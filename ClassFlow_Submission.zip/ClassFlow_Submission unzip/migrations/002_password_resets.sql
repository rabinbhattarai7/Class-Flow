-- Store a hashed recovery code with issue, expiry and use times. A new request can replace the previous code for the same account.
CREATE TABLE IF NOT EXISTS cf_password_resets (
    user_id INT UNSIGNED NOT NULL PRIMARY KEY,
    code_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL UNIQUE,
    account_state CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    requested_at BIGINT UNSIGNED NOT NULL,
    expires_at BIGINT UNSIGNED NOT NULL,
    used_at BIGINT UNSIGNED NULL
) ENGINE=InnoDB;
