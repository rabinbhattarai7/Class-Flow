-- Store one set of reminder preferences per student and track each delivery attempt separately from the academic record.
-- Additive migration. Does not replace or delete existing student records.
CREATE TABLE IF NOT EXISTS cf_preferences (
 user_id INT UNSIGNED NOT NULL PRIMARY KEY,
 email_enabled TINYINT NOT NULL DEFAULT 0,
 timezone VARCHAR(64) NOT NULL DEFAULT 'Europe/Copenhagen',
 study_reminder VARCHAR(16) NOT NULL DEFAULT '1_day',
 class_reminder VARCHAR(16) NOT NULL DEFAULT 'none',
 assignment_reminder VARCHAR(16) NOT NULL DEFAULT '1_day',
 exam_reminder VARCHAR(16) NOT NULL DEFAULT '1_day'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
-- The delivery key identifies an occurrence and its reminder settings. Its primary key prevents duplicate rows for the same key.
CREATE TABLE IF NOT EXISTS cf_reminder_deliveries (
 delivery_key CHAR(64) NOT NULL PRIMARY KEY,
 user_id INT UNSIGNED NOT NULL,
 event_type VARCHAR(20) NOT NULL,
 event_id INT UNSIGNED NOT NULL,
 event_title VARCHAR(150) NOT NULL,
 event_at DATETIME NOT NULL,
 status VARCHAR(20) NOT NULL DEFAULT 'pending',
 attempts INT NOT NULL DEFAULT 0,
 last_error VARCHAR(250) DEFAULT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 attempted_at DATETIME DEFAULT NULL,
 sent_at DATETIME DEFAULT NULL,
 INDEX(user_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
