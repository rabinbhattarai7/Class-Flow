// Shared navigation interactions; no academic records are changed.
(() => {
    const toggle = document.getElementById('cf-menu-toggle');
    const nav = document.getElementById('cf-navigation');
    const backdrop = document.getElementById('cf-nav-backdrop');
    if (!toggle || !nav || !backdrop) return;
    const narrow = window.matchMedia('(max-width: 767.98px)');
    const setOpen = (open, restoreFocus = false) => {
        document.body.classList.toggle('cf-nav-open', open);
        toggle.setAttribute('aria-expanded', String(open));
        toggle.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
        backdrop.hidden = !open;
        nav.inert = narrow.matches && !open;
        if (restoreFocus) toggle.focus();
    };
    toggle.addEventListener('click', () => setOpen(toggle.getAttribute('aria-expanded') !== 'true'));
    backdrop.addEventListener('click', () => setOpen(false, true));
    nav.addEventListener('click', e => { if (e.target.closest('a') && narrow.matches) setOpen(false); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') { setOpen(false, true); document.querySelectorAll('.cf-help-menu[open]').forEach(el => el.removeAttribute('open')); } });
    narrow.addEventListener('change', () => setOpen(false));
    setOpen(false);
    document.querySelectorAll('.sidebar a.active').forEach(a => a.setAttribute('aria-current', 'page'));
})();
