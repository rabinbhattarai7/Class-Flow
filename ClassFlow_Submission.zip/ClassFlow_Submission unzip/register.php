<?php
/* Registration validates the account details, checks that the email is available and stores a password hash for future sign-in. */
/* Registration page: validates account details and stores a password hash for a new user. */
// Connect to the database so we can check and save users
require_once 'include/database.php';

// Default empty values so the form starts blank
$firstName = '';
$lastName = '';
$email = '';
$errors = []; // Stores validation error messages for each field

// Run only when the user submits the registration form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the submitted form data (extra spaces removed from text fields)
    $firstName = trim($_POST['first_name'] ?? '');
    $lastName = trim($_POST['last_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    // Validate first name: required and 2-50 characters
    if ($firstName === '') {
        $errors['first_name'] = 'First name is required.';
    } elseif (strlen($firstName) < 2 || strlen($firstName) > 50) {
        $errors['first_name'] = 'First name must be between 2 and 50 characters.';
    }

    // Validate last name: required and 2-50 characters
    if ($lastName === '') {
        $errors['last_name'] = 'Last name is required.';
    } elseif (strlen($lastName) < 2 || strlen($lastName) > 50) {
        $errors['last_name'] = 'Last name must be between 2 and 50 characters.';
    }

    // Validate email: required, correct format, and not already used by another account
    if ($email === '') {
        $errors['email'] = 'Email address is required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Enter a valid email address.';
    } else {
        // Look up the email in the database to prevent duplicate accounts
        $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ?');
        $stmt->execute([$email]);

        if ($stmt->fetch()) {
            $errors['email'] = 'An account with this email already exists.';
        }
    }

    // Validate password: required and at least 8 characters
    if ($password === '') {
        $errors['password'] = 'Password is required.';
    } elseif (strlen($password) < 8) {
        $errors['password'] = 'Password must be at least 8 characters.';
    }

    // Validate confirm password: required and must match the password
    if ($confirmPassword === '') {
        $errors['confirm_password'] = 'Please confirm your password.';
    } elseif ($password !== $confirmPassword) {
        $errors['confirm_password'] = 'Passwords do not match.';
    }

    // If there are no errors, create the account
    if (empty($errors)) {
        // Hash the password so it is not stored as plain text
        // Store a one-way hash instead of the password itself. PHP adds a random salt when creating the hash and can verify the password later.
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        try {
            // Save the new user in the database
            $stmt = $pdo->prepare('INSERT INTO users (first_name, last_name, email, password) VALUES (?, ?, ?, ?)');
            $stmt->execute([$firstName, $lastName, $email, $hashedPassword]);

            // Redirect to the login page with a "registered" success flag
            header('Location: login.php?registered=1');
            exit;
        } catch (PDOException $e) {
            // Show a general error if saving to the database fails
            $errors['general'] = 'Registration failed. Please try again.';
        }
    }
}

// Load the page header (navigation, styles, etc.)
require_once 'include/header.php';
?>

<!-- Main page content, positioned alongside the sidebar on dashboard pages. -->
<main class="login-section">
    <div class="login-card">
        <!-- Page icon, title and subtitle -->
        <div class="text-center">
            <div class="login-icon">
                <i class="bi bi-person-plus"></i>
            </div>
            <h1 class="login-title">Create your account</h1>
            <p class="login-subtitle">Register to start organising your university schedule.</p>
        </div>

        <!-- Shows a general error, e.g. when the database save fails -->
        <?php if (isset($errors['general'])): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($errors['general']) ?></div>
        <?php endif; ?>

        <!-- Registration form (submits to this same page) -->
        <form action="register.php" method="POST" novalidate>
            <div class="row g-3 mb-3">
                <!-- First name input: keeps the typed value and shows its error if invalid -->
                <div class="col-md-6">
                    <!-- Input field: First Name. -->
                    <label for="first_name" class="form-label">First Name</label>
                    <input type="text" class="form-control <?= isset($errors['first_name']) ? 'is-invalid' : '' ?>" id="first_name" name="first_name" value="<?= htmlspecialchars($firstName) ?>" placeholder="First name">
                    <?php if (isset($errors['first_name'])): ?>
                        <div class="invalid-feedback"><?= htmlspecialchars($errors['first_name']) ?></div>
                    <?php endif; ?>
                </div>
                <!-- Last name input: keeps the typed value and shows its error if invalid -->
                <div class="col-md-6">
                    <!-- Input field: Last Name. -->
                    <label for="last_name" class="form-label">Last Name</label>
                    <input type="text" class="form-control <?= isset($errors['last_name']) ? 'is-invalid' : '' ?>" id="last_name" name="last_name" value="<?= htmlspecialchars($lastName) ?>" placeholder="Last name">
                    <?php if (isset($errors['last_name'])): ?>
                        <div class="invalid-feedback"><?= htmlspecialchars($errors['last_name']) ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Email input: keeps the typed value and shows its error if invalid -->
            <div class="mb-3">
                <!-- Input field: Email Address. -->
                <label for="email" class="form-label">Email Address</label>
                <div class="input-group has-validation">
                    <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                    <input type="email" class="form-control <?= isset($errors['email']) ? 'is-invalid' : '' ?>" id="email" name="email" value="<?= htmlspecialchars($email) ?>" placeholder="student@example.com">
                    <?php if (isset($errors['email'])): ?>
                        <div class="invalid-feedback"><?= htmlspecialchars($errors['email']) ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Password input: the eye button lets the user show or hide the password -->
            <div class="mb-3">
                <!-- Input field: Password. -->
                <label for="password" class="form-label">Password</label>
                <div class="input-group has-validation">
                    <span class="input-group-text"><i class="bi bi-lock"></i></span>
                    <input type="password" class="form-control <?= isset($errors['password']) ? 'is-invalid' : '' ?>" id="password" name="password" placeholder="Minimum 8 characters">
                    <button class="input-group-text password-toggle" type="button" id="togglePassword" data-password-target="password" aria-controls="password" aria-label="Show password" aria-pressed="false">
                        <i class="bi bi-eye" id="eyeIcon"></i>
                    </button>
                    <?php if (isset($errors['password'])): ?>
                        <div class="invalid-feedback"><?= htmlspecialchars($errors['password']) ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Confirm password input: user re-enters the password to avoid typos -->
            <div class="mb-4">
                <!-- Input field: Confirm Password. -->
                <label for="confirm_password" class="form-label">Confirm Password</label>
                <div class="input-group has-validation">
                    <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
                    <input type="password" class="form-control <?= isset($errors['confirm_password']) ? 'is-invalid' : '' ?>" id="confirm_password" name="confirm_password" placeholder="Enter password again">
                    <button class="input-group-text password-toggle" type="button" data-password-target="confirm_password" aria-controls="confirm_password" aria-label="Show password" aria-pressed="false">
                        <i class="bi bi-eye" aria-hidden="true"></i>
                    </button>
                    <?php if (isset($errors['confirm_password'])): ?>
                        <div class="invalid-feedback"><?= htmlspecialchars($errors['confirm_password']) ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Button that submits the form to create the account -->
            <button type="submit" class="btn btn-cf-primary w-100">
                <i class="bi bi-person-plus me-2"></i>Create Account
            </button>

            <!-- Link for users who already have an account -->
            <div class="text-center mt-4">
                <span class="register-text">Already have an account?</span>
                <a href="login.php" class="cf-link ms-1">Login</a>
            </div>
        </form>
    </div>
</main>

<!-- Load the page footer (closing tags, scripts, etc.) -->
<?php require_once 'include/footer.php'; ?>