# Load the saved settings into the current command before starting PHP. Preview, self-test and normal sending use the same worker.
# Run this under the Windows account whose environment contains the Gmail settings.
[CmdletBinding(DefaultParameterSetName = 'Send')]
param(
    [Parameter(Mandatory, ParameterSetName = 'Preview')]
    [switch]$DryRun,
    [Parameter(Mandatory, ParameterSetName = 'Test')]
    [switch]$TestGmail
)

$ErrorActionPreference = 'Stop'
# Reload the saved user settings on each run because an older terminal or scheduled task may not have inherited them.
foreach ($name in @('CLASSFLOW_GMAIL_ADDRESS', 'CLASSFLOW_GMAIL_APP_PASSWORD')) {
    $value = [Environment]::GetEnvironmentVariable($name, 'User')
    if ($value) { [Environment]::SetEnvironmentVariable($name, $value, 'Process') }
}
$workerArguments = @()
if ($DryRun) { $workerArguments += '--dry-run' }
if ($TestGmail) { $workerArguments += '--test-gmail-to-self' }
& 'C:\xampp\php\php.exe' (Join-Path $PSScriptRoot 'send_reminders.php') @workerArguments
exit $LASTEXITCODE
