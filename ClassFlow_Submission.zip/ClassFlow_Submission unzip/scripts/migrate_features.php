<?php
/* The migration command adds the tables and fields needed for reminders and password recovery without replacing student accounts or schedules. */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require __DIR__ . '/../include/database.php';
foreach (['001_planning_and_reminders.sql', '002_password_resets.sql'] as $migration) {
    $pdo->exec(file_get_contents(__DIR__ . '/../migrations/' . $migration));
}
// Inspect the existing preference fields so the two shared options can be added once on older installations.
$columns = $pdo->query('SHOW COLUMNS FROM cf_preferences')->fetchAll(PDO::FETCH_COLUMN);
foreach (['assignment_reminder', 'exam_reminder'] as $column) {
    if (!in_array($column, $columns, true)) {
        $pdo->exec("ALTER TABLE cf_preferences ADD COLUMN $column VARCHAR(16) NOT NULL DEFAULT '1_day'");
    }
}
$classColumns = $pdo->query('SHOW COLUMNS FROM classes')->fetchAll(PDO::FETCH_COLUMN);
if (!in_array('class_date', $classColumns, true)) {
    $pdo->exec('ALTER TABLE classes ADD COLUMN class_date DATE DEFAULT NULL');
}

echo "ClassFlow planning, reminder and password reset tables are ready. Existing records were preserved.\n";
