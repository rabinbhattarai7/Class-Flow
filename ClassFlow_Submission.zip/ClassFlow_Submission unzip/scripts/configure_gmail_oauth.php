<?php
/* The local setup script opens a Google consent flow, verifies the returning response and saves the sender connection for future mail delivery. */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require __DIR__ . '/../include/gmail_oauth.php';

if ($argc !== 2) {
    fwrite(STDERR, "Usage: php configure_gmail_oauth.php <Google desktop client JSON path>\n");
    exit(2);
}

try {
    $path = cf_gmail_oauth_path();
    if ($path === null) {
        throw new RuntimeException('Run setup from your Windows user account.');
    }
    $contents = @file_get_contents($argv[1]);
    $client = $contents === false ? null : (json_decode($contents, true)['installed'] ?? null);
    if (empty($client['client_id']) || empty($client['client_secret'])) {
        throw new RuntimeException('Select the JSON file for a Google OAuth Desktop app client.');
    }

    // Accept the browser callback on this computer only. The temporary port allows the setup to run without exposing a public endpoint.
    $listener = @stream_socket_server('tcp://127.0.0.1:0');
    if ($listener === false) {
        throw new RuntimeException('Could not start the local Google sign-in callback.');
    }
    $redirect = 'http://' . stream_socket_get_name($listener, false) . '/';
    // The state value links the callback to this sign-in attempt. The separate verifier proves that the same setup initiated the code exchange.
    $state = bin2hex(random_bytes(32));
    $verifier = cf_gmail_base64url(random_bytes(32));
    $query = http_build_query([
        'client_id' => $client['client_id'],
        'redirect_uri' => $redirect,
        'response_type' => 'code',
        'scope' => 'openid email https://www.googleapis.com/auth/gmail.send',
        'access_type' => 'offline',
        'prompt' => 'consent select_account',
        'state' => $state,
        'code_challenge' => cf_gmail_base64url(hash('sha256', $verifier, true)),
        'code_challenge_method' => 'S256',
    ], '', '&', PHP_QUERY_RFC3986);
    echo "Open this URL in your regular browser, choose the Gmail sender and review the permissions:\n";
    echo "https://accounts.google.com/o/oauth2/v2/auth?$query\n";

    $deadline = time() + 300;
    $code = null;
    while ($deadline > time() && ($connection = @stream_socket_accept($listener, $deadline - time()))) {
        stream_set_timeout($connection, 2);
        $request = fgets($connection, 8192);
        $response = [];
        if (is_string($request) && preg_match('~^GET /(\?[^ ]+) HTTP/1\.[01]~', $request, $match)) {
            parse_str(substr($match[1], 1), $response);
        }
        // Accept a callback only when its state matches the value generated for this setup.
        $valid = is_string($response['state'] ?? null) && hash_equals($state, $response['state']);
        $message = $valid ? 'Return to the ClassFlow setup window to see the result.' : 'No matching ClassFlow sign-in request.';
        fwrite($connection, "HTTP/1.1 " . ($valid ? '200 OK' : '400 Bad Request')
            . "\r\nContent-Type: text/plain; charset=utf-8\r\nCache-Control: no-store"
            . "\r\nConnection: close\r\nContent-Length: " . strlen($message) . "\r\n\r\n" . $message);
        fclose($connection);
        if ($valid) {
            $code = $response['code'] ?? null;
            break;
        }
    }
    fclose($listener);
    if (!is_string($code) || $code === '') {
        throw new RuntimeException('Google sign-in was cancelled or the setup window timed out.');
    }

    // Exchange the one-time code for an access token and a refresh token that lets later reminder runs send mail.
    $token = cf_gmail_token([
        'client_id' => $client['client_id'],
        'client_secret' => $client['client_secret'],
        'code' => $code,
        'code_verifier' => $verifier,
        'redirect_uri' => $redirect,
        'grant_type' => 'authorization_code',
    ]);
    if (empty($token['refresh_token']) || empty($token['access_token'])
        || !in_array('https://www.googleapis.com/auth/gmail.send', explode(' ', $token['scope'] ?? ''), true)) {
        throw new RuntimeException('Google did not grant Gmail send permission and offline access.');
    }
    // Ask Google which verified account approved access so ClassFlow can save the correct sender address.
    $account = cf_gmail_google_request(
        'https://openidconnect.googleapis.com/v1/userinfo',
        ['Authorization: Bearer ' . $token['access_token']],
        null,
        'Google account lookup'
    );
    if (empty($account['email_verified']) || !filter_var($account['email'] ?? '', FILTER_VALIDATE_EMAIL)) {
        throw new RuntimeException('Google did not return a verified sender email.');
    }
    $directory = dirname($path);
    if (!is_dir($directory) && !mkdir($directory, 0700, true)) {
        throw new RuntimeException('Could not create the Windows user configuration folder.');
    }
    $data = json_encode([
        'client_id' => $client['client_id'],
        'client_secret' => $client['client_secret'],
        'refresh_token' => $token['refresh_token'],
        'email' => $account['email'],
    ], JSON_THROW_ON_ERROR);
    // Write the complete connection to a temporary file before replacing the saved configuration. This avoids leaving a partially written connection.
    $temporary = $path . '.' . bin2hex(random_bytes(8)) . '.tmp';
    try {
        if (file_put_contents($temporary, $data) !== strlen($data) || !rename($temporary, $path)) {
            throw new RuntimeException('Could not save the Gmail connection.');
        }
    } finally {
        if (is_file($temporary)) unlink($temporary);
    }
    echo "Gmail sender saved for {$account['email']}. Run scripts/run_reminders.ps1 -TestGmail.\n";
} catch (Throwable $error) {
    fwrite(STDERR, $error->getMessage() . "\n");
    exit(1);
}
