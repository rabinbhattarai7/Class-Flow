# Read the sender address and app password locally. Save them for this Windows account so the application can use them without placing credentials in its source files.
# Run locally. Never paste the app password into a chat or commit it to the project.
$ErrorActionPreference = 'Stop'
$address = Read-Host 'Gmail address to send reminders from'
if ($address -notmatch '^[^\s@]+@[^\s@]+\.[^\s@]+$') { throw 'Enter a valid email address.' }
# Hide the password prompt input and remove spaces inserted by the way Google displays the app password.
$secret = Read-Host 'Gmail app password (input hidden)' -AsSecureString
$credential = [PSCredential]::new($address, $secret)
$password = $credential.GetNetworkCredential().Password.Replace(' ', '')
if ($password.Length -ne 16) { throw 'Enter the 16-character Google app password, not your normal Gmail password.' }
[Environment]::SetEnvironmentVariable('CLASSFLOW_GMAIL_ADDRESS', $address, 'User')
[Environment]::SetEnvironmentVariable('CLASSFLOW_GMAIL_APP_PASSWORD', $password, 'User')
Remove-Variable password,credential,secret
Write-Output 'Sender settings saved to your Windows user environment. Restart XAMPP for the website to see them.'
Write-Output 'These settings are accessible to programs running as your Windows user. Use a dedicated sender account.'
Write-Output 'To start scheduled delivery, run scripts/register_reminder_task.ps1.'
