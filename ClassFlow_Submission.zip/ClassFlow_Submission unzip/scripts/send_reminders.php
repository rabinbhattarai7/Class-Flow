<?php
/* This command can preview the queue, send one test email to the configured sender, or run normal reminder delivery. */
/* Run every five minutes with Task Scheduler or cron. Never expose a web sending endpoint. */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require __DIR__ . '/../include/email.php';
// Validate the command option first. Preview and test mode are explicit so an accidental option cannot start real queue delivery.
$mode = $argv[1] ?? '';
if ($argc > 2 || !in_array($mode, ['', '--dry-run', '--test-gmail-to-self'], true)) {
    fwrite(STDERR, "Usage: php send_reminders.php [--dry-run | --test-gmail-to-self]\n");
    exit(2);
}

// Send one identifiable message back to the configured sender without reading the academic reminder queue.
if ($mode === '--test-gmail-to-self') {
    if (!cf_mail_configured()) {
        fwrite(STDERR, "Gmail is not configured. See FEATURE_SETUP.md for Gmail connection options.\n");
        exit(1);
    }

    $reference = gmdate('Ymd-His') . '-' . bin2hex(random_bytes(4));
    $subject = 'ClassFlow Gmail delivery test ' . $reference;
    try {
        cf_send_email(
            cf_mail_sender_address(),
            $subject,
            "This is a synthetic ClassFlow test message.\nReference: {$reference}\n"
        );
    } catch (\Exception $error) {
        fwrite(STDERR, "Gmail submission failed: " . $error->getMessage() . "\n");
        exit(1);
    }
    echo "Gmail accepted the test message. Check the sender's inbox for: {$subject}\n";
    exit(0);
}

$dryRun = $mode === '--dry-run';
require __DIR__ . '/../include/database.php';
require __DIR__ . '/../include/features.php';
if (!cf_feature_ready($pdo)) { fwrite(STDERR, "Run scripts/migrate_features.php first.\n"); exit(1); }
if (!$dryRun && !cf_mail_configured()) { fwrite(STDERR, "Gmail is not configured. No messages sent.\n"); exit(1); }
require __DIR__ . '/../include/reminder_dispatch.php';
// Use the same worker for previews and normal runs. The exit code tells a scheduler whether any delivery attempt was unconfirmed.
$result = cf_dispatch_reminders($pdo, 'cf_send_email', $dryRun);
if ($result['busy']) echo "Another sender is running.\n";
echo ($dryRun ? 'Previewed' : 'Attempted') . " {$result['count']} reminders; {$result['errors']} unconfirmed.\n";
exit($result['errors'] ? 1 : 0);
