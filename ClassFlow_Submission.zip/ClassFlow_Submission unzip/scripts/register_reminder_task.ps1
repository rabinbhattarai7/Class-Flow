# Register a Windows task that checks the reminder queue every five minutes while this account is signed in. Ignore a new run if the previous one is still working.
# Explicitly run this after configuring Gmail and opting in to reminders.
$ErrorActionPreference = 'Stop'
$script = Join-Path $PSScriptRoot 'run_reminders.ps1'
$action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument ('-NoProfile -NonInteractive -WindowStyle Hidden -File "' + $script + '"')
# Schedule the first check after one minute and repeat it every five minutes.
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 5)
$settings = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 4) -StartWhenAvailable
$principal = New-ScheduledTaskPrincipal -UserId ([Security.Principal.WindowsIdentity]::GetCurrent().Name) -LogonType Interactive -RunLevel Limited
Register-ScheduledTask -TaskName 'ClassFlow Email Reminders' -Action $action -Trigger $trigger -Settings $settings -Principal $principal -Description 'Send opted-in ClassFlow reminders every five minutes while signed in.' -Force | Out-Null
Write-Output 'ClassFlow reminder task registered. XAMPP MySQL must be running. The computer must be on and your Windows account signed in.'
