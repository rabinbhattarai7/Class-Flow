<?php
/* The study planner displays planned, in-progress and completed study sessions and links to the forms that change them. */
/* Study planner: lists the user's study sessions and their progress. */
session_start();
require_once '../include/database.php';

// Reject requests that do not have a signed-in user in the session.
if (!isset($_SESSION['user_id'])) {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: ../login.php');
    exit;
}

// Use the session account ID to scope database operations to the current user.
$userId = $_SESSION['user_id'];
$successMessage = '';
$errorMessage = '';

// Read this session value only when it exists.
if (isset($_SESSION['success_message'])) {
    $successMessage = $_SESSION['success_message'];
    // Remove the flash message so it is displayed only once.
    unset($_SESSION['success_message']);
}

// Read this session value only when it exists.
if (isset($_SESSION['error_message'])) {
    $errorMessage = $_SESSION['error_message'];
    // Remove the flash message so it is displayed only once.
    unset($_SESSION['error_message']);
}

// Prepare a lookup of study sessions using bound parameters. Restrict the query to the current account.
$stmt = $pdo->prepare("
    SELECT *
    FROM study_sessions
    WHERE user_id = ?
    ORDER BY
        CASE WHEN status = 'Completed' THEN 1 ELSE 0 END,
        study_date ASC,
        start_time ASC
");
$stmt->execute([$userId]);
// Load all matching rows for the list or calculations below.
$studySessions = $stmt->fetchAll();

$totalSessions = count($studySessions);
$plannedSessions = 0;
$completedSessions = 0;
$pastSessions = 0;

// Process each item in this collection for the page or response.
foreach ($studySessions as $session) {
    if ($session['status'] === 'Completed') {
        $completedSessions++;
    } elseif (strtotime($session['study_date'] . ' ' . $session['end_time']) < time()) {
        $pastSessions++;
    } else {
        $plannedSessions++;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<!-- Set the page title, character encoding, responsive viewport and stylesheet links. -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Study Planner | ClassFlow</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=20261103b"><link rel="stylesheet" href="../css/theme.css?v=20261113-red1">
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <?php require_once 'sidebar.php'; ?>

        <!-- Main page content, positioned alongside the sidebar on dashboard pages. -->
        <main class="col-md-9 col-lg-10 p-4 dashboard-content">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="page-title mb-1">Study Planner</h2>
                    <p class="text-muted mb-0">Plan and organise your personal study sessions.</p>
                </div>

                <a href="add_study_session.php" class="btn btn-add">
                    <i class="fa-solid fa-plus me-1"></i> Add Study Session
                </a>
            </div>

            <?php if ($successMessage): ?>
                <div class="alert alert-success"><?= htmlspecialchars($successMessage) ?></div>
            <?php endif; ?>

            <?php if ($errorMessage): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($errorMessage) ?></div>
            <?php endif; ?>

            <div class="row g-3 mb-4">
                <div class="col-md-3">
                    <div class="study-stat-card">
                        <div class="study-stat-icon total">
                            <i class="fa-solid fa-book-open-reader"></i>
                        </div>
                        <div>
                            <span>Total Sessions</span>
                            <h3><?= $totalSessions ?></h3>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="study-stat-card">
                        <div class="study-stat-icon planned">
                            <i class="fa-regular fa-calendar"></i>
                        </div>
                        <div>
                            <span>Planned</span>
                            <h3><?= $plannedSessions ?></h3>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="study-stat-card">
                        <div class="study-stat-icon completed">
                            <i class="fa-solid fa-check"></i>
                        </div>
                        <div>
                            <span>Completed</span>
                            <h3><?= $completedSessions ?></h3>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="study-stat-card">
                        <div class="study-stat-icon past">
                            <i class="fa-solid fa-clock-rotate-left"></i>
                        </div>
                        <div>
                            <span>Past</span>
                            <h3><?= $pastSessions ?></h3>
                        </div>
                    </div>
                </div>
            </div>

            <div class="table-card">
                <div class="mb-3">
                    <h5 class="fw-bold mb-1">My Study Sessions</h5>
                    <p class="text-muted small mb-0">Your planned personal study schedule</p>
                </div>

                <div class="table-responsive">
                    <!-- Display the loaded records in a table with headings and row actions. -->
                    <table class="table study-table align-middle mb-0">
                        <!-- Column headings describe the values displayed in each record row. -->
                        <thead>
                            <tr>
                                <th>Topic</th>
                                <th>Module</th>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <!-- Render the record rows and any empty-state message. -->
                        <tbody>
                            <?php if ($studySessions): ?>
                                <?php foreach ($studySessions as $session): ?>
                                    <?php
                                    $isPast = $session['status'] !== 'Completed'
                                        && strtotime($session['study_date'] . ' ' . $session['end_time']) < time();
                                    ?>

                                    <tr>
                                        <td>
                                            <a href="view_study_session.php?id=<?= $session['id'] ?>" class="study-title">
                                                <?= htmlspecialchars($session['topic']) ?>
                                            </a>
                                        </td>

                                        <td><?= htmlspecialchars($session['module']) ?></td>

                                        <td>
                                            <?= date('d M Y', strtotime($session['study_date'])) ?>

                                            <?php if ($isPast): ?>
                                                <small class="d-block text-danger">Past</small>
                                            <?php endif; ?>
                                        </td>

                                        <td>
                                            <?= date('g:i A', strtotime($session['start_time'])) ?>
                                            -
                                            <?= date('g:i A', strtotime($session['end_time'])) ?>
                                        </td>

                                        <td>
                                            <span class="study-status <?= strtolower(str_replace(' ', '-', $session['status'])) ?>">
                                                <?= htmlspecialchars($session['status']) ?>
                                            </span>
                                        </td>

                                        <td>
                                            <div class="d-flex gap-1">
                                                <a href="view_study_session.php?id=<?= $session['id'] ?>" class="btn btn-sm btn-info text-white">
                                                    <i class="fa-solid fa-eye"></i>
                                                </a>

                                                <a href="edit_study_session.php?id=<?= $session['id'] ?>" class="btn btn-sm btn-warning">
                                                    <i class="fa-solid fa-pen-to-square"></i>
                                                </a>

                                                <?php if ($session['status'] !== 'Completed'): ?>
                                                    <!-- Submit these fields using POST to the PHP handler named in the form action. -->
                                                    <form method="POST" action="complete_study_session.php">
                                                        <!-- Send this record identifier with the form; the server must still check ownership. -->
                                                        <input type="hidden" name="id" value="<?= $session['id'] ?>">
                                                        <!-- Submit this form to its PHP handler. -->
                                                        <button type="submit" class="btn btn-sm btn-success" title="Mark Completed">
                                                            <i class="fa-solid fa-check"></i>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>

                                                <!-- Submit these fields using POST to the PHP handler named in the form action. -->
                                                <form method="POST" action="delete_study_session.php" onsubmit="return confirm('Are you sure you want to delete this study session?');">
                                                    <!-- Send this record identifier with the form; the server must still check ownership. -->
                                                    <input type="hidden" name="id" value="<?= $session['id'] ?>">
                                                    <!-- Submit this form to its PHP handler. -->
                                                    <button type="submit" class="btn btn-sm btn-danger">
                                                        <i class="fa-solid fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center py-5">
                                        <i class="fa-solid fa-book-open-reader fa-2x text-muted mb-3"></i>
                                        <p class="text-muted mb-2">No study sessions planned yet.</p>
                                        <a href="add_study_session.php" class="btn btn-add btn-sm">Plan Your First Session</a>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</div>
</body>
</html>