<?php
/* The calendar endpoint returns the signed-in student’s events for a requested date range. Weekly classes are expanded into individual dates. */
/* JSON endpoint: combines the signed-in user's events within the requested date range. */
session_start();
require_once '../include/database.php';

// Tell the browser that this endpoint returns JSON rather than an HTML page.
header('Content-Type: application/json');

// Reject requests that do not have a signed-in user in the session.
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode([]);
    exit;
}

// Use the session account ID to scope database operations to the current user.
$userId = $_SESSION['user_id'];

// Read the calendar date range; the end boundary is treated as exclusive.
// The browser supplies the dates currently visible in the calendar so the response only needs to include that range.
$rangeStart = $_GET['start'] ?? '';
$rangeEnd = $_GET['end'] ?? '';

// Return an empty result when the requested date range is incomplete.
if (!$rangeStart || !$rangeEnd) {
    echo json_encode([]);
    exit;
}

$rangeStartDate = substr($rangeStart, 0, 10);
$rangeEndDate = substr($rangeEnd, 0, 10);

$events = [];

/*
|--------------------------------------------------------------------------
| Assignments
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT id, title, module, due_date, due_time, status
    FROM assignments
    WHERE user_id = ?
    AND due_date >= ?
    AND due_date < ?
");

$stmt->execute([
    $userId,
    $rangeStartDate,
    $rangeEndDate
]);

// Load all matching rows for the list or calculations below.
$assignments = $stmt->fetchAll();

// Process each item in this collection for the page or response.
foreach ($assignments as $assignment) {
    // Map this database record to the event fields expected by FullCalendar.
    $events[] = [
        'id' => 'assignment-' . $assignment['id'],
        'title' => $assignment['title'],
        'start' => $assignment['due_date'] . 'T' . $assignment['due_time'],
        'url' => 'view_assignment.php?id=' . $assignment['id'],
        'type' => 'assignment',
        'module' => $assignment['module'],
        'status' => $assignment['status']
    ];
}

/*
|--------------------------------------------------------------------------
| Exams
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT id, exam_name, module, exam_date, start_time, end_time, location, exam_type
    FROM exams
    WHERE user_id = ?
    AND exam_date >= ?
    AND exam_date < ?
");

$stmt->execute([
    $userId,
    $rangeStartDate,
    $rangeEndDate
]);

// Load all matching rows for the list or calculations below.
$exams = $stmt->fetchAll();

// Process each item in this collection for the page or response.
foreach ($exams as $exam) {
    // Map this database record to the event fields expected by FullCalendar.
    $events[] = [
        'id' => 'exam-' . $exam['id'],
        'title' => $exam['exam_name'],
        'start' => $exam['exam_date'] . 'T' . $exam['start_time'],
        'end' => $exam['exam_date'] . 'T' . $exam['end_time'],
        'url' => 'view_exam.php?id=' . $exam['id'],
        'type' => 'exam',
        'module' => $exam['module'],
        'location' => $exam['location'],
        'examType' => $exam['exam_type']
    ];
}

/*
|--------------------------------------------------------------------------
| Study Sessions
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT id, topic, module, study_date, start_time, end_time, status
    FROM study_sessions
    WHERE user_id = ?
    AND study_date >= ?
    AND study_date < ?
");

$stmt->execute([
    $userId,
    $rangeStartDate,
    $rangeEndDate
]);

// Load all matching rows for the list or calculations below.
$studySessions = $stmt->fetchAll();

// Process each item in this collection for the page or response.
foreach ($studySessions as $studySession) {
    // Map this database record to the event fields expected by FullCalendar.
    $events[] = [
        'id' => 'study-' . $studySession['id'],
        'title' => $studySession['topic'],
        'start' => $studySession['study_date'] . 'T' . $studySession['start_time'],
        'end' => $studySession['study_date'] . 'T' . $studySession['end_time'],
        'url' => 'view_study_session.php?id=' . $studySession['id'],
        'type' => 'study',
        'module' => $studySession['module'],
        'status' => $studySession['status']
    ];
}

/*
|--------------------------------------------------------------------------
| Weekly Classes
|--------------------------------------------------------------------------
|
| Dated classes occur once; undated classes repeat weekly.
| They contain Monday, Tuesday, Wednesday, etc.
|
| Therefore, we generate each class occurrence for the requested
| calendar date range.
|
*/

$stmt = $pdo->prepare("
    SELECT id, subject_name, lecturer_name, day, class_date, start_time, end_time, room, class_type
    FROM classes
    WHERE user_id = ?
");

$stmt->execute([$userId]);

// Load all matching rows for the list or calculations below.
$classes = $stmt->fetchAll();

$startDate = new DateTime($rangeStartDate);
$endDate = new DateTime($rangeEndDate);

// Walk through the requested dates and place each repeating class on every date matching its weekday.
for ($date = clone $startDate; $date < $endDate; $date->modify('+1 day')) {

    $dayName = $date->format('l');
    $currentDate = $date->format('Y-m-d');

    // Process each item in this collection for the page or response.
    foreach ($classes as $class) {

        if (!empty($class['class_date']) ? $class['class_date'] !== $currentDate : $class['day'] !== $dayName) {
            continue;
        }

        // Map this database record to the event fields expected by FullCalendar.
        $events[] = [
            'id' => 'class-' . $class['id'] . '-' . $currentDate,
            'title' => $class['subject_name'],
            'start' => $currentDate . 'T' . $class['start_time'],
            'end' => $currentDate . 'T' . $class['end_time'],
            'url' => 'view_class.php?id=' . $class['id'],
            'type' => 'class',
            'module' => $class['subject_name'],
            'lecturer' => $class['lecturer_name'],
            'room' => $class['room'],
            'classType' => $class['class_type']
        ];
    }
}

// Return the event collection as JSON for the calendar in the browser.
// Return the event records in the format the browser calendar expects. The calendar uses the detail link to open the original record.
echo json_encode($events);