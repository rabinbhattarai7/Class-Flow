<?php
/* This handler deletes the requested study session only when it belongs to the signed-in student. */
/* Accepts a POST request and deletes the signed-in user's study session. */
session_start();
require_once '../include/database.php';

// Reject requests that do not have a signed-in user in the session.
if (!isset($_SESSION['user_id'])) {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: ../login.php');
    exit;
}

// Require a form submission before performing this state-changing action.
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: study_planner.php');
    exit;
}

// Use the session account ID to scope database operations to the current user.
$userId = $_SESSION['user_id'];
// Read the requested record ID and require a valid integer.
$sessionId = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

if (!$sessionId) {
    $_SESSION['error_message'] = 'Invalid study session.';
    // Redirect the browser after processing; exit below stops further output.
    header('Location: study_planner.php');
    exit;
}

// Prepare deletion of the matching study sessions record. Restrict the query to the current account.
$stmt = $pdo->prepare("
    DELETE FROM study_sessions
    WHERE id = ? AND user_id = ?
");

$stmt->execute([$sessionId, $userId]);

// Check whether the database operation actually changed a matching record.
if ($stmt->rowCount() > 0) {
    $_SESSION['success_message'] = 'Study session deleted successfully.';
} else {
    $_SESSION['error_message'] = 'Study session not found or could not be deleted.';
}

// Redirect the browser after processing; exit below stops further output.
header('Location: study_planner.php');
exit;