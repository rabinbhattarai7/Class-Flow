<?php
/* The details page reads one class using both the record number and the signed-in student’s account number. */
/* Loads and displays the signed-in user's class. */
session_start();
require_once '../include/database.php';

// Reject requests that do not have a signed-in user in the session.
if (!isset($_SESSION['user_id'])) {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: ../login.php');
    exit;
}

// Use the session account ID to scope database operations to the current user.
$userId = $_SESSION['user_id'];
// Read the requested record ID and require a valid integer.
$classId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$classId) {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: timetable.php');
    exit;
}

// Prepare a lookup of classes using bound parameters. Restrict the query to the current account.
$stmt = $pdo->prepare("SELECT * FROM classes WHERE id = ? AND user_id = ?");
$stmt->execute([$classId, $userId]);
// Read the matching record; false means no row was found.
$class = $stmt->fetch();

if (!$class) {
    $_SESSION['error_message'] = 'Class not found.';
    // Redirect the browser after processing; exit below stops further output.
    header('Location: timetable.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<!-- Set the page title, character encoding, responsive viewport and stylesheet links. -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($class['subject_name']) ?> | ClassFlow</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=20261103b"><link rel="stylesheet" href="../css/theme.css?v=20261113-red1">
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <?php require_once 'sidebar.php'; ?>

        <!-- Main page content, positioned alongside the sidebar on dashboard pages. -->
        <main class="col-md-9 col-lg-10 p-4 dashboard-content">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="page-title mb-1">Class Details</h2>
                    <p class="text-muted mb-0">View your class information.</p>
                </div>
                <a href="timetable.php" class="btn btn-outline-secondary">
                    <i class="fa-solid fa-arrow-left me-1"></i> Back
                </a>
            </div>

            <div class="class-details-card">
                <div class="class-details-header <?= strtolower($class['class_type']) ?>">
                    <div>
                        <span class="details-type"><?= htmlspecialchars($class['class_type']) ?></span>
                        <h3><?= htmlspecialchars($class['subject_name']) ?></h3>
                        <p class="mb-0"><?= htmlspecialchars($class['lecturer_name']) ?></p>
                    </div>
                    <div class="details-actions">
                        <a href="edit_class.php?id=<?= $class['id'] ?>" class="btn btn-light">
                            <i class="fa-solid fa-pen-to-square me-1"></i> Edit
                        </a>
                        <!-- Submit these fields using POST to the PHP handler named in the form action. -->
                        <form method="POST" action="delete_class.php" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this class?');">
                            <!-- Send this record identifier with the form; the server must still check ownership. -->
                            <input type="hidden" name="id" value="<?= $class['id'] ?>">
                            <!-- Submit this form to its PHP handler. -->
                            <button type="submit" class="btn btn-danger">
                                <i class="fa-solid fa-trash me-1"></i> Delete
                            </button>
                        </form>
                    </div>
                </div>

                <div class="class-details-body">
                    <div class="row">
                        <div class="col-md-6 col-lg-3 mb-4">
                            <div class="detail-item">
                                <div class="detail-icon"><i class="fa-regular fa-calendar"></i></div>
                                <div>
                                    <span>Day</span>
                                    <strong><?= htmlspecialchars($class['day']) ?> &mdash; <?= !empty($class['class_date']) ? htmlspecialchars((new DateTimeImmutable($class['class_date']))->format('j M Y')) : 'Repeats weekly' ?></strong>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 col-lg-3 mb-4">
                            <div class="detail-item">
                                <div class="detail-icon"><i class="fa-regular fa-clock"></i></div>
                                <div>
                                    <span>Time</span>
                                    <strong><?= date('g:i A', strtotime($class['start_time'])) ?> - <?= date('g:i A', strtotime($class['end_time'])) ?></strong>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 col-lg-3 mb-4">
                            <div class="detail-item">
                                <div class="detail-icon"><i class="fa-solid fa-location-dot"></i></div>
                                <div>
                                    <span>Room</span>
                                    <strong><?= htmlspecialchars($class['room']) ?></strong>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 col-lg-3 mb-4">
                            <div class="detail-item">
                                <div class="detail-icon"><i class="fa-solid fa-chalkboard-user"></i></div>
                                <div>
                                    <span>Class Type</span>
                                    <strong><?= htmlspecialchars($class['class_type']) ?></strong>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="details-section">
                        <h6><i class="fa-regular fa-user me-2"></i>Lecturer</h6>
                        <p><?= htmlspecialchars($class['lecturer_name']) ?></p>
                    </div>

                    <div class="details-section mb-0">
                        <h6><i class="fa-regular fa-note-sticky me-2"></i>Notes</h6>
                        <p class="mb-0">
                            <?= $class['notes'] ? nl2br(htmlspecialchars($class['notes'])) : '<span class="text-muted">No notes added.</span>' ?>
                        </p>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
</body>
</html>