<?php
/* The dashboard brings together the signed-in student’s record counts, upcoming activity and assignment or exam reminders. */
/* Dashboard overview: loads account-specific counts, upcoming events and due reminders. */
session_start();
require_once '../include/database.php';
require_once '../include/features.php';

// Reject requests that do not have a signed-in user in the session.
if (!isset($_SESSION['user_id'])) {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: ../login.php');
    exit;
}

// Use the session account ID to scope database operations to the current user.
$userId = $_SESSION['user_id'];
$reminderPrefs = cf_feature_ready($pdo) ? cf_preferences($pdo, (int) $userId) : [];
$firstName = $_SESSION['first_name'] ?? 'Student';
$today = date('Y-m-d');
$now = time();

// Decide whether an upcoming event has reached its selected reminder lead time.
function shouldShowReminder(string $date, string $time, string $reminder): bool
{
    if ($reminder === 'none') {
        return false;
    }

    $eventTimestamp = strtotime($date . ' ' . $time);

    if ($eventTimestamp === false || $eventTimestamp < time()) {
        return false;
    }

    if ($reminder === 'same_day') {
        return date('Y-m-d', $eventTimestamp) === date('Y-m-d');
    }

    // Convert the selected reminder interval into seconds before the event.
    $seconds = match ($reminder) {
        '1_day' => 86400,
        '3_days' => 259200,
        '1_week' => 604800,
        default => null
    };

    if ($seconds === null) {
        return false;
    }

    return time() >= ($eventTimestamp - $seconds);
}

// Convert an event date into a short label such as today, tomorrow or in N days.
function getReminderMessage(string $date, string $time): string
{
    $eventTimestamp = strtotime($date . ' ' . $time);
    $today = strtotime(date('Y-m-d'));
    $eventDay = strtotime(date('Y-m-d', $eventTimestamp));
    $days = (int) (($eventDay - $today) / 86400);

    if ($days === 0) {
        return 'today';
    }

    if ($days === 1) {
        return 'tomorrow';
    }

    return 'in ' . $days . ' days';
}

$todayDay = date('l');

// Prepare a lookup of classes using bound parameters. Restrict the query to the current account.
$stmt = $pdo->prepare("
    SELECT COUNT(*)
    FROM classes
    WHERE user_id = ? AND day = ? AND (class_date IS NULL OR class_date = ?)
");
$stmt->execute([$userId, $todayDay, $today]);
$todayClassesCount = (int) $stmt->fetchColumn();

// Prepare a lookup of assignments using bound parameters. Restrict the query to the current account.
$stmt = $pdo->prepare("
    SELECT COUNT(*)
    FROM assignments
    WHERE user_id = ?
    AND status != 'Completed'
    AND CONCAT(due_date, ' ', due_time) >= NOW()
");
$stmt->execute([$userId]);
$pendingAssignmentsCount = (int) $stmt->fetchColumn();

// Prepare a lookup of exams using bound parameters. Restrict the query to the current account.
$stmt = $pdo->prepare("
    SELECT COUNT(*)
    FROM exams
    WHERE user_id = ?
    AND CONCAT(exam_date, ' ', end_time) >= NOW()
");
$stmt->execute([$userId]);
$upcomingExamsCount = (int) $stmt->fetchColumn();

// Prepare a lookup of study sessions using bound parameters. Restrict the query to the current account.
$stmt = $pdo->prepare("
    SELECT COUNT(*)
    FROM study_sessions
    WHERE user_id = ?
    AND status != 'Completed'
    AND CONCAT(study_date, ' ', end_time) >= NOW()
");
$stmt->execute([$userId]);
$studySessionsCount = (int) $stmt->fetchColumn();

// Prepare a lookup of classes using bound parameters. Restrict the query to the current account.
$stmt = $pdo->prepare("
    SELECT *
    FROM classes
    WHERE user_id = ? AND day = ? AND (class_date IS NULL OR class_date = ?)
    ORDER BY start_time ASC
");
$stmt->execute([$userId, $todayDay, $today]);
// Load all matching rows for the list or calculations below.
$todayClasses = $stmt->fetchAll();

// Prepare a lookup of assignments using bound parameters. Restrict the query to the current account.
$stmt = $pdo->prepare("
    SELECT *
    FROM assignments
    WHERE user_id = ?
    AND status != 'Completed'
    AND CONCAT(due_date, ' ', due_time) >= NOW()
    ORDER BY due_date ASC, due_time ASC
    LIMIT 5
");
$stmt->execute([$userId]);
// Load all matching rows for the list or calculations below.
$upcomingAssignments = $stmt->fetchAll();

// Prepare a lookup of exams using bound parameters. Restrict the query to the current account.
$stmt = $pdo->prepare("
    SELECT *
    FROM exams
    WHERE user_id = ?
    AND CONCAT(exam_date, ' ', end_time) >= NOW()
    ORDER BY exam_date ASC, start_time ASC
    LIMIT 5
");
$stmt->execute([$userId]);
// Load all matching rows for the list or calculations below.
$upcomingExams = $stmt->fetchAll();

// Prepare a lookup of study sessions using bound parameters. Restrict the query to the current account.
$stmt = $pdo->prepare("
    SELECT *
    FROM study_sessions
    WHERE user_id = ?
    AND status != 'Completed'
    AND CONCAT(study_date, ' ', end_time) >= NOW()
    ORDER BY study_date ASC, start_time ASC
    LIMIT 5
");
$stmt->execute([$userId]);
// Load all matching rows for the list or calculations below.
$upcomingStudySessions = $stmt->fetchAll();

// Prepare a lookup of assignments using bound parameters. Restrict the query to the current account.
$stmt = $pdo->prepare("
    SELECT id, title, module, due_date, due_time
    FROM assignments
    WHERE user_id = ?
    AND status != 'Completed'
    AND CONCAT(due_date, ' ', due_time) >= NOW()
    ORDER BY due_date ASC, due_time ASC
");
$stmt->execute([$userId]);
// Load all matching rows for the list or calculations below.
$assignmentRows = $stmt->fetchAll();

// Prepare a lookup of exams using bound parameters. Restrict the query to the current account.
$stmt = $pdo->prepare("
    SELECT id, exam_name, module, exam_date, start_time
    FROM exams
    WHERE user_id = ?
    AND CONCAT(exam_date, ' ', start_time) >= NOW()
    ORDER BY exam_date ASC, start_time ASC
");
$stmt->execute([$userId]);
// Load all matching rows for the list or calculations below.
$examRows = $stmt->fetchAll();

$reminders = [];

// Process each item in this collection for the page or response.
foreach ($assignmentRows as $assignment) {
    if (shouldShowReminder($assignment['due_date'], $assignment['due_time'], $reminderPrefs['assignment_reminder'] ?? '1_day')) {
        // Add a reminder with its message, urgency and link to the related record.
        $reminders[] = [
            'type' => 'assignment',
            'title' => $assignment['title'],
            'module' => $assignment['module'],
            'date' => $assignment['due_date'],
            'time' => $assignment['due_time'],
            'timestamp' => strtotime($assignment['due_date'] . ' ' . $assignment['due_time']),
            'url' => 'view_assignment.php?id=' . $assignment['id']
        ];
    }
}

// Process each item in this collection for the page or response.
foreach ($examRows as $exam) {
    if (shouldShowReminder($exam['exam_date'], $exam['start_time'], $reminderPrefs['exam_reminder'] ?? '1_day')) {
        // Add a reminder with its message, urgency and link to the related record.
        $reminders[] = [
            'type' => 'exam',
            'title' => $exam['exam_name'],
            'module' => $exam['module'],
            'date' => $exam['exam_date'],
            'time' => $exam['start_time'],
            'timestamp' => strtotime($exam['exam_date'] . ' ' . $exam['start_time']),
            'url' => 'view_exam.php?id=' . $exam['id']
        ];
    }
}

// Order reminder entries by their event timestamps.
usort($reminders, fn($a, $b) => $a['timestamp'] <=> $b['timestamp']);
?>

<!DOCTYPE html>
<html lang="en">
<!-- Set the page title, character encoding, responsive viewport and stylesheet links. -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | ClassFlow</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=20261103b"><link rel="stylesheet" href="../css/theme.css?v=20261113-red1">
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <?php require_once 'sidebar.php'; ?>

        <!-- Main page content, positioned alongside the sidebar on dashboard pages. -->
        <main class="col-md-9 col-lg-10 p-4 dashboard-content">
            <section class="cf-dashboard-hero">
                <div class="cf-hero-copy">
                    <span class="cf-eyebrow">A little structure. A better day.</span>
                    <h1>Welcome back, <?= htmlspecialchars($firstName) ?>.</h1>
                    <p>Your classes, deadlines and study plans. All in one place.</p>
                    <div class="cf-hero-actions"><a class="btn cf-btn-white" href="calendar.php"><i class="fa-regular fa-calendar me-2" aria-hidden="true"></i>Open calendar</a><a class="btn cf-btn-ghost" href="add_class.php"><i class="fa-solid fa-plus me-2" aria-hidden="true"></i>Add a class</a></div>
                </div>
                <div class="cf-hero-date"><span><?= date('l') ?></span><strong><?= date('d') ?></strong><span><?= date('F Y') ?></span></div>
            </section>
            <div class="cf-section-heading"><h2>Your day at a glance</h2><span>Make room for what matters.</span></div>

            <?php if (!empty($reminders)): ?>
                <div class="mb-4">
                    <h5 class="mb-3">
                        <i class="fa-solid fa-bell me-2 text-warning"></i>Reminders
                    </h5>

                    <?php foreach ($reminders as $reminder): ?>
                        <?php $when = getReminderMessage($reminder['date'], $reminder['time']); ?>

                        <?php if ($reminder['type'] === 'assignment'): ?>
                            <a href="<?= htmlspecialchars($reminder['url']) ?>" class="text-decoration-none">
                                <div class="alert alert-warning d-flex align-items-center mb-2">
                                    <i class="fa-solid fa-triangle-exclamation me-3"></i>
                                    <div>
                                        <strong>Assignment due <?= htmlspecialchars($when) ?>:</strong>
                                        <?= htmlspecialchars($reminder['title']) ?>
                                        <span class="ms-1">— <?= date('g:i A', strtotime($reminder['time'])) ?></span>
                                    </div>
                                </div>
                            </a>
                        <?php else: ?>
                            <a href="<?= htmlspecialchars($reminder['url']) ?>" class="text-decoration-none">
                                <div class="alert alert-info d-flex align-items-center mb-2">
                                    <i class="fa-solid fa-bell me-3"></i>
                                    <div>
                                        <strong>Exam <?= htmlspecialchars($when) ?>:</strong>
                                        <?= htmlspecialchars($reminder['title']) ?>
                                        <span class="ms-1">— <?= date('g:i A', strtotime($reminder['time'])) ?></span>
                                    </div>
                                </div>
                            </a>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <div class="row g-3 mb-4">
                <div class="col-md-6 col-xl-3">
                    <a href="timetable.php" class="dashboard-stat-card cf-stat-0">
                        <div>
                            <span>Today's Classes</span>
                            <h3><?= $todayClassesCount ?></h3>
                        </div>
                        <div class="dashboard-stat-icon class-icon">
                            <i class="fa-solid fa-calendar-days"></i>
                        </div><span class="cf-card-arrow" aria-hidden="true">↗</span></a></div>

                <div class="col-md-6 col-xl-3">
                    <a href="assignments.php" class="dashboard-stat-card cf-stat-1">
                        <div>
                            <span>Pending Assignments</span>
                            <h3><?= $pendingAssignmentsCount ?></h3>
                        </div>
                        <div class="dashboard-stat-icon assignment-icon">
                            <i class="fa-solid fa-list-check"></i>
                        </div><span class="cf-card-arrow" aria-hidden="true">↗</span></a></div>

                <div class="col-md-6 col-xl-3">
                    <a href="exams.php" class="dashboard-stat-card cf-stat-2">
                        <div>
                            <span>Upcoming Exams</span>
                            <h3><?= $upcomingExamsCount ?></h3>
                        </div>
                        <div class="dashboard-stat-icon exam-icon">
                            <i class="fa-solid fa-book-open"></i>
                        </div><span class="cf-card-arrow" aria-hidden="true">↗</span></a></div>

                <div class="col-md-6 col-xl-3">
                    <a href="study_planner.php" class="dashboard-stat-card cf-stat-3">
                        <div>
                            <span>Study Sessions</span>
                            <h3><?= $studySessionsCount ?></h3>
                        </div>
                        <div class="dashboard-stat-icon study-icon">
                            <i class="fa-solid fa-clock"></i>
                        </div><span class="cf-card-arrow" aria-hidden="true">↗</span></a></div>
            </div>

            <div class="row g-4 mb-4">
                <div class="col-lg-6">
                    <div class="dashboard-section">
                        <div class="dashboard-section-header">
                            <div>
                                <h5>Today's Classes</h5>
                                <p>Your classes scheduled for <?= htmlspecialchars($todayDay) ?>.</p>
                            </div>
                            <a href="timetable.php">View Timetable</a>
                        </div>

                        <?php if (!empty($todayClasses)): ?>
                            <?php foreach ($todayClasses as $class): ?>
                                <a href="view_class.php?id=<?= (int) $class['id'] ?>" class="dashboard-event-item">
                                    <div class="dashboard-event-icon class-event">
                                        <i class="fa-solid fa-graduation-cap"></i>
                                    </div>
                                    <div class="flex-grow-1">
                                        <h6><?= htmlspecialchars($class['subject_name']) ?></h6>
                                        <p><?= htmlspecialchars($class['class_type']) ?> · <?= htmlspecialchars($class['room']) ?></p>
                                    </div>
                                    <div class="dashboard-event-time">
                                        <?= date('g:i A', strtotime($class['start_time'])) ?>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="dashboard-empty">
                                <i class="fa-regular fa-calendar-check"></i>
                                <p>No classes scheduled today.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="dashboard-section">
                        <div class="dashboard-section-header">
                            <div>
                                <h5>Upcoming Assignments</h5>
                                <p>Your nearest coursework deadlines.</p>
                            </div>
                            <a href="assignments.php">View All</a>
                        </div>

                        <?php if (!empty($upcomingAssignments)): ?>
                            <?php foreach ($upcomingAssignments as $assignment): ?>
                                <a href="view_assignment.php?id=<?= (int) $assignment['id'] ?>" class="dashboard-event-item">
                                    <div class="dashboard-event-icon assignment-event">
                                        <i class="fa-solid fa-list-check"></i>
                                    </div>
                                    <div class="flex-grow-1">
                                        <h6><?= htmlspecialchars($assignment['title']) ?></h6>
                                        <p><?= htmlspecialchars($assignment['module']) ?></p>
                                    </div>
                                    <div class="dashboard-event-date">
                                        <strong><?= date('d M', strtotime($assignment['due_date'])) ?></strong>
                                        <span><?= date('g:i A', strtotime($assignment['due_time'])) ?></span>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="dashboard-empty">
                                <i class="fa-regular fa-circle-check"></i>
                                <p>No upcoming assignments.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="row g-4">
                <div class="col-lg-6">
                    <div class="dashboard-section">
                        <div class="dashboard-section-header">
                            <div>
                                <h5>Upcoming Exams</h5>
                                <p>Your next scheduled examinations.</p>
                            </div>
                            <a href="exams.php">View All</a>
                        </div>

                        <?php if (!empty($upcomingExams)): ?>
                            <?php foreach ($upcomingExams as $exam): ?>
                                <a href="view_exam.php?id=<?= (int) $exam['id'] ?>" class="dashboard-event-item">
                                    <div class="dashboard-event-icon exam-event">
                                        <i class="fa-solid fa-book-open"></i>
                                    </div>
                                    <div class="flex-grow-1">
                                        <h6><?= htmlspecialchars($exam['exam_name']) ?></h6>
                                        <p><?= htmlspecialchars($exam['module']) ?> · <?= htmlspecialchars($exam['location']) ?></p>
                                    </div>
                                    <div class="dashboard-event-date">
                                        <strong><?= date('d M', strtotime($exam['exam_date'])) ?></strong>
                                        <span><?= date('g:i A', strtotime($exam['start_time'])) ?></span>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="dashboard-empty">
                                <i class="fa-regular fa-calendar-check"></i>
                                <p>No upcoming exams.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="dashboard-section">
                        <div class="dashboard-section-header">
                            <div>
                                <h5>Upcoming Study Sessions</h5>
                                <p>Your planned study activities.</p>
                            </div>
                            <a href="study_planner.php">View Planner</a>
                        </div>

                        <?php if (!empty($upcomingStudySessions)): ?>
                            <?php foreach ($upcomingStudySessions as $study): ?>
                                <a href="view_study_session.php?id=<?= (int) $study['id'] ?>" class="dashboard-event-item">
                                    <div class="dashboard-event-icon study-event">
                                        <i class="fa-solid fa-clock"></i>
                                    </div>
                                    <div class="flex-grow-1">
                                        <h6><?= htmlspecialchars($study['topic']) ?></h6>
                                        <p><?= htmlspecialchars($study['module']) ?></p>
                                    </div>
                                    <div class="dashboard-event-date">
                                        <strong><?= date('d M', strtotime($study['study_date'])) ?></strong>
                                        <span><?= date('g:i A', strtotime($study['start_time'])) ?></span>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="dashboard-empty">
                                <i class="fa-regular fa-calendar"></i>
                                <p>No upcoming study sessions.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
</body>
</html>
