<?php
/* The exam list presents the next scheduled assessment and the student’s other exams, with links to each record. */
/* Exam list: loads the user's exams and calculates schedule summary counts. */
session_start();
require_once '../include/database.php';

// Reject requests that do not have a signed-in user in the session.
if (!isset($_SESSION['user_id'])) {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: ../login.php');
    exit;
}

// Use the session account ID to scope database operations to the current user.
$userId = $_SESSION['user_id'];
$successMessage = '';
$errorMessage = '';

// Read this session value only when it exists.
if (isset($_SESSION['success_message'])) {
    $successMessage = $_SESSION['success_message'];
    // Remove the flash message so it is displayed only once.
    unset($_SESSION['success_message']);
}

// Read this session value only when it exists.
if (isset($_SESSION['error_message'])) {
    $errorMessage = $_SESSION['error_message'];
    // Remove the flash message so it is displayed only once.
    unset($_SESSION['error_message']);
}

// Prepare a lookup of exams using bound parameters. Restrict the query to the current account.
$stmt = $pdo->prepare("
    SELECT *
    FROM exams
    WHERE user_id = ?
    ORDER BY exam_date ASC, start_time ASC
");
$stmt->execute([$userId]);
// Load all matching rows for the list or calculations below.
$exams = $stmt->fetchAll();

$totalExams = count($exams);
$upcomingExams = 0;
$completedExams = 0;
$nextExam = null;
$now = time();

// Process each item in this collection for the page or response.
foreach ($exams as $exam) {
    $examEnd = strtotime($exam['exam_date'] . ' ' . $exam['end_time']);

    if ($examEnd >= $now) {
        $upcomingExams++;

        if ($nextExam === null) {
            $nextExam = $exam;
        }
    } else {
        $completedExams++;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<!-- Set the page title, character encoding, responsive viewport and stylesheet links. -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exams | ClassFlow</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=20261103b"><link rel="stylesheet" href="../css/theme.css?v=20261113-red1">
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <?php require_once 'sidebar.php'; ?>

        <!-- Main page content, positioned alongside the sidebar on dashboard pages. -->
        <main class="col-md-9 col-lg-10 p-4 dashboard-content">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="page-title mb-1">Exams</h2>
                    <p class="text-muted mb-0">Manage examination dates, times and locations.</p>
                </div>
                <a href="add_exam.php" class="btn btn-add">
                    <i class="fa-solid fa-plus me-1"></i> Add Exam
                </a>
            </div>

            <?php if ($successMessage): ?>
                <div class="alert alert-success"><?= htmlspecialchars($successMessage) ?></div>
            <?php endif; ?>

            <?php if ($errorMessage): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($errorMessage) ?></div>
            <?php endif; ?>

            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <div class="exam-stat-card">
                        <div class="exam-stat-icon total">
                            <i class="fa-solid fa-file-pen"></i>
                        </div>
                        <div>
                            <span>Total Exams</span>
                            <h3><?= $totalExams ?></h3>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="exam-stat-card">
                        <div class="exam-stat-icon upcoming">
                            <i class="fa-regular fa-calendar"></i>
                        </div>
                        <div>
                            <span>Upcoming Exams</span>
                            <h3><?= $upcomingExams ?></h3>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="exam-stat-card">
                        <div class="exam-stat-icon completed">
                            <i class="fa-solid fa-check"></i>
                        </div>
                        <div>
                            <span>Past Exams</span>
                            <h3><?= $completedExams ?></h3>
                        </div>
                    </div>
                </div>
            </div>

            <?php if ($nextExam): ?>
                <div class="next-exam-card mb-4">
                    <div class="next-exam-icon">
                        <i class="fa-solid fa-graduation-cap"></i>
                    </div>
                    <div class="flex-grow-1">
                        <span class="next-label">NEXT EXAM</span>
                        <h5><?= htmlspecialchars($nextExam['exam_name']) ?></h5>
                        <p class="mb-0">
                            <?= htmlspecialchars($nextExam['module']) ?> ·
                            <?= date('d M Y', strtotime($nextExam['exam_date'])) ?> ·
                            <?= date('g:i A', strtotime($nextExam['start_time'])) ?>
                        </p>
                    </div>
                    <a href="view_exam.php?id=<?= $nextExam['id'] ?>" class="btn btn-outline-primary">View Details</a>
                </div>
            <?php endif; ?>

            <div class="table-card">
                <div class="mb-3">
                    <h5 class="fw-bold mb-1">My Exams</h5>
                    <p class="text-muted small mb-0">Your examination schedule</p>
                </div>

                <div class="table-responsive">
                    <!-- Display the loaded records in a table with headings and row actions. -->
                    <table class="table exam-table align-middle mb-0">
                        <!-- Column headings describe the values displayed in each record row. -->
                        <thead>
                            <tr>
                                <th>Exam</th>
                                <th>Module</th>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Location</th>
                                <th>Type</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <!-- Render the record rows and any empty-state message. -->
                        <tbody>
                            <?php if ($exams): ?>
                                <?php foreach ($exams as $exam): ?>
                                    <?php
                                    $examEnd = strtotime($exam['exam_date'] . ' ' . $exam['end_time']);
                                    $isPast = $examEnd < time();
                                    ?>
                                    <tr class="<?= $isPast ? 'past-exam' : '' ?>">
                                        <td>
                                            <a href="view_exam.php?id=<?= $exam['id'] ?>" class="exam-title">
                                                <?= htmlspecialchars($exam['exam_name']) ?>
                                            </a>
                                        </td>
                                        <td><?= htmlspecialchars($exam['module']) ?></td>
                                        <td>
                                            <?= date('d M Y', strtotime($exam['exam_date'])) ?>
                                            <?php if ($isPast): ?>
                                                <small class="d-block text-muted">Past</small>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?= date('g:i A', strtotime($exam['start_time'])) ?> -
                                            <?= date('g:i A', strtotime($exam['end_time'])) ?>
                                        </td>
                                        <td><?= htmlspecialchars($exam['location']) ?></td>
                                        <td>
                                            <span class="exam-type-badge">
                                                <?= htmlspecialchars($exam['exam_type']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="d-flex gap-1">
                                                <a href="view_exam.php?id=<?= $exam['id'] ?>" class="btn btn-sm btn-info text-white" title="View">
                                                    <i class="fa-solid fa-eye"></i>
                                                </a>
                                                <a href="edit_exam.php?id=<?= $exam['id'] ?>" class="btn btn-sm btn-warning" title="Edit">
                                                    <i class="fa-solid fa-pen-to-square"></i>
                                                </a>
                                                <!-- Submit these fields using POST to the PHP handler named in the form action. -->
                                                <form method="POST" action="delete_exam.php" onsubmit="return confirm('Are you sure you want to delete this exam?');">
                                                    <!-- Send this record identifier with the form; the server must still check ownership. -->
                                                    <input type="hidden" name="id" value="<?= $exam['id'] ?>">
                                                    <!-- Submit this form to its PHP handler. -->
                                                    <button type="submit" class="btn btn-sm btn-danger" title="Delete">
                                                        <i class="fa-solid fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="text-center py-5">
                                        <i class="fa-solid fa-graduation-cap fa-2x text-muted mb-3"></i>
                                        <p class="text-muted mb-2">No exams have been added yet.</p>
                                        <a href="add_exam.php" class="btn btn-add btn-sm">Add Your First Exam</a>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</div>
</body>
</html>