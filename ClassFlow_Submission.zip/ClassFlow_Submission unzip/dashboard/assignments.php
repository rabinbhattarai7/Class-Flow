<?php
/* The assignment list shows deadlines, priorities and progress for the signed-in student so they can identify work that needs attention. */
/* Assignment list: loads the user's coursework and calculates completion and deadline counts. */
session_start();
require_once '../include/database.php';

// Reject requests that do not have a signed-in user in the session.
if (!isset($_SESSION['user_id'])) {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: ../login.php');
    exit;
}

// Use the session account ID to scope database operations to the current user.
$userId = $_SESSION['user_id'];
$successMessage = '';
$errorMessage = '';

// Read this session value only when it exists.
if (isset($_SESSION['success_message'])) {
    $successMessage = $_SESSION['success_message'];
    // Remove the flash message so it is displayed only once.
    unset($_SESSION['success_message']);
}

// Read this session value only when it exists.
if (isset($_SESSION['error_message'])) {
    $errorMessage = $_SESSION['error_message'];
    // Remove the flash message so it is displayed only once.
    unset($_SESSION['error_message']);
}

// Prepare a lookup of assignments using bound parameters. Restrict the query to the current account.
$stmt = $pdo->prepare("
    SELECT *
    FROM assignments
    WHERE user_id = ?
    ORDER BY
        CASE WHEN status = 'Completed' THEN 1 ELSE 0 END,
        due_date ASC,
        due_time ASC
");
$stmt->execute([$userId]);
// Load all matching rows for the list or calculations below.
$assignments = $stmt->fetchAll();

$totalAssignments = count($assignments);
$completedAssignments = 0;
$upcomingAssignments = 0;
$overdueAssignments = 0;

// Process each item in this collection for the page or response.
foreach ($assignments as $assignment) {
    if ($assignment['status'] === 'Completed') {
        $completedAssignments++;
        continue;
    }

    $dueDateTime = strtotime($assignment['due_date'] . ' ' . $assignment['due_time']);

    if ($dueDateTime < time()) {
        $overdueAssignments++;
    } else {
        $upcomingAssignments++;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<!-- Set the page title, character encoding, responsive viewport and stylesheet links. -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignments | ClassFlow</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=20261103b"><link rel="stylesheet" href="../css/theme.css?v=20261113-red1">
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <?php require_once 'sidebar.php'; ?>

        <!-- Main page content, positioned alongside the sidebar on dashboard pages. -->
        <main class="col-md-9 col-lg-10 p-4 dashboard-content">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="page-title mb-1">Assignments</h2>
                    <p class="text-muted mb-0">Manage coursework and keep track of deadlines.</p>
                </div>
                <a href="add_assignment.php" class="btn btn-add">
                    <i class="fa-solid fa-plus me-1"></i> Add Assignment
                </a>
            </div>

            <?php if ($successMessage): ?>
                <div class="alert alert-success"><?= htmlspecialchars($successMessage) ?></div>
            <?php endif; ?>

            <?php if ($errorMessage): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($errorMessage) ?></div>
            <?php endif; ?>

            <div class="row g-3 mb-4">
                <div class="col-md-6 col-xl-3">
                    <div class="assignment-stat-card">
                        <div class="stat-icon total"><i class="fa-solid fa-list-check"></i></div>
                        <div>
                            <span>Total Assignments</span>
                            <h3><?= $totalAssignments ?></h3>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 col-xl-3">
                    <div class="assignment-stat-card">
                        <div class="stat-icon upcoming"><i class="fa-regular fa-clock"></i></div>
                        <div>
                            <span>Upcoming</span>
                            <h3><?= $upcomingAssignments ?></h3>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 col-xl-3">
                    <div class="assignment-stat-card">
                        <div class="stat-icon completed"><i class="fa-solid fa-check"></i></div>
                        <div>
                            <span>Completed</span>
                            <h3><?= $completedAssignments ?></h3>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 col-xl-3">
                    <div class="assignment-stat-card">
                        <div class="stat-icon overdue"><i class="fa-solid fa-triangle-exclamation"></i></div>
                        <div>
                            <span>Overdue</span>
                            <h3><?= $overdueAssignments ?></h3>
                        </div>
                    </div>
                </div>
            </div>

            <div class="table-card">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div>
                        <h5 class="fw-bold mb-1">My Assignments</h5>
                        <p class="text-muted small mb-0">Coursework and submission deadlines</p>
                    </div>
                </div>

                <div class="table-responsive">
                    <!-- Display the loaded records in a table with headings and row actions. -->
                    <table class="table assignment-table align-middle mb-0">
                        <!-- Column headings describe the values displayed in each record row. -->
                        <thead>
                            <tr>
                                <th>Assignment</th>
                                <th>Module</th>
                                <th>Due</th>
                                <th>Priority</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <!-- Render the record rows and any empty-state message. -->
                        <tbody>
                            <?php if ($assignments): ?>
                                <?php foreach ($assignments as $assignment): ?>
                                    <?php
                                    $dueDateTime = strtotime($assignment['due_date'] . ' ' . $assignment['due_time']);
                                    $isOverdue = $assignment['status'] !== 'Completed' && $dueDateTime < time();
                                    ?>
                                    <tr>
                                        <td>
                                            <a href="view_assignment.php?id=<?= $assignment['id'] ?>" class="assignment-title">
                                                <?= htmlspecialchars($assignment['title']) ?>
                                            </a>
                                        </td>

                                        <td><?= htmlspecialchars($assignment['module']) ?></td>

                                        <td>
                                            <div class="<?= $isOverdue ? 'text-danger fw-semibold' : '' ?>">
                                                <?= date('d M Y', strtotime($assignment['due_date'])) ?>
                                            </div>
                                            <small class="text-muted"><?= date('g:i A', strtotime($assignment['due_time'])) ?></small>
                                            <?php if ($isOverdue): ?>
                                                <small class="d-block text-danger">Overdue</small>
                                            <?php endif; ?>
                                        </td>

                                        <td>
                                            <span class="priority-badge <?= strtolower($assignment['priority']) ?>">
                                                <?= htmlspecialchars($assignment['priority']) ?>
                                            </span>
                                        </td>

                                        <td>
                                            <span class="status-badge <?= strtolower(str_replace(' ', '-', $assignment['status'])) ?>">
                                                <?= htmlspecialchars($assignment['status']) ?>
                                            </span>
                                        </td>

                                        <td>
                                            <div class="d-flex gap-1">
                                                <a href="view_assignment.php?id=<?= $assignment['id'] ?>" class="btn btn-sm btn-info text-white" title="View">
                                                    <i class="fa-solid fa-eye"></i>
                                                </a>

                                                <a href="edit_assignment.php?id=<?= $assignment['id'] ?>" class="btn btn-sm btn-warning" title="Edit">
                                                    <i class="fa-solid fa-pen-to-square"></i>
                                                </a>

                                                <?php if ($assignment['status'] !== 'Completed'): ?>
                                                    <!-- Submit these fields using POST to the PHP handler named in the form action. -->
                                                    <form method="POST" action="complete_assignment.php">
                                                        <!-- Send this record identifier with the form; the server must still check ownership. -->
                                                        <input type="hidden" name="id" value="<?= $assignment['id'] ?>">
                                                        <!-- Submit this form to its PHP handler. -->
                                                        <button type="submit" class="btn btn-sm btn-success" title="Mark Completed">
                                                            <i class="fa-solid fa-check"></i>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>

                                                <!-- Submit these fields using POST to the PHP handler named in the form action. -->
                                                <form method="POST" action="delete_assignment.php" onsubmit="return confirm('Are you sure you want to delete this assignment?');">
                                                    <!-- Send this record identifier with the form; the server must still check ownership. -->
                                                    <input type="hidden" name="id" value="<?= $assignment['id'] ?>">
                                                    <!-- Submit this form to its PHP handler. -->
                                                    <button type="submit" class="btn btn-sm btn-danger" title="Delete">
                                                        <i class="fa-solid fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center py-5">
                                        <i class="fa-solid fa-list-check fa-2x text-muted mb-3"></i>
                                        <p class="text-muted mb-2">No assignments have been added yet.</p>
                                        <a href="add_assignment.php" class="btn btn-add btn-sm">Add Your First Assignment</a>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</div>
</body>
</html>