<?php
/* This form validates a date, start and end times, and assessment details before saving a new exam under the signed-in student’s account. */
/* Validates submitted fields and saves a new exam. */
session_start();
require_once '../include/database.php';
require_once '../include/features.php';

// Reject requests that do not have a signed-in user in the session.
if (!isset($_SESSION['user_id'])) {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: ../login.php');
    exit;
}

// Use the session account ID to scope database operations to the current user.
$userId = $_SESSION['user_id'];
$message = '';

$examName = '';
$module = '';
$examDate = '';
$startTime = '';
$endTime = '';
$location = '';
$examType = '';
$notes = '';

// Restore an unsaved conflict draft without saving anything.
foreach (cf_draft_restore((int)$userId, 'exam', 0) as $field => $value) {
    $variable = cf_draft_fields('exam')[$field] ?? null;
    if ($variable !== null) $variable = $value;
}

// Process submitted form values only on a POST request.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    cf_check_csrf();
    $examName = trim($_POST['exam_name'] ?? '');
    $module = trim($_POST['module'] ?? '');
    $examDate = trim($_POST['exam_date'] ?? '');
    $startTime = trim($_POST['start_time'] ?? '');
    $endTime = trim($_POST['end_time'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $examType = trim($_POST['exam_type'] ?? '');
    $notes = trim($_POST['notes'] ?? '');

    // Define the values accepted by the server for this selection field.
    $validExamTypes = ['Written', 'Practical', 'Online', 'Oral'];
    // Define the values accepted by the server for this selection field.

    // Validate required values before continuing with database changes.
    if ($examName === '' || $module === '' || $examDate === '' || $startTime === '' || $endTime === '' || $location === '' || $examType === '') {
        $message = '<div class="alert alert-danger">Please fill in all required fields.</div>';
    } elseif (!in_array($examType, $validExamTypes, true)) {
        $message = '<div class="alert alert-danger">Please select a valid exam type.</div>';
    } elseif ($startTime >= $endTime) {
        $message = '<div class="alert alert-danger">End time must be later than start time.</div>';
    } elseif (($scheduleConflict = cf_schedule_conflict($pdo, (int) $userId, 'exam', $examDate, $startTime, $endTime, 0)) && !cf_is_schedule_overlap($scheduleConflict)) {
        $message = '<div class="alert alert-danger">' . cf_escape($scheduleConflict) . '</div>';
    } else {
        // Prepare a new exams record using placeholders for submitted values.
        $stmt = $pdo->prepare("
            INSERT INTO exams (user_id, exam_name, module, exam_date, start_time, end_time, location, exam_type, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        if ($stmt->execute([$userId, $examName, $module, $examDate, $startTime, $endTime, $location, $examType, $notes])) {
            cf_draft_clear((int)$userId, 'exam', 0);
                $_SESSION['success_message'] = 'Exam added successfully.';
                cf_saved_conflict_redirect($pdo, (int)$userId, 'exam', (int)$pdo->lastInsertId(), $_POST, $scheduleConflict ?? null);
            // Redirect the browser after processing; exit below stops further output.
            header('Location: exams.php');
            exit;
        }

        $message = '<div class="alert alert-danger">Unable to add exam. Please try again.</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<!-- Set the page title, character encoding, responsive viewport and stylesheet links. -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Exam | ClassFlow</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=20261103b"><link rel="stylesheet" href="../css/theme.css?v=20261113-red1">
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <?php require_once 'sidebar.php'; ?>

        <!-- Main page content, positioned alongside the sidebar on dashboard pages. -->
        <main class="col-md-9 col-lg-10 p-4 dashboard-content">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="page-title mb-1">Add Exam</h2>
                    <p class="text-muted mb-0">Add an upcoming examination to your schedule.</p>
                </div>
                <a href="exams.php" class="btn btn-outline-secondary">
                    <i class="fa-solid fa-arrow-left me-1"></i> Back
                </a>
            </div>

            <?= $message ?>

            <div class="form-card">
                <!-- Submit these fields using POST to the PHP handler named in the form action. -->
                <form method="POST">
                    <input type="hidden" name="csrf" value="<?= cf_csrf_token() ?>">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <!-- Input field: Exam Name. -->
                            <label for="exam_name" class="form-label">Exam Name</label>
                            <input type="text" class="form-control" id="exam_name" name="exam_name" value="<?= htmlspecialchars($examName) ?>" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <!-- Input field: Module. -->
                            <label for="module" class="form-label">Module</label>
                            <input type="text" class="form-control" id="module" name="module" value="<?= htmlspecialchars($module) ?>" required>
                        </div>

                        <div class="col-md-4 mb-3">
                            <!-- Input field: Exam Date. -->
                            <label for="exam_date" class="form-label">Exam Date</label>
                            <input type="date" class="form-control" id="exam_date" name="exam_date" value="<?= htmlspecialchars($examDate) ?>" required>
                        </div>

                        <div class="col-md-4 mb-3">
                            <!-- Input field: Start Time. -->
                            <label for="start_time" class="form-label">Start Time</label>
                            <input type="time" class="form-control" id="start_time" name="start_time" value="<?= htmlspecialchars($startTime) ?>" required>
                        </div>

                        <div class="col-md-4 mb-3">
                            <!-- Input field: End Time. -->
                            <label for="end_time" class="form-label">End Time</label>
                            <input type="time" class="form-control" id="end_time" name="end_time" value="<?= htmlspecialchars($endTime) ?>" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <!-- Input field: Location. -->
                            <label for="location" class="form-label">Location</label>
                            <input type="text" class="form-control" id="location" name="location" value="<?= htmlspecialchars($location) ?>" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <!-- Input field: Exam Type. -->
                            <label for="exam_type" class="form-label">Exam Type</label>
                            <select class="form-select" id="exam_type" name="exam_type" required>
                                <option value="">Select exam type</option>
                                <option value="Written" <?= $examType === 'Written' ? 'selected' : '' ?>>Written</option>
                                <option value="Practical" <?= $examType === 'Practical' ? 'selected' : '' ?>>Practical</option>
                                <option value="Online" <?= $examType === 'Online' ? 'selected' : '' ?>>Online</option>
                                <option value="Oral" <?= $examType === 'Oral' ? 'selected' : '' ?>>Oral</option>
                            </select>
                        </div>


                        <div class="col-12 mb-3">
                            <label for="notes" class="form-label">Notes <span class="text-muted">(Optional)</span></label>
                            <textarea class="form-control" id="notes" name="notes" rows="4"><?= htmlspecialchars($notes) ?></textarea>
                        </div>
                    </div>

                    <!-- Submit this form to its PHP handler. -->
                    <button type="submit" class="btn btn-save">
                        <i class="fa-solid fa-plus me-1"></i> Add Exam
                    </button>
                </form>
            </div>
        </main>
    </div>
</div>
</body>
</html>