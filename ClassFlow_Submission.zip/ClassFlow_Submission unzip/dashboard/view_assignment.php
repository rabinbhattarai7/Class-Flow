<?php
/* The details page reads one assignment using both the record number and the signed-in student’s account number. */
/* Loads and displays the signed-in user's assignment. */
session_start();
require_once '../include/database.php';

// Reject requests that do not have a signed-in user in the session.
if (!isset($_SESSION['user_id'])) {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: ../login.php');
    exit;
}

// Use the session account ID to scope database operations to the current user.
$userId = $_SESSION['user_id'];
// Read the requested record ID and require a valid integer.
$assignmentId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$assignmentId) {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: assignments.php');
    exit;
}

// Prepare a lookup of assignments using bound parameters. Restrict the query to the current account.
$stmt = $pdo->prepare("SELECT * FROM assignments WHERE id = ? AND user_id = ?");
$stmt->execute([$assignmentId, $userId]);
// Read the matching record; false means no row was found.
$assignment = $stmt->fetch();

if (!$assignment) {
    $_SESSION['error_message'] = 'Assignment not found.';
    // Redirect the browser after processing; exit below stops further output.
    header('Location: assignments.php');
    exit;
}

$dueDateTime = strtotime($assignment['due_date'] . ' ' . $assignment['due_time']);
$isOverdue = $assignment['status'] !== 'Completed' && $dueDateTime < time();
?>

<!DOCTYPE html>
<html lang="en">
<!-- Set the page title, character encoding, responsive viewport and stylesheet links. -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($assignment['title']) ?> | ClassFlow</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=20261103b"><link rel="stylesheet" href="../css/theme.css?v=20261113-red1">
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <?php require_once 'sidebar.php'; ?>

        <!-- Main page content, positioned alongside the sidebar on dashboard pages. -->
        <main class="col-md-9 col-lg-10 p-4 dashboard-content">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="page-title mb-1">Assignment Details</h2>
                    <p class="text-muted mb-0">View your coursework information and deadline.</p>
                </div>
                <a href="assignments.php" class="btn btn-outline-secondary">
                    <i class="fa-solid fa-arrow-left me-1"></i> Back
                </a>
            </div>

            <div class="assignment-details-card">
                <div class="assignment-details-header">
                    <div>
                        <span class="priority-badge <?= strtolower($assignment['priority']) ?>">
                            <?= htmlspecialchars($assignment['priority']) ?> Priority
                        </span>

                        <h3><?= htmlspecialchars($assignment['title']) ?></h3>

                        <p class="mb-0">
                            <i class="fa-solid fa-book me-1"></i>
                            <?= htmlspecialchars($assignment['module']) ?>
                        </p>
                    </div>

                    <div class="details-actions">
                        <a href="edit_assignment.php?id=<?= $assignment['id'] ?>" class="btn btn-light">
                            <i class="fa-solid fa-pen-to-square me-1"></i> Edit
                        </a>

                        <?php if ($assignment['status'] !== 'Completed'): ?>
                            <!-- Submit these fields using POST to the PHP handler named in the form action. -->
                            <form method="POST" action="complete_assignment.php">
                                <!-- Send this record identifier with the form; the server must still check ownership. -->
                                <input type="hidden" name="id" value="<?= $assignment['id'] ?>">
                                <!-- Submit this form to its PHP handler. -->
                                <button type="submit" class="btn btn-success">
                                    <i class="fa-solid fa-check me-1"></i> Complete
                                </button>
                            </form>
                        <?php endif; ?>

                        <!-- Submit these fields using POST to the PHP handler named in the form action. -->
                        <form method="POST" action="delete_assignment.php" onsubmit="return confirm('Are you sure you want to delete this assignment?');">
                            <!-- Send this record identifier with the form; the server must still check ownership. -->
                            <input type="hidden" name="id" value="<?= $assignment['id'] ?>">
                            <!-- Submit this form to its PHP handler. -->
                            <button type="submit" class="btn btn-danger">
                                <i class="fa-solid fa-trash me-1"></i> Delete
                            </button>
                        </form>
                    </div>
                </div>

                <div class="assignment-details-body">
                    <div class="row">
                        <div class="col-md-6 col-lg-3 mb-4">
                            <div class="detail-item">
                                <div class="detail-icon">
                                    <i class="fa-regular fa-calendar"></i>
                                </div>
                                <div>
                                    <span>Due Date</span>
                                    <strong><?= date('d M Y', strtotime($assignment['due_date'])) ?></strong>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 col-lg-3 mb-4">
                            <div class="detail-item">
                                <div class="detail-icon">
                                    <i class="fa-regular fa-clock"></i>
                                </div>
                                <div>
                                    <span>Due Time</span>
                                    <strong><?= date('g:i A', strtotime($assignment['due_time'])) ?></strong>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 col-lg-3 mb-4">
                            <div class="detail-item">
                                <div class="detail-icon">
                                    <i class="fa-solid fa-flag"></i>
                                </div>
                                <div>
                                    <span>Priority</span>
                                    <strong><?= htmlspecialchars($assignment['priority']) ?></strong>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 col-lg-3 mb-4">
                            <div class="detail-item">
                                <div class="detail-icon">
                                    <i class="fa-solid fa-circle-check"></i>
                                </div>
                                <div>
                                    <span>Status</span>
                                    <strong><?= htmlspecialchars($assignment['status']) ?></strong>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php if ($isOverdue): ?>
                        <div class="alert alert-danger mb-4">
                            <i class="fa-solid fa-triangle-exclamation me-2"></i>
                            This assignment is overdue.
                        </div>
                    <?php endif; ?>

                    <div class="details-section">
                        <h6><i class="fa-solid fa-book me-2"></i>Module</h6>
                        <p><?= htmlspecialchars($assignment['module']) ?></p>
                    </div>

                    <div class="details-section mb-0">
                        <h6><i class="fa-regular fa-file-lines me-2"></i>Description</h6>
                        <p class="mb-0">
                            <?= $assignment['description'] ? nl2br(htmlspecialchars($assignment['description'])) : '<span class="text-muted">No description added.</span>' ?>
                        </p>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
</body>
</html>