<?php
/* The calendar loads the visible date range from the calendar endpoint and presents each kind of academic activity with its own colour and detail link. */
/* Calendar page: displays events from calendar_events.php using FullCalendar. */
session_start();

// Reject requests that do not have a signed-in user in the session.
if (!isset($_SESSION['user_id'])) {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: ../login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<!-- Set the page title, character encoding, responsive viewport and stylesheet links. -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Calendar | ClassFlow</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.19/index.global.min.js"></script>

    <link rel="stylesheet" href="style.css?v=20261103b"><link rel="stylesheet" href="../css/theme.css?v=20261113-red1">
</head>

<body>
<div class="container-fluid">
    <div class="row">

        <?php require_once 'sidebar.php'; ?>

        <!-- Main page content, positioned alongside the sidebar on dashboard pages. -->
        <main class="col-md-9 col-lg-10 p-4 dashboard-content">

            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="page-title mb-1">Calendar</h2>
                    <p class="text-muted mb-0">
                        View your classes, assignments, exams and study sessions in one place.
                    </p>
                </div>
            </div>

            <div class="calendar-legend mb-3">
                <span>
                    <i class="calendar-dot class-dot"></i>
                    Classes
                </span>

                <span>
                    <i class="calendar-dot assignment-dot"></i>
                    Assignments
                </span>

                <span>
                    <i class="calendar-dot exam-dot"></i>
                    Exams
                </span>

                <span>
                    <i class="calendar-dot study-dot"></i>
                    Study Sessions
                </span>
            </div>

            <div class="calendar-card">
                <!-- FullCalendar inserts the interactive calendar into this empty container. -->
                <div id="calendar"></div>
            </div>

        </main>
    </div>
</div>

<script>
// Wait until the calendar container exists before initialising the calendar.
document.addEventListener('DOMContentLoaded', function () {
    const calendarElement = document.getElementById('calendar');

    // Configure the available views, event source and interactions for the calendar.
    const calendar = new FullCalendar.Calendar(calendarElement, {
        initialView: 'dayGridMonth',

        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,listWeek'
        },

        buttonText: {
            today: 'Today',
            month: 'Month',
            week: 'Week',
            list: 'List'
        },

        // Fetch event JSON from the server for the date range currently being viewed.
        events: 'calendar_events.php',

        eventTimeFormat: {
            hour: 'numeric',
            minute: '2-digit',
            meridiem: 'short'
        },

        // Open the event detail page when a calendar entry is clicked.
        eventClick: function (info) {
            info.jsEvent.preventDefault();

            if (info.event.url) {
                window.location.href = info.event.url;
            }
        },

        // Apply a CSS colour class according to the event category.
        eventDidMount: function (info) {
            const type = info.event.extendedProps.type;

            if (type === 'class') {
                info.el.classList.add('calendar-class');
            }

            if (type === 'assignment') {
                info.el.classList.add('calendar-assignment');
            }

            if (type === 'exam') {
                info.el.classList.add('calendar-exam');
            }

            if (type === 'study') {
                info.el.classList.add('calendar-study');
            }
        },

        height: 'auto'
    });

    // Draw the configured calendar inside its page container.
    calendar.render();
});
</script>

</body>
</html>