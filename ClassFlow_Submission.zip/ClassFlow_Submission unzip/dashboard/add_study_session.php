<?php
/* This form validates a date, start and end times, and study progress before saving a new study session under the signed-in student’s account. */
/* Validates submitted fields and saves a new study session. */
session_start();
require_once '../include/database.php';
require_once '../include/features.php';

// Reject requests that do not have a signed-in user in the session.
if (!isset($_SESSION['user_id'])) {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: ../login.php');
    exit;
}

// Use the session account ID to scope database operations to the current user.
$userId = $_SESSION['user_id'];

$topic = '';
$module = '';
$studyDate = '';
$startTime = '';
$endTime = '';
$notes = '';
$status = 'Planned';
$message = '';

// Restore an unsaved conflict draft without saving anything.
foreach (cf_draft_restore((int)$userId, 'study_session', 0) as $field => $value) {
    $variable = cf_draft_fields('study_session')[$field] ?? null;
    if ($variable !== null) $variable = $value;
}

// Process submitted form values only on a POST request.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    cf_check_csrf();
    $topic = trim($_POST['topic'] ?? '');
    $module = trim($_POST['module'] ?? '');
    $studyDate = trim($_POST['study_date'] ?? '');
    $startTime = trim($_POST['start_time'] ?? '');
    $endTime = trim($_POST['end_time'] ?? '');
    $notes = trim($_POST['notes'] ?? '');
    $status = trim($_POST['status'] ?? '');

    // Define the values accepted by the server for this selection field.
    $validStatuses = ['Planned', 'In Progress', 'Completed'];

    // Validate required values before continuing with database changes.
    if ($topic === '' || $module === '' || $studyDate === '' || $startTime === '' || $endTime === '' || $status === '') {
        $message = '<div class="alert alert-danger">Please fill in all required fields.</div>';
    } elseif (!in_array($status, $validStatuses, true)) {
        $message = '<div class="alert alert-danger">Please select a valid status.</div>';
    } elseif ($startTime >= $endTime) {
        $message = '<div class="alert alert-danger">End time must be later than start time.</div>';
    } elseif (($scheduleConflict = cf_schedule_conflict($pdo, (int) $userId, 'study_session', $studyDate, $startTime, $endTime, 0, $status === 'Completed')) && !cf_is_schedule_overlap($scheduleConflict)) {
        $message = '<div class="alert alert-danger">' . cf_escape($scheduleConflict) . '</div>';
    } else {
        $stmt = $pdo->prepare("
                    INSERT INTO study_sessions
                    (user_id, topic, module, study_date, start_time, end_time, notes, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ");

                if ($stmt->execute([
                    $userId,
                    $topic,
                    $module,
                    $studyDate,
                    $startTime,
                    $endTime,
                    $notes,
                    $status
                ])) {
                    cf_draft_clear((int)$userId, 'study_session', 0);
                $_SESSION['success_message'] = 'Study session added successfully.';
                cf_saved_conflict_redirect($pdo, (int)$userId, 'study_session', (int)$pdo->lastInsertId(), $_POST, $scheduleConflict ?? null);
                    // Redirect the browser after processing; exit below stops further output.
                    header('Location: study_planner.php');
                    exit;
                }

                $message = '<div class="alert alert-danger">Unable to add study session.</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<!-- Set the page title, character encoding, responsive viewport and stylesheet links. -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Study Session | ClassFlow</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=20261103b"><link rel="stylesheet" href="../css/theme.css?v=20261113-red1">
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <?php require_once 'sidebar.php'; ?>

        <!-- Main page content, positioned alongside the sidebar on dashboard pages. -->
        <main class="col-md-9 col-lg-10 p-4 dashboard-content">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="page-title mb-1">Add Study Session</h2>
                    <p class="text-muted mb-0">Plan focused study time around your timetable.</p>
                </div>

                <a href="study_planner.php" class="btn btn-outline-secondary">
                    <i class="fa-solid fa-arrow-left me-1"></i> Back
                </a>
            </div>

            <?= $message ?>

            <div class="form-card">
                <!-- Submit these fields using POST to the PHP handler named in the form action. -->
                <form method="POST">
                    <input type="hidden" name="csrf" value="<?= cf_csrf_token() ?>">
                    <div class="row">

                        <div class="col-md-6 mb-3">
                            <!-- Input field: Study Topic. -->
                            <label for="topic" class="form-label">Study Topic</label>
                            <input type="text" class="form-control" id="topic" name="topic"
                                   value="<?= htmlspecialchars($topic) ?>"
                                   placeholder="e.g. Normalisation and ER Diagrams" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <!-- Input field: Module. -->
                            <label for="module" class="form-label">Module</label>
                            <input type="text" class="form-control" id="module" name="module"
                                   value="<?= htmlspecialchars($module) ?>"
                                   placeholder="e.g. Database Systems" required>
                        </div>

                        <div class="col-md-4 mb-3">
                            <!-- Input field: Date. -->
                            <label for="study_date" class="form-label">Date</label>
                            <input type="date" class="form-control" id="study_date" name="study_date"
                                   value="<?= htmlspecialchars($studyDate) ?>" required>
                        </div>

                        <div class="col-md-4 mb-3">
                            <!-- Input field: Start Time. -->
                            <label for="start_time" class="form-label">Start Time</label>
                            <input type="time" class="form-control" id="start_time" name="start_time"
                                   value="<?= htmlspecialchars($startTime) ?>" required>
                        </div>

                        <div class="col-md-4 mb-3">
                            <!-- Input field: End Time. -->
                            <label for="end_time" class="form-label">End Time</label>
                            <input type="time" class="form-control" id="end_time" name="end_time"
                                   value="<?= htmlspecialchars($endTime) ?>" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <!-- Input field: Status. -->
                            <label for="status" class="form-label">Status</label>

                            <select class="form-select" id="status" name="status" required>
                                <option value="Planned" <?= $status === 'Planned' ? 'selected' : '' ?>>
                                    Planned
                                </option>

                                <option value="In Progress" <?= $status === 'In Progress' ? 'selected' : '' ?>>
                                    In Progress
                                </option>

                                <option value="Completed" <?= $status === 'Completed' ? 'selected' : '' ?>>
                                    Completed
                                </option>
                            </select>
                        </div>

                        <div class="col-12 mb-3">
                            <label for="notes" class="form-label">
                                Notes <span class="text-muted">(Optional)</span>
                            </label>

                            <textarea class="form-control" id="notes" name="notes" rows="4"
                                      placeholder="What do you plan to study during this session?"><?= htmlspecialchars($notes) ?></textarea>
                        </div>

                    </div>

                    <!-- Submit this form to its PHP handler. -->
                    <button type="submit" class="btn btn-save">
                        <i class="fa-solid fa-plus me-1"></i>
                        Add Study Session
                    </button>
                </form>
            </div>
        </main>
    </div>
</div>
</body>
</html>
