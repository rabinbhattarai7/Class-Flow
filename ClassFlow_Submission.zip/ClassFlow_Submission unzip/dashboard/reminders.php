<?php
/* The on-screen reminder page groups approaching and overdue activities. It displays notices in ClassFlow without sending email. */
/* Reminder page: builds on-screen notices from assignment, exam and study-session dates. */
session_start();
require_once '../include/database.php';

// Reject requests that do not have a signed-in user in the session.
if (!isset($_SESSION['user_id'])) {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: ../login.php');
    exit;
}

// Use the session account ID to scope database operations to the current user.
$userId = $_SESSION['user_id'];
$reminders = [];

/*
|--------------------------------------------------------------------------
| Assignment Reminders
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT id, title, module, due_date, due_time, status
    FROM assignments
    WHERE user_id = ?
    AND status != 'Completed'
    ORDER BY due_date ASC, due_time ASC
");

$stmt->execute([$userId]);
// Load all matching rows for the list or calculations below.
$assignments = $stmt->fetchAll();

// Process each item in this collection for the page or response.
foreach ($assignments as $assignment) {

    $dueTimestamp = strtotime(
        $assignment['due_date'] . ' ' . $assignment['due_time']
    );

    $now = time();
    $secondsRemaining = $dueTimestamp - $now;
    $daysRemaining = (int) floor($secondsRemaining / 86400);

    if ($dueTimestamp < $now) {

        // Add a reminder with its message, urgency and link to the related record.
        $reminders[] = [
            'type' => 'assignment',
            'title' => $assignment['title'],
            'module' => $assignment['module'],
            'message' => 'Assignment is overdue.',
            'date' => $assignment['due_date'],
            'time' => $assignment['due_time'],
            'level' => 'overdue',
            'url' => 'view_assignment.php?id=' . $assignment['id'],
            'timestamp' => $dueTimestamp
        ];

    } elseif ($secondsRemaining <= 86400) {

        // Add a reminder with its message, urgency and link to the related record.
        $reminders[] = [
            'type' => 'assignment',
            'title' => $assignment['title'],
            'module' => $assignment['module'],
            'message' => 'Assignment is due within 24 hours.',
            'date' => $assignment['due_date'],
            'time' => $assignment['due_time'],
            'level' => 'urgent',
            'url' => 'view_assignment.php?id=' . $assignment['id'],
            'timestamp' => $dueTimestamp
        ];

    } elseif ($daysRemaining <= 7) {

        // Add a reminder with its message, urgency and link to the related record.
        $reminders[] = [
            'type' => 'assignment',
            'title' => $assignment['title'],
            'module' => $assignment['module'],
            'message' => 'Assignment deadline is approaching.',
            'date' => $assignment['due_date'],
            'time' => $assignment['due_time'],
            'level' => 'upcoming',
            'url' => 'view_assignment.php?id=' . $assignment['id'],
            'timestamp' => $dueTimestamp
        ];
    }
}

/*
|--------------------------------------------------------------------------
| Exam Reminders
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT id, exam_name, module, exam_date, start_time
    FROM exams
    WHERE user_id = ?
    ORDER BY exam_date ASC, start_time ASC
");

$stmt->execute([$userId]);
// Load all matching rows for the list or calculations below.
$exams = $stmt->fetchAll();

// Process each item in this collection for the page or response.
foreach ($exams as $exam) {

    $examTimestamp = strtotime(
        $exam['exam_date'] . ' ' . $exam['start_time']
    );

    $now = time();
    $secondsRemaining = $examTimestamp - $now;
    $daysRemaining = (int) floor($secondsRemaining / 86400);

    /*
     * Ignore exams that have already started/passed.
     */
    if ($examTimestamp < $now) {
        continue;
    }

    if ($secondsRemaining <= 86400) {

        // Add a reminder with its message, urgency and link to the related record.
        $reminders[] = [
            'type' => 'exam',
            'title' => $exam['exam_name'],
            'module' => $exam['module'],
            'message' => 'Exam is within 24 hours.',
            'date' => $exam['exam_date'],
            'time' => $exam['start_time'],
            'level' => 'urgent',
            'url' => 'view_exam.php?id=' . $exam['id'],
            'timestamp' => $examTimestamp
        ];

    } elseif ($daysRemaining <= 7) {

        // Add a reminder with its message, urgency and link to the related record.
        $reminders[] = [
            'type' => 'exam',
            'title' => $exam['exam_name'],
            'module' => $exam['module'],
            'message' => 'Exam is approaching.',
            'date' => $exam['exam_date'],
            'time' => $exam['start_time'],
            'level' => 'upcoming',
            'url' => 'view_exam.php?id=' . $exam['id'],
            'timestamp' => $examTimestamp
        ];
    }
}

/*
|--------------------------------------------------------------------------
| Study Session Reminders
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT id, topic, module, study_date, start_time, status
    FROM study_sessions
    WHERE user_id = ?
    AND status != 'Completed'
    ORDER BY study_date ASC, start_time ASC
");

$stmt->execute([$userId]);
// Load all matching rows for the list or calculations below.
$studySessions = $stmt->fetchAll();

// Process each item in this collection for the page or response.
foreach ($studySessions as $studySession) {

    $studyTimestamp = strtotime(
        $studySession['study_date'] . ' ' . $studySession['start_time']
    );

    $now = time();
    $secondsRemaining = $studyTimestamp - $now;

    /*
     * Ignore study sessions that have already started/passed.
     */
    if ($studyTimestamp < $now) {
        continue;
    }

    if ($secondsRemaining <= 86400) {

        // Add a reminder with its message, urgency and link to the related record.
        $reminders[] = [
            'type' => 'study',
            'title' => $studySession['topic'],
            'module' => $studySession['module'],
            'message' => 'Study session is within 24 hours.',
            'date' => $studySession['study_date'],
            'time' => $studySession['start_time'],
            'level' => 'urgent',
            'url' => 'view_study_session.php?id=' . $studySession['id'],
            'timestamp' => $studyTimestamp
        ];

    } elseif ($secondsRemaining <= (3 * 86400)) {

        // Add a reminder with its message, urgency and link to the related record.
        $reminders[] = [
            'type' => 'study',
            'title' => $studySession['topic'],
            'module' => $studySession['module'],
            'message' => 'Study session is coming up.',
            'date' => $studySession['study_date'],
            'time' => $studySession['start_time'],
            'level' => 'upcoming',
            'url' => 'view_study_session.php?id=' . $studySession['id'],
            'timestamp' => $studyTimestamp
        ];
    }
}

/*
|--------------------------------------------------------------------------
| Sort Reminders
|--------------------------------------------------------------------------
*/

usort($reminders, function ($a, $b) {

    $priority = [
        'overdue' => 1,
        'urgent' => 2,
        'upcoming' => 3
    ];

    if ($priority[$a['level']] === $priority[$b['level']]) {
        return $a['timestamp'] <=> $b['timestamp'];
    }

    return $priority[$a['level']] <=> $priority[$b['level']];
});

$totalReminders = count($reminders);

$urgentCount = count(array_filter(
    $reminders,
    fn($reminder) => $reminder['level'] === 'urgent'
));

$upcomingCount = count(array_filter(
    $reminders,
    fn($reminder) => $reminder['level'] === 'upcoming'
));

$overdueCount = count(array_filter(
    $reminders,
    fn($reminder) => $reminder['level'] === 'overdue'
));
?>

<!DOCTYPE html>
<html lang="en">
<!-- Set the page title, character encoding, responsive viewport and stylesheet links. -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Reminders | ClassFlow</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">

    <link rel="stylesheet" href="style.css?v=20261103b"><link rel="stylesheet" href="../css/theme.css?v=20261113-red1">
</head>

<body>

<div class="container-fluid">
    <div class="row">

        <?php require_once 'sidebar.php'; ?>

        <!-- Main page content, positioned alongside the sidebar on dashboard pages. -->
        <main class="col-md-9 col-lg-10 p-4 dashboard-content">

            <div class="mb-4">
                <h2 class="page-title mb-1">Smart Reminders</h2>
                <a href="email_reminders.php" class="btn btn-outline-primary my-2"><i class="fa-solid fa-envelope me-1"></i> Set up email reminders</a>

                <p class="text-muted mb-0">
                    Keep track of important academic deadlines and upcoming activities.
                </p>
            </div>

            <div class="row g-3 mb-4">

                <div class="col-md-3">
                    <div class="reminder-stat-card">
                        <div class="reminder-stat-icon total">
                            <i class="fa-solid fa-bell"></i>
                        </div>

                        <div>
                            <span>Total Reminders</span>
                            <h3><?= $totalReminders ?></h3>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="reminder-stat-card">
                        <div class="reminder-stat-icon overdue">
                            <i class="fa-solid fa-triangle-exclamation"></i>
                        </div>

                        <div>
                            <span>Overdue</span>
                            <h3><?= $overdueCount ?></h3>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="reminder-stat-card">
                        <div class="reminder-stat-icon urgent">
                            <i class="fa-solid fa-clock"></i>
                        </div>

                        <div>
                            <span>Urgent</span>
                            <h3><?= $urgentCount ?></h3>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="reminder-stat-card">
                        <div class="reminder-stat-icon upcoming">
                            <i class="fa-regular fa-calendar"></i>
                        </div>

                        <div>
                            <span>Upcoming</span>
                            <h3><?= $upcomingCount ?></h3>
                        </div>
                    </div>
                </div>

            </div>

            <div class="reminders-card">

                <div class="reminders-header">
                    <div>
                        <h5 class="mb-1">Your Reminders</h5>
                        <p class="text-muted mb-0">
                            Automatically generated from your academic schedule.
                        </p>
                    </div>
                </div>

                <?php if (empty($reminders)): ?>

                    <div class="empty-reminders">
                        <div class="empty-reminder-icon">
                            <i class="fa-regular fa-circle-check"></i>
                        </div>

                        <h5>You're all caught up</h5>

                        <p class="text-muted mb-0">
                            There are no urgent or upcoming academic reminders.
                        </p>
                    </div>

                <?php else: ?>

                    <div class="reminder-list">

                        <?php foreach ($reminders as $reminder): ?>

                            <a
                                href="<?= htmlspecialchars($reminder['url']) ?>"
                                class="reminder-item"
                            >

                                <div class="reminder-type-icon <?= htmlspecialchars($reminder['type']) ?>">

                                    <?php if ($reminder['type'] === 'assignment'): ?>
                                        <i class="fa-solid fa-list-check"></i>

                                    <?php elseif ($reminder['type'] === 'exam'): ?>
                                        <i class="fa-solid fa-book-open"></i>

                                    <?php else: ?>
                                        <i class="fa-solid fa-clock"></i>
                                    <?php endif; ?>

                                </div>

                                <div class="reminder-content">

                                    <div class="reminder-title-row">

                                        <div>
                                            <h6>
                                                <?= htmlspecialchars($reminder['title']) ?>
                                            </h6>

                                            <span class="reminder-module">
                                                <?= htmlspecialchars($reminder['module']) ?>
                                            </span>
                                        </div>

                                        <span class="reminder-level <?= htmlspecialchars($reminder['level']) ?>">
                                            <?= ucfirst(htmlspecialchars($reminder['level'])) ?>
                                        </span>

                                    </div>

                                    <p>
                                        <?= htmlspecialchars($reminder['message']) ?>
                                    </p>

                                    <div class="reminder-date">
                                        <i class="fa-regular fa-calendar me-1"></i>

                                        <?= date(
                                            'D, d M Y',
                                            strtotime($reminder['date'])
                                        ) ?>

                                        <span class="mx-2">•</span>

                                        <i class="fa-regular fa-clock me-1"></i>

                                        <?= date(
                                            'g:i A',
                                            strtotime($reminder['time'])
                                        ) ?>
                                    </div>

                                </div>

                                <div class="reminder-arrow">
                                    <i class="fa-solid fa-chevron-right"></i>
                                </div>

                            </a>

                        <?php endforeach; ?>

                    </div>

                <?php endif; ?>

            </div>

        </main>
    </div>
</div>

</body>
</html>
