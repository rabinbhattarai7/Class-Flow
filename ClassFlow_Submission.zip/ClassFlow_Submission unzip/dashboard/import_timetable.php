<?php
/* The upload form builds an editable preview. A separate save action imports only the class rows the student selected. */
session_start();
require_once '../include/database.php';
require_once '../include/timetable_import.php';
if(!isset($_SESSION['user_id'])) { header('Location: ../login.php'); exit; }
$userId=(int)$_SESSION['user_id'];
// Supply a sample file with headers the importer recognises, so students can see the expected columns.
if(isset($_GET['template'])) {
    header('Content-Type: text/csv; charset=UTF-8'); header('Content-Disposition: attachment; filename="classflow-timetable-template.csv"');
    $out=fopen('php://output','w');
    fputcsv($out,['subject_name','lecturer_name','day','start_time','end_time','room','class_type','notes'],',','"','');
    fputcsv($out,['Database Systems','Alex Smith','Monday','09:00','10:30','B204','Lecture',''],',','"','');
    fputcsv($out,['Programming Lab','Jamie Lee','Wednesday','13:00','15:00','Lab 2','Lab',''],',','"','');
    fclose($out); exit;
}
$error=''; $statuses=[];
$fields=['subject_name'=>'Subject / module','day'=>'Weekday','start_time'=>'Start time','end_time'=>'End time','lecturer_name'=>'Lecturer','room'=>'Room','class_type'=>'Class type','notes'=>'Notes'];
// Keep the preview in the signed-in student’s session. The preview expires after twenty minutes and is discarded if it belongs to another account.
$state=$_SESSION['cf_timetable_import']??null;
if($state && ($state['expires']<time() || $state['user_id']!==$userId)) { unset($_SESSION['cf_timetable_import']); $state=null; }
if($_SERVER['REQUEST_METHOD']==='POST') {
    // Verify the form token before changing the preview or saving any classes.
    cf_check_csrf();
    try {
        $action=(string)($_POST['action']??'');
        if($action==='discard') { unset($_SESSION['cf_timetable_import']); $state=null; }
        // Validate the file and read it into a preview. Uploading does not create timetable records.
        elseif($action==='upload') {
            $file=$_FILES['timetable']??null;
            if(!$file || $file['error']!==UPLOAD_ERR_OK) throw new RuntimeException('The upload did not complete. Check the file size and try again.');
            if(!is_uploaded_file($file['tmp_name']) || $file['size']<1 || $file['size']>20*1024*1024) throw new RuntimeException('Choose a non-empty CSV or PDF smaller than 20 MB. Your server may impose a smaller upload limit.');
            $extension=strtolower(pathinfo($file['name'],PATHINFO_EXTENSION));
            $state=['id'=>bin2hex(random_bytes(16)),'user_id'=>$userId,'expires'=>time()+1200,'name'=>mb_substr(basename($file['name']),0,200),'warnings'=>[]];
            // Recognise familiar column headers and let the student map any required columns that cannot be recognised automatically.
            if($extension==='csv') {
                $state['csv']=cf_import_csv_read(file_get_contents($file['tmp_name'])); $state['stage']='mapping'; $state['mapping']=[];
                foreach($state['csv']['header'] as $i=>$label) if($field=cf_import_alias((string)$label)) $state['mapping'][$field]=(string)$i;
                if(count(array_intersect(['subject_name','day','start_time','end_time'],array_keys($state['mapping'])))===4) {
                    $state['rows']=cf_import_csv_map($state['csv'],array_intersect_key($state['mapping'],$fields));
                    $state['stage']='preview';
                }
            } elseif($extension==='pdf') {
                if(!str_starts_with(file_get_contents($file['tmp_name'],false,null,0,5),'%PDF-')) throw new RuntimeException('This file does not have a valid PDF header.');
                $parsed=cf_import_pdf($file['tmp_name'],trim((string)($_POST['pdf_pages']??'')));
                $state['rows']=$parsed['rows']; $state['warnings']=$parsed['warnings']; $state['stage']='preview';
                if(!$state['rows']) throw new RuntimeException('No reliable classes could be extracted. Scanned PDFs need OCR; complex grids may need a CSV export. '.implode(' ',$parsed['warnings']));
            } else throw new RuntimeException('Only .csv and .pdf files are supported.');
            $_SESSION['cf_timetable_import']=$state;
        } elseif(in_array($action,['remap','map','review','save'],true)) {
            if(!$state || !hash_equals($state['id'],(string)($_POST['import_id']??''))) throw new RuntimeException('This preview expired. Upload your timetable again.');
            if($action==='remap') {
                if(!isset($state['csv'])) throw new RuntimeException('Upload a CSV first.');
                $state['stage']='mapping';
            } elseif($action==='map') {
                if(!isset($state['csv'])) throw new RuntimeException('Upload a CSV first.');
                $mapping=(array)($_POST['mapping']??[]);
                $state['rows']=cf_import_csv_map($state['csv'],array_intersect_key($mapping,$fields));
                $state['mapping']=$mapping; $state['stage']='preview'; unset($state['selected']);
            } else {
                if(!isset($state['rows'])) throw new RuntimeException('Preview the timetable before importing.');
                // Apply edited preview values and collect the row numbers the student selected. Ignore invalid row numbers.
                $edited=(array)($_POST['rows']??[]);
                $selected=[];
                foreach ((array) ($_POST['selected'] ?? []) as $index) {
                    if (is_string($index) && ctype_digit($index) && isset($state['rows'][$index])) {
                        $selected[(int) $index] = (int) $index;
                    }
                }
                foreach($state['rows'] as $i=>&$row) {
                    foreach(array_keys($fields) as $field) if(isset($edited[$i][$field]) && is_string($edited[$i][$field])) $row[$field]=trim($edited[$i][$field]);
                    $row['start_time']=cf_import_time($row['start_time']); $row['end_time']=cf_import_time($row['end_time']);
                } unset($row);
                $state['selected']=array_values($selected);
                if($action==='save') {
                    $chosen=[]; foreach($state['selected'] as $i) $chosen[]=$state['rows'][$i];
                    // Validate and save only the selected rows. If a selected class has an error or conflict, the import helper rejects the batch.
                    $count=cf_import_commit($pdo,$userId,$chosen);
                    unset($_SESSION['cf_timetable_import']);
                    $_SESSION['success_message']="$count classes imported. Existing duplicates were skipped.";
                    header('Location: timetable.php'); exit;
                }
            }
            $_SESSION['cf_timetable_import']=$state;
        } else throw new RuntimeException('Choose a valid import action.');
    } catch(Throwable $e) {
        if($e instanceof PDOException) $error='The import could not be saved. No selected classes were added. Please try again.';
        elseif($e instanceof RuntimeException) $error=$e->getMessage();
        else $error='This PDF could not be read. Try an unencrypted PDF with selectable text, or export the timetable as CSV.';
        if($state && isset($state['rows'])) $_SESSION['cf_timetable_import']=$state;
    }
}
if($state && isset($state['rows'])) $statuses=cf_import_statuses($pdo,$userId,$state['rows']);
cf_page_start('Import timetable', false);
?>
<header class="import-hero"><div><div class="import-eyebrow">Your week, brought together</div><h1>Import your<br>timetable.</h1><p>Bring your timetable into ClassFlow. Upload your file, give it a quick check, and make room for the week ahead.</p></div><a class="btn btn-outline-secondary import-back" href="timetable.php"><i class="fa-solid fa-arrow-left me-2"></i> Your timetable</a></header>
<ol class="import-progress" aria-label="Import progress"><li class="<?= !$state?'is-current':'' ?>"><span>01</span> Upload file</li><li class="<?= $state?'is-current':'' ?>"><span>02</span> Review classes</li><li><span>03</span> Add to timetable</li></ol>
<?php if($error): ?><div class="alert alert-danger" role="alert"><?= cf_escape($error) ?></div><?php endif; ?>
<div class="form-card import-upload"><div class="import-section-title"><div><h4>Start with your timetable</h4><p>A PDF from your university or a simple spreadsheet export.</p></div><a class="import-template" href="?template=csv"><i class="fa-solid fa-download me-1"></i> CSV template</a></div>
<form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?= cf_csrf_token() ?>"><input type="hidden" name="action" value="upload">
<div class="import-upload-grid"><div class="import-file-area"><div class="import-file-icon"><i class="fa-regular fa-file-lines"></i></div><label for="timetable"><strong>Choose your timetable file</strong></label><p>PDF or CSV · up to <?= cf_escape(min(20,(int)ini_get('upload_max_filesize'))) ?> MB</p><input class="form-control" type="file" id="timetable" name="timetable" accept=".csv,.pdf,text/csv,application/pdf" required></div><div class="import-options"><label class="form-label" for="pdf_pages">Only need a few PDF pages?</label><input class="form-control" id="pdf_pages" name="pdf_pages" placeholder="All pages, or e.g. 1,3-4"><div class="form-text small">Leave this blank to read the whole file.</div><button class="btn btn-primary">Preview classes <i class="fa-solid fa-arrow-right ms-2"></i></button></div></div></form><div class="import-supported"><span>PDF</span><span>CSV</span> Daily exports, class tables and supported weekly grids.</div></div>
<div class="import-help"><div class="import-help-item"><i class="fa-solid fa-list-check"></i><div><strong>You’re in control</strong><p>Check every class before saving. Your existing timetable stays in place.</p></div></div><div class="import-help-item"><i class="fa-solid fa-shield-halved"></i><div><strong>Processed here, privately</strong><p>Your file is read on this server, without an external AI service.</p></div></div><div class="import-help-item"><i class="fa-regular fa-file-pdf"></i><div><strong>A quick note on PDFs</strong><p>Use a PDF with selectable text. Scanned images need OCR first.</p></div></div></div>
<?php if($state): ?><div class="import-file-summary"><i class="fa-regular fa-file-lines"></i><strong><?= cf_escape($state['name']) ?></strong><span>Preview available for 20 minutes</span></div><?php endif; ?>
<?php if(($state['stage']??'')==='mapping'): ?>
<section class="form-card mb-4"><h4>Match your CSV columns</h4><p class="text-muted">Required: subject, weekday, start and end. Other columns are optional; missing lecturer/room values are marked “Not specified”, and the default class type is Lecture.</p>
<form method="post"><input type="hidden" name="csrf" value="<?= cf_csrf_token() ?>"><input type="hidden" name="action" value="map"><input type="hidden" name="import_id" value="<?= cf_escape($state['id']) ?>"><div class="row g-3">
<?php foreach($fields as $field=>$label): ?><div class="col-md-3"><label class="form-label" for="map_<?= $field ?>"><?= $label ?></label><select class="form-select" name="mapping[<?= $field ?>]" id="map_<?= $field ?>"><option value="">Not supplied</option><?php foreach($state['csv']['header'] as $i=>$name): ?><option value="<?= $i ?>" <?= (string)($state['mapping'][$field]??'')===(string)$i?'selected':'' ?>><?= cf_escape($name) ?></option><?php endforeach; ?></select></div><?php endforeach; ?></div><button class="btn btn-primary mt-3">Preview classes</button></form></section>
<?php endif; ?>
<?php if(($state['stage']??'')==='preview'): ?>
<?php if(isset($state['csv'])): ?><form method="post" class="mb-3"><input type="hidden" name="csrf" value="<?= cf_csrf_token() ?>"><input type="hidden" name="import_id" value="<?= cf_escape($state['id']) ?>"><button class="btn btn-outline-secondary btn-sm" name="action" value="remap">Change CSV column mapping</button></form><?php endif; ?>
<?php foreach($state['warnings'] as $warning): ?><div class="alert alert-warning"><?= cf_escape($warning) ?></div><?php endforeach; ?>
<section class="table-card import-preview"><div class="import-section-title"><div><h4>Your classes, ready for a look</h4><p>Check the details, edit anything that needs it, and choose what to add.</p></div><span class="import-count"><?= count($state['rows']) ?> classes found</span></div><p class="text-muted small">Tick each class you want to add. Use “Review changes” to check your edits. Exact duplicates are skipped.</p>
<div class="alert alert-info">ClassFlow stores repeating weekly classes. Dates printed in a PDF determine the weekday; original dates are retained in notes. Week ranges, term dates and one-off changes are not enforced. Import only the classes and group that belong to you.</div>
<form method="post"><input type="hidden" name="csrf" value="<?= cf_csrf_token() ?>"><input type="hidden" name="import_id" value="<?= cf_escape($state['id']) ?>">
<div class="form-check mb-3" id="import-select-all-control" hidden>
    <input type="checkbox" class="form-check-input" id="import-select-all">
    <label class="form-check-label" for="import-select-all">Select all classes</label>
</div>
<div class="table-responsive"><table class="table align-middle"><thead><tr><th>Import</th><th>Subject</th><th>Day</th><th>Start</th><th>End</th><th>Room</th><th>Lecturer</th><th>Type</th><th>Review</th></tr></thead><tbody>
<?php foreach($state['rows'] as $i=>$row): $status=$statuses[$i]; $checked=in_array($i,$state['selected']??[],true); ?>
<tr><td><input type="checkbox" class="form-check-input" name="selected[]" value="<?= $i ?>" aria-label="Import row <?= $i+1 ?>" <?= $checked?'checked':'' ?>></td>
<?php foreach(['subject_name','day','start_time','end_time','room','lecturer_name','class_type'] as $field): ?>
<td><?php if($field==='day'||$field==='class_type'): ?><select class="form-select" style="min-width:120px" name="rows[<?= $i ?>][<?= $field ?>]" aria-label="<?= cf_escape($fields[$field]) ?> row <?= $i+1 ?>"><option value="">Choose…</option><?php foreach($field==='day'?['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']:['Lecture','Tutorial','Lab'] as $option): ?><option <?= $row[$field]===$option?'selected':'' ?>><?= $option ?></option><?php endforeach; ?></select><?php else: ?><input class="form-control" style="min-width:<?= $field==='subject_name'?'240':'115' ?>px" name="rows[<?= $i ?>][<?= $field ?>]" type="<?= in_array($field,['start_time','end_time'])?'time':'text' ?>" value="<?= cf_escape($row[$field]) ?>" aria-label="<?= cf_escape($fields[$field]) ?> row <?= $i+1 ?>"><?php endif; ?></td>
<?php endforeach; ?>
<td style="min-width:240px"><span class="badge <?= $status['status']==='ready'?'bg-success':'bg-warning text-dark' ?>"><?= cf_escape(ucfirst($status['status'])) ?></span><div class="small"><?= cf_escape($status['message']) ?></div><div class="small text-muted"><?= cf_escape($row['source']) ?><?= $row['warnings']?' · '.cf_escape($row['warnings']):'' ?></div><details class="small"><summary>Notes</summary><textarea class="form-control" name="rows[<?= $i ?>][notes]" aria-label="Notes row <?= $i+1 ?>"><?= cf_escape($row['notes']) ?></textarea></details></td></tr>
<?php endforeach; ?></tbody></table></div>
<div class="import-actions">
<div class="import-action-buttons"><button class="btn btn-outline-primary" name="action" value="review">Review changes</button><button class="btn btn-primary" name="action" value="save">Add selected classes <i class="fa-solid fa-arrow-right ms-2"></i></button></div></div></form></section>
<script>
(() => {
    const selectAll = document.getElementById('import-select-all');
    const rows = [...selectAll.form.querySelectorAll('input[name="selected[]"]')];
    if (rows.length === 0) return;

    // Reflect whether none, some or all preview rows are selected.
    function syncSelectAll() {
        const selectedCount = rows.filter(row => row.checked).length;
        selectAll.checked = selectedCount === rows.length;
        selectAll.indeterminate = selectedCount > 0 && selectedCount < rows.length;
    }

    selectAll.addEventListener('change', () => {
        rows.forEach(row => { row.checked = selectAll.checked; });
        syncSelectAll();
    });
    rows.forEach(row => row.addEventListener('change', syncSelectAll));
    syncSelectAll();
    document.getElementById('import-select-all-control').hidden = false;
})();
</script>
<?php endif; ?>
<?php if(!$state): ?><section class="table-card import-preview"><div class="import-section-title"><div><h4>Your class preview</h4><p>A quick check before anything joins your timetable.</p></div><span class="import-count">No file yet</span></div><div class="import-empty"><i class="fa-regular fa-calendar"></i><h5>A clearer week starts here</h5><p>Your classes will appear here after you upload a timetable. You can review and edit them before saving.</p></div></section><?php endif; ?>
<?php if($state): ?><form method="post" class="mt-3"><input type="hidden" name="csrf" value="<?= cf_csrf_token() ?>"><button class="btn btn-outline-secondary" name="action" value="discard">Discard preview</button></form><?php endif; ?>
<?php cf_page_end(); ?>
