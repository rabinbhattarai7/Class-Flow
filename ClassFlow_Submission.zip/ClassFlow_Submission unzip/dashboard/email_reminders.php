<?php
/* The email reminder page saves one schedule per activity type and shows delivery attempts belonging to the signed-in student. */
session_start();
require_once '../include/database.php';
require_once '../include/features.php';
require_once '../include/email.php';
if (!isset($_SESSION['user_id'])) { header('Location: ../login.php'); exit; }
$userId = (int) $_SESSION['user_id'];
$message = '';
$leadOptions = ['none'=>'Off','same_day'=>'On the day','1_day'=>'1 day before','3_days'=>'3 days before','1_week'=>'1 week before'];
// Each activity type has a shared timing choice. Assignment and exam reminders use these choices rather than a setting on each item.
$reminderFields = [
    'assignment_reminder' => 'Assignments',
    'exam_reminder' => 'Exams',
    'study_reminder' => 'Study sessions',
    'class_reminder' => 'Weekly classes',
];
if (cf_feature_ready($pdo) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check the form token before changing preferences or requesting another delivery attempt.
    cf_check_csrf();
    // Only the owner can return an uncertain attempt to the queue. The worker checks whether the event is still due before trying again.
    if (isset($_POST['retry'])) {
        $stmt = $pdo->prepare("UPDATE cf_reminder_deliveries SET status = 'pending', last_error = NULL WHERE delivery_key = ? AND user_id = ? AND status IN ('failed','uncertain')");
        $stmt->execute([(string) $_POST['retry'], $userId]);
        $message = 'Retry requested. If the event is still eligible, the next sender run will try again.';
    } else {
        $zone = (string) ($_POST['timezone'] ?? '');
        // Collect and validate all four timing choices before saving them together.
        $leads = [];
        foreach ($reminderFields as $field => $label) {
            $leads[$field] = $_POST[$field] ?? '';
        }
        if (!in_array($zone, DateTimeZone::listIdentifiers(), true) ||
            count(array_filter($leads, fn($lead) => is_string($lead) && isset($leadOptions[$lead]))) !== count($reminderFields)) {
            $message = 'Please choose valid reminder settings.';
        } else {
            $stmt = $pdo->prepare(
                'INSERT INTO cf_preferences (user_id, email_enabled, timezone, assignment_reminder, exam_reminder, study_reminder, class_reminder)
                 VALUES (?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE email_enabled=VALUES(email_enabled), timezone=VALUES(timezone),
                 assignment_reminder=VALUES(assignment_reminder), exam_reminder=VALUES(exam_reminder),
                 study_reminder=VALUES(study_reminder), class_reminder=VALUES(class_reminder)'
            );
            $stmt->execute([$userId, isset($_POST['email_enabled']) ? 1 : 0, $zone, ...array_values($leads)]);
            $message = 'Your email preferences have been saved.';
        }
    }
}
cf_page_start('Email reminders');
cf_require_features($pdo);
$prefs = cf_preferences($pdo, $userId);
$stmt = $pdo->prepare('SELECT email FROM users WHERE id = ?'); $stmt->execute([$userId]); $email = $stmt->fetchColumn();
// Read the thirty most recent delivery attempts for this student only.
$stmt = $pdo->prepare('SELECT * FROM cf_reminder_deliveries WHERE user_id = ? ORDER BY created_at DESC LIMIT 30'); $stmt->execute([$userId]); $history = $stmt->fetchAll();
?>
<p class="text-muted">Get reminders even when ClassFlow is closed. Messages go to your profile email: <strong><?= cf_escape($email) ?></strong>. <a href="profile.php">Change email</a></p>
<?php if ($message): ?><div class="alert alert-info" role="status"><?= cf_escape($message) ?></div><?php endif; ?>
<?php if (!cf_mail_configured()): ?><div class="alert alert-warning">Email delivery is awaiting the administrator’s Gmail connection. You can save your preferences now, but messages cannot be sent yet.</div><?php endif; ?>
<div class="form-card mb-4"><form method="post">
<input type="hidden" name="csrf" value="<?= cf_csrf_token() ?>">
<div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox" name="email_enabled" id="email_enabled" <?= $prefs['email_enabled'] ? 'checked' : '' ?>><label class="form-check-label" for="email_enabled">Send me email reminders</label></div>
<div class="row g-3">
<div class="col-12"><label class="form-label" for="timezone">Your timetable time zone</label><select class="form-select" name="timezone" id="timezone"><?php foreach (DateTimeZone::listIdentifiers() as $zone): ?><option <?= $zone === $prefs['timezone'] ? 'selected' : '' ?>><?= cf_escape($zone) ?></option><?php endforeach; ?></select></div>
<?php foreach ($reminderFields as $field => $label): ?>
<div class="col-sm-6 col-lg-3"><label class="form-label" for="<?= $field ?>"><?= $label ?></label><select class="form-select" id="<?= $field ?>" name="<?= $field ?>"><?php foreach ($leadOptions as $value=>$text): ?><option value="<?= $value ?>" <?= $prefs[$field] === $value ? 'selected' : '' ?>><?= $text ?></option><?php endforeach; ?></select></div>
<?php endforeach; ?>
</div><p class="text-muted small mt-3">Each setting applies to all items of that type. “On the day” sends from 08:00, or midnight for items due or starting at or before 08:00. The sender stops trying when the item is due or starts. Completed assignments and study sessions are skipped.</p>
<button class="btn btn-save">Save preferences</button>
</form></div>
<div class="table-card"><h4>Delivery history</h4><p class="text-muted small">“Sent” means Gmail accepted the message; check spam if it has not arrived. An uncertain attempt may already have been accepted, so check your inbox before retrying.</p>
<?php if (!$history): ?><p>No delivery attempts yet.</p><?php else: ?><div class="table-responsive"><table class="table"><thead><tr><th>Event</th><th>Event time</th><th>Status</th><th>Details</th></tr></thead><tbody>
<?php foreach ($history as $row): ?><tr><td><?= cf_escape($row['event_title']) ?></td><td><?= cf_escape($row['event_at']) ?></td><td><?= cf_escape(ucfirst($row['status'])) ?></td><td><?= cf_escape($row['last_error'] ?? '') ?><?php if (in_array($row['status'], ['failed','uncertain'], true)): ?><form method="post" class="mt-1"><input type="hidden" name="csrf" value="<?= cf_csrf_token() ?>"><button name="retry" value="<?= cf_escape($row['delivery_key']) ?>" class="btn btn-sm btn-outline-primary">Retry delivery</button></form><?php endif; ?></td></tr><?php endforeach; ?>
</tbody></table></div><?php endif; ?></div>
<?php cf_page_end(); ?>
