<?php
/* The details page reads one study session using both the record number and the signed-in student’s account number. */
/* Loads and displays the signed-in user's study session. */
session_start();
require_once '../include/database.php';

// Reject requests that do not have a signed-in user in the session.
if (!isset($_SESSION['user_id'])) {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: ../login.php');
    exit;
}

// Use the session account ID to scope database operations to the current user.
$userId = $_SESSION['user_id'];
// Read the requested record ID and require a valid integer.
$sessionId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$sessionId) {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: study_planner.php');
    exit;
}

// Prepare a lookup of study sessions using bound parameters. Restrict the query to the current account.
$stmt = $pdo->prepare("
    SELECT *
    FROM study_sessions
    WHERE id = ? AND user_id = ?
");
$stmt->execute([$sessionId, $userId]);
// Read the matching record; false means no row was found.
$studySession = $stmt->fetch();

if (!$studySession) {
    $_SESSION['error_message'] = 'Study session not found.';
    // Redirect the browser after processing; exit below stops further output.
    header('Location: study_planner.php');
    exit;
}

$sessionEnd = strtotime(
    $studySession['study_date'] . ' ' . $studySession['end_time']
);

$isPast = $studySession['status'] !== 'Completed' && $sessionEnd < time();
?>

<!DOCTYPE html>
<html lang="en">
<!-- Set the page title, character encoding, responsive viewport and stylesheet links. -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($studySession['topic']) ?> | ClassFlow</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=20261103b"><link rel="stylesheet" href="../css/theme.css?v=20261113-red1">
</head>

<body>
<div class="container-fluid">
    <div class="row">

        <?php require_once 'sidebar.php'; ?>

        <!-- Main page content, positioned alongside the sidebar on dashboard pages. -->
        <main class="col-md-9 col-lg-10 p-4 dashboard-content">

            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="page-title mb-1">Study Session Details</h2>
                    <p class="text-muted mb-0">View your planned study information.</p>
                </div>

                <a href="study_planner.php" class="btn btn-outline-secondary">
                    <i class="fa-solid fa-arrow-left me-1"></i> Back
                </a>
            </div>

            <div class="study-details-card">

                <div class="study-details-header">
                    <div>
                        <span class="study-status <?= strtolower(str_replace(' ', '-', $studySession['status'])) ?>">
                            <?= htmlspecialchars($studySession['status']) ?>
                        </span>

                        <h3><?= htmlspecialchars($studySession['topic']) ?></h3>

                        <p class="mb-0">
                            <i class="fa-solid fa-book me-1"></i>
                            <?= htmlspecialchars($studySession['module']) ?>
                        </p>
                    </div>

                    <div class="details-actions">

                        <a href="edit_study_session.php?id=<?= $studySession['id'] ?>" class="btn btn-light">
                            <i class="fa-solid fa-pen-to-square me-1"></i>
                            Edit
                        </a>

                        <?php if ($studySession['status'] !== 'Completed'): ?>
                            <!-- Submit these fields using POST to the PHP handler named in the form action. -->
                            <form method="POST" action="complete_study_session.php">
                                <!-- Send this record identifier with the form; the server must still check ownership. -->
                                <input type="hidden" name="id" value="<?= $studySession['id'] ?>">

                                <!-- Submit this form to its PHP handler. -->
                                <button type="submit" class="btn btn-success">
                                    <i class="fa-solid fa-check me-1"></i>
                                    Complete
                                </button>
                            </form>
                        <?php endif; ?>

                        <!-- Submit these fields using POST to the PHP handler named in the form action. -->
                        <form method="POST" action="delete_study_session.php"
                              onsubmit="return confirm('Are you sure you want to delete this study session?');">

                            <!-- Send this record identifier with the form; the server must still check ownership. -->
                            <input type="hidden" name="id" value="<?= $studySession['id'] ?>">

                            <!-- Submit this form to its PHP handler. -->
                            <button type="submit" class="btn btn-danger">
                                <i class="fa-solid fa-trash me-1"></i>
                                Delete
                            </button>
                        </form>

                    </div>
                </div>

                <div class="study-details-body">

                    <?php if ($isPast): ?>
                        <div class="alert alert-warning">
                            <i class="fa-solid fa-triangle-exclamation me-2"></i>
                            This study session has passed but has not been marked as completed.
                        </div>
                    <?php endif; ?>

                    <div class="row">

                        <div class="col-md-6 col-lg-3 mb-4">
                            <div class="detail-item">
                                <div class="detail-icon">
                                    <i class="fa-regular fa-calendar"></i>
                                </div>

                                <div>
                                    <span>Date</span>
                                    <strong>
                                        <?= date('d M Y', strtotime($studySession['study_date'])) ?>
                                    </strong>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 col-lg-3 mb-4">
                            <div class="detail-item">
                                <div class="detail-icon">
                                    <i class="fa-regular fa-clock"></i>
                                </div>

                                <div>
                                    <span>Time</span>
                                    <strong>
                                        <?= date('g:i A', strtotime($studySession['start_time'])) ?>
                                        -
                                        <?= date('g:i A', strtotime($studySession['end_time'])) ?>
                                    </strong>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 col-lg-3 mb-4">
                            <div class="detail-item">
                                <div class="detail-icon">
                                    <i class="fa-solid fa-book"></i>
                                </div>

                                <div>
                                    <span>Module</span>
                                    <strong><?= htmlspecialchars($studySession['module']) ?></strong>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 col-lg-3 mb-4">
                            <div class="detail-item">
                                <div class="detail-icon">
                                    <i class="fa-solid fa-circle-check"></i>
                                </div>

                                <div>
                                    <span>Status</span>
                                    <strong><?= htmlspecialchars($studySession['status']) ?></strong>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="details-section">
                        <h6>
                            <i class="fa-solid fa-book-open-reader me-2"></i>
                            Study Topic
                        </h6>

                        <p><?= htmlspecialchars($studySession['topic']) ?></p>
                    </div>

                    <div class="details-section mb-0">
                        <h6>
                            <i class="fa-regular fa-note-sticky me-2"></i>
                            Notes
                        </h6>

                        <p class="mb-0">
                            <?= $studySession['notes']
                                ? nl2br(htmlspecialchars($studySession['notes']))
                                : '<span class="text-muted">No notes added.</span>' ?>
                        </p>
                    </div>

                </div>
            </div>

        </main>
    </div>
</div>
</body>
</html>