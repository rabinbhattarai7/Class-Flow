<?php
/* The timetable groups saved classes by weekday. Weekly classes repeat on the calendar while the timetable lists each class once. */
/* Weekly timetable: groups the user's recurring classes by weekday. */
session_start();
require_once '../include/database.php';

// Reject requests that do not have a signed-in user in the session.
if (!isset($_SESSION['user_id'])) {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: ../login.php');
    exit;
}

// Use the session account ID to scope database operations to the current user.
$userId = $_SESSION['user_id'];
$successMessage = '';

// Read this session value only when it exists.
if (isset($_SESSION['success_message'])) {
    $successMessage = $_SESSION['success_message'];
    // Remove the flash message so it is displayed only once.
    unset($_SESSION['success_message']);
}

// Prepare a lookup of classes using bound parameters. Restrict the query to the current account.
$stmt = $pdo->prepare("
    SELECT *
    FROM classes
    WHERE user_id = ?
    ORDER BY FIELD(day, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'), start_time
");
$stmt->execute([$userId]);
// Load all matching rows for the list or calculations below.
$classes = $stmt->fetchAll();

$days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
$weekStart = (new DateTimeImmutable('now', new DateTimeZone('Europe/Copenhagen')))
    ->modify('monday this week')->setTime(0, 0);
$weekdayDates = [];
foreach (['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'] as $offset => $weekday) {
    $weekdayDates[$weekday] = $weekStart->modify("+$offset days");
}
foreach (['Saturday','Sunday'] as $weekendDay) {
    if (in_array($weekendDay, array_column($classes,'day'), true)) $days[]=$weekendDay;
}
?>

<!DOCTYPE html>
<html lang="en">
<!-- Set the page title, character encoding, responsive viewport and stylesheet links. -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Timetable | ClassFlow</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=20261103b"><link rel="stylesheet" href="../css/theme.css?v=20261113-red1">
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <?php require_once 'sidebar.php'; ?>

        <!-- Main page content, positioned alongside the sidebar on dashboard pages. -->
        <main class="col-md-9 col-lg-10 p-4 dashboard-content">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="page-title mb-1">Weekly Timetable</h2>
                    <p class="text-muted mb-0">Manage your lectures, tutorials and lab classes.</p>
                </div>
                <div class="d-flex gap-2"><a href="import_timetable.php" class="btn btn-outline-primary"><i class="fa-solid fa-file-import me-1"></i> Import CSV / PDF</a>
                <a href="add_class.php" class="btn btn-add">
                    <i class="fa-solid fa-plus me-1"></i> Add Class
                </a>
                </div>
            </div>

            <?php if ($successMessage): ?>
                <div class="alert alert-success"><?= htmlspecialchars($successMessage) ?></div>
            <?php endif; ?>

            <div class="timetable-card mb-4">
                <div class="timetable-header">
                    <div>
                        <h5 class="mb-1">My Weekly Schedule</h5>
                        <p class="mb-0">Current week: <?= $weekStart->format('j M Y') ?> &ndash; <?= $weekStart->modify('+6 days')->format('j M Y') ?>. Dated classes appear only in their scheduled week.</p>
                    </div>
                    <div class="timetable-legend">
                        <span><i class="legend-dot lecture"></i>Lecture</span>
                        <span><i class="legend-dot tutorial"></i>Tutorial</span>
                        <span><i class="legend-dot lab"></i>Lab</span>
                    </div>
                </div>

                <div class="table-responsive">
                    <!-- Display the loaded records in a table with headings and row actions. -->
                    <table class="weekly-timetable">
                        <!-- Column headings describe the values displayed in each record row. -->
                        <thead>
                            <tr>
                                <th class="time-heading">
                                    <i class="fa-regular fa-clock"></i>
                                </th>
                                <?php foreach ($days as $day): ?>
                                    <th>
                                        <span class="day-name"><?= $day ?></span>
                                        <time class="d-block small fw-normal" datetime="<?= $weekdayDates[$day]->format('Y-m-d') ?>"><?= $weekdayDates[$day]->format('j M Y') ?></time>
                                    </th>
                                <?php endforeach; ?>
                            </tr>
                        </thead>
                        <!-- Render the record rows and any empty-state message. -->
                        <tbody>
                            <?php
                            $startHour = 8;
                            $endHour = 18;
                            foreach ($classes as $entry) {
                                $startHour=min($startHour,(int)substr($entry['start_time'],0,2));
                                $endHour=max($endHour,(int)substr($entry['end_time'],0,2)+(substr($entry['end_time'],3,2)!=='00'?1:0));
                            }

                            for ($hour = $startHour; $hour < $endHour; $hour++):
                                $slotStart = sprintf('%02d:00:00', $hour);
                                $slotEnd = sprintf('%02d:00:00', $hour + 1);
                            ?>
                                <tr>
                                    <td class="time-cell">
                                        <span>
                                            <?= date('g:i A', strtotime($slotStart)) ?>
                                            -
                                            <?= date('g:i A', strtotime($slotEnd)) ?>
                                        </span>
                                    </td>

                                    <?php foreach ($days as $day): ?>
                                        <?php
                                        $matchingClasses = [];

                                        // Process each item in this collection for the page or response.
                                        foreach ($classes as $class) {
                                            if (
                                                $class['day'] === $day &&
                                                (empty($class['class_date']) || $class['class_date'] === $weekdayDates[$day]->format('Y-m-d')) &&
                                                $class['start_time'] < $slotEnd &&
                                                $class['end_time'] > $slotStart
                                            ) {
                                                $matchingClasses[] = $class;
                                            }
                                        }
                                        ?>

                                        <?php if ($matchingClasses): ?>
                                            <td class="class-cell">
                                                <?php foreach ($matchingClasses as $currentClass): ?>
                                                <a href="view_class.php?id=<?= $currentClass['id'] ?>" class="timetable-class mb-2 <?= strtolower($currentClass['class_type']) ?>">
                                                    <div class="class-type-label">
                                                        <?= htmlspecialchars($currentClass['class_type']) ?>
                                                    </div>

                                                    <h6><?= htmlspecialchars($currentClass['subject_name']) ?></h6>

                                                    <div class="class-detail">
                                                        <i class="fa-regular fa-clock"></i>
                                                        <?= date('g:i A', strtotime($currentClass['start_time'])) ?>
                                                        -
                                                        <?= date('g:i A', strtotime($currentClass['end_time'])) ?>
                                                    </div>

                                                    <div class="class-detail">
                                                        <i class="fa-solid fa-location-dot"></i>
                                                        <?= htmlspecialchars($currentClass['room']) ?>
                                                    </div>
                                                </a>
                                                <?php endforeach; ?>
                                            </td>
                                        <?php else: ?>
                                            <td class="empty-cell">
                                                <span class="empty-line"></span>
                                            </td>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </tr>
                            <?php endfor; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="fw-bold mb-0">My Classes</h4>
                <span class="text-muted"><?= count($classes) ?> class<?= count($classes) === 1 ? '' : 'es' ?></span>
            </div>

            <div class="table-card">
                <div class="table-responsive">
                    <!-- Display the loaded records in a table with headings and row actions. -->
                    <table class="table table-hover align-middle mb-0">
                        <!-- Column headings describe the values displayed in each record row. -->
                        <thead>
                            <tr>
                                <th>Subject</th>
                                <th>Day / Date</th>
                                <th>Time</th>
                                <th>Room</th>
                                <th>Type</th>
                                <th>Lecturer</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <!-- Render the record rows and any empty-state message. -->
                        <tbody>
                            <?php if ($classes): ?>
                                <?php foreach ($classes as $class): ?>
                                    <tr>
                                        <td class="fw-semibold"><?= htmlspecialchars($class['subject_name']) ?></td>
                                        <td><?= htmlspecialchars($class['day']) ?><br><small><?= !empty($class['class_date']) ? htmlspecialchars((new DateTimeImmutable($class['class_date']))->format('j M Y')) : 'Repeats weekly' ?></small></td>
                                        <td><?= date('g:i A', strtotime($class['start_time'])) ?> - <?= date('g:i A', strtotime($class['end_time'])) ?></td>
                                        <td><?= htmlspecialchars($class['room']) ?></td>
                                        <td>
                                            <span class="class-type <?= strtolower($class['class_type']) ?>">
                                                <?= htmlspecialchars($class['class_type']) ?>
                                            </span>
                                        </td>
                                        <td><?= htmlspecialchars($class['lecturer_name']) ?></td>
                                        <td>
                                            <a href="view_class.php?id=<?= $class['id'] ?>" class="btn btn-sm btn-info text-white" title="View">
                                                <i class="fa-solid fa-eye"></i>
                                            </a>
                                            <a href="edit_class.php?id=<?= $class['id'] ?>" class="btn btn-sm btn-warning" title="Edit">
                                                <i class="fa-solid fa-pen-to-square"></i>
                                            </a>
                                            <form method="POST" action="delete_class.php" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this class?');">
                                                <input type="hidden" name="id" value="<?= (int) $class['id'] ?>">
                                                <button type="submit" class="btn btn-sm btn-danger" title="Delete">
                                                <i class="fa-solid fa-trash"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="text-center py-5">
                                        <i class="fa-regular fa-calendar-xmark fa-2x text-muted mb-3"></i>
                                        <p class="text-muted mb-2">No classes have been added yet.</p>
                                        <a href="add_class.php" class="btn btn-add btn-sm">Add Your First Class</a>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</div>
</body>
</html>
