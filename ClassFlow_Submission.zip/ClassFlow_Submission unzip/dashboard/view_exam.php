<?php
/* The details page reads one exam using both the record number and the signed-in student’s account number. */
/* Loads and displays the signed-in user's exam. */
session_start();
require_once '../include/database.php';

// Reject requests that do not have a signed-in user in the session.
if (!isset($_SESSION['user_id'])) {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: ../login.php');
    exit;
}

// Use the session account ID to scope database operations to the current user.
$userId = $_SESSION['user_id'];
// Read the requested record ID and require a valid integer.
$examId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$examId) {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: exams.php');
    exit;
}

// Prepare a lookup of exams using bound parameters. Restrict the query to the current account.
$stmt = $pdo->prepare("SELECT * FROM exams WHERE id = ? AND user_id = ?");
$stmt->execute([$examId, $userId]);
// Read the matching record; false means no row was found.
$exam = $stmt->fetch();

if (!$exam) {
    $_SESSION['error_message'] = 'Exam not found.';
    // Redirect the browser after processing; exit below stops further output.
    header('Location: exams.php');
    exit;
}

$examEnd = strtotime($exam['exam_date'] . ' ' . $exam['end_time']);
$isPast = $examEnd < time();
?>

<!DOCTYPE html>
<html lang="en">
<!-- Set the page title, character encoding, responsive viewport and stylesheet links. -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($exam['exam_name']) ?> | ClassFlow</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=20261103b"><link rel="stylesheet" href="../css/theme.css?v=20261113-red1">
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <?php require_once 'sidebar.php'; ?>

        <!-- Main page content, positioned alongside the sidebar on dashboard pages. -->
        <main class="col-md-9 col-lg-10 p-4 dashboard-content">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="page-title mb-1">Exam Details</h2>
                    <p class="text-muted mb-0">View your examination information.</p>
                </div>
                <a href="exams.php" class="btn btn-outline-secondary">
                    <i class="fa-solid fa-arrow-left me-1"></i> Back
                </a>
            </div>

            <div class="exam-details-card">
                <div class="exam-details-header">
                    <div>
                        <span class="exam-type-badge"><?= htmlspecialchars($exam['exam_type']) ?></span>
                        <h3><?= htmlspecialchars($exam['exam_name']) ?></h3>
                        <p class="mb-0">
                            <i class="fa-solid fa-book me-1"></i>
                            <?= htmlspecialchars($exam['module']) ?>
                        </p>
                    </div>

                    <div class="details-actions">
                        <a href="edit_exam.php?id=<?= $exam['id'] ?>" class="btn btn-light">
                            <i class="fa-solid fa-pen-to-square me-1"></i> Edit
                        </a>

                        <!-- Submit these fields using POST to the PHP handler named in the form action. -->
                        <form method="POST" action="delete_exam.php" onsubmit="return confirm('Are you sure you want to delete this exam?');">
                            <!-- Send this record identifier with the form; the server must still check ownership. -->
                            <input type="hidden" name="id" value="<?= $exam['id'] ?>">
                            <!-- Submit this form to its PHP handler. -->
                            <button type="submit" class="btn btn-danger">
                                <i class="fa-solid fa-trash me-1"></i> Delete
                            </button>
                        </form>
                    </div>
                </div>

                <div class="exam-details-body">
                    <?php if ($isPast): ?>
                        <div class="alert alert-secondary mb-4">
                            <i class="fa-solid fa-circle-check me-2"></i>This exam has passed.
                        </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-md-6 col-lg-3 mb-4">
                            <div class="detail-item">
                                <div class="detail-icon"><i class="fa-regular fa-calendar"></i></div>
                                <div>
                                    <span>Date</span>
                                    <strong><?= date('d M Y', strtotime($exam['exam_date'])) ?></strong>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 col-lg-3 mb-4">
                            <div class="detail-item">
                                <div class="detail-icon"><i class="fa-regular fa-clock"></i></div>
                                <div>
                                    <span>Time</span>
                                    <strong><?= date('g:i A', strtotime($exam['start_time'])) ?> - <?= date('g:i A', strtotime($exam['end_time'])) ?></strong>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 col-lg-3 mb-4">
                            <div class="detail-item">
                                <div class="detail-icon"><i class="fa-solid fa-location-dot"></i></div>
                                <div>
                                    <span>Location</span>
                                    <strong><?= htmlspecialchars($exam['location']) ?></strong>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 col-lg-3 mb-4">
                            <div class="detail-item">
                                <div class="detail-icon"><i class="fa-solid fa-file-pen"></i></div>
                                <div>
                                    <span>Exam Type</span>
                                    <strong><?= htmlspecialchars($exam['exam_type']) ?></strong>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="details-section">
                        <h6><i class="fa-solid fa-book me-2"></i>Module</h6>
                        <p><?= htmlspecialchars($exam['module']) ?></p>
                    </div>

                    <div class="details-section mb-0">
                        <h6><i class="fa-regular fa-note-sticky me-2"></i>Notes</h6>
                        <p class="mb-0">
                            <?= $exam['notes'] ? nl2br(htmlspecialchars($exam['notes'])) : '<span class="text-muted">No notes added.</span>' ?>
                        </p>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
</body>
</html>