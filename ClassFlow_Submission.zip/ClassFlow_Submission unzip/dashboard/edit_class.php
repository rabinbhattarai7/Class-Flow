<?php
/* This form loads an owned class, checks the submitted changes and updates that same record for the signed-in student. */
/* Loads an owned record, validates changes and updates the class. */
session_start();
require_once '../include/database.php';
require_once '../include/features.php';

// Reject requests that do not have a signed-in user in the session.
if (!isset($_SESSION['user_id'])) {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: ../login.php');
    exit;
}

// Use the session account ID to scope database operations to the current user.
$userId = $_SESSION['user_id'];
// Read the requested record ID and require a valid integer.
$classId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$message = '';

if (!$classId) {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: timetable.php');
    exit;
}

// Prepare a lookup of classes using bound parameters. Restrict the query to the current account.
$stmt = $pdo->prepare("SELECT * FROM classes WHERE id = ? AND user_id = ?");
$stmt->execute([$classId, $userId]);
// Read the matching record; false means no row was found.
$class = $stmt->fetch();

if (!$class) {
    $_SESSION['error_message'] = 'Class not found.';
    // Redirect the browser after processing; exit below stops further output.
    header('Location: timetable.php');
    exit;
}

$subjectName = $class['subject_name'];
$lecturerName = $class['lecturer_name'];
$day = $class['day'];
$classDate = $class['class_date'] ?? '';
$startTime = substr($class['start_time'], 0, 5);
$endTime = substr($class['end_time'], 0, 5);
$room = $class['room'];
$classType = $class['class_type'];
$notes = $class['notes'] ?? '';

// Restore an unsaved conflict draft without saving anything.
foreach (cf_draft_restore((int)$userId, 'class', $classId) as $field => $value) {
    $variable = cf_draft_fields('class')[$field] ?? null;
    if ($variable !== null) $variable = $value;
}

// Process submitted form values only on a POST request.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    cf_check_csrf();
    $subjectName = trim($_POST['subject_name'] ?? '');
    $lecturerName = trim($_POST['lecturer_name'] ?? '');
    $day = trim($_POST['day'] ?? '');
    $classDate = trim($_POST['class_date'] ?? '');
    $parsedClassDate = $classDate !== '' ? DateTimeImmutable::createFromFormat('!Y-m-d', $classDate) : null;
    $invalidClassDate = $classDate !== '' && (!$parsedClassDate || $parsedClassDate->format('Y-m-d') !== $classDate);
    if ($parsedClassDate && !$invalidClassDate) $day = $parsedClassDate->format('l');
    $startTime = trim($_POST['start_time'] ?? '');
    $endTime = trim($_POST['end_time'] ?? '');
    $room = trim($_POST['room'] ?? '');
    $classType = trim($_POST['class_type'] ?? '');
    $notes = trim($_POST['notes'] ?? '');

    // Define the values accepted by the server for this selection field.
    $validDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    // Define the values accepted by the server for this selection field.
    $validTypes = ['Lecture', 'Tutorial', 'Lab'];

    // Validate required values before continuing with database changes.
    if ($invalidClassDate) {
        $message = '<div class="alert alert-danger">Choose a valid class date.</div>';
    } elseif ($subjectName === '' || $lecturerName === '' || $day === '' || $startTime === '' || $endTime === '' || $room === '' || $classType === '') {
        $message = '<div class="alert alert-danger">Please fill in all required fields.</div>';
    } elseif (!in_array($day, $validDays, true)) {
        $message = '<div class="alert alert-danger">Please select a valid day.</div>';
    } elseif (!in_array($classType, $validTypes, true)) {
        $message = '<div class="alert alert-danger">Please select a valid class type.</div>';
    } elseif ($startTime >= $endTime) {
        $message = '<div class="alert alert-danger">End time must be later than start time.</div>';
    } elseif (($scheduleConflict = cf_schedule_conflict($pdo, (int) $userId, $classDate !== '' ? 'dated_class' : 'class', $classDate !== '' ? $classDate : $day, $startTime, $endTime, $classId)) && !cf_is_schedule_overlap($scheduleConflict)) {
        $message = '<div class="alert alert-danger">' . cf_escape($scheduleConflict) . '</div>';
    } else {
            // Prepare changes to the matching classes record. Restrict the query to the current account.
            $stmt = $pdo->prepare("
                UPDATE classes
                SET subject_name = ?, lecturer_name = ?, day = ?, class_date = ?, start_time = ?, end_time = ?, room = ?, class_type = ?, notes = ?
                WHERE id = ? AND user_id = ?
            ");

            if ($stmt->execute([$subjectName, $lecturerName, $day, $classDate !== '' ? $classDate : null, $startTime, $endTime, $room, $classType, $notes, $classId, $userId])) {
                cf_draft_clear((int)$userId, 'class', $classId);
                $_SESSION['success_message'] = 'Class updated successfully.';
                cf_saved_conflict_redirect($pdo, (int)$userId, 'class', $classId, $_POST, $scheduleConflict ?? null);
                // Redirect the browser after processing; exit below stops further output.
                header('Location: timetable.php');
                exit;
            }

            $message = '<div class="alert alert-danger">Unable to update class. Please try again.</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<!-- Set the page title, character encoding, responsive viewport and stylesheet links. -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Class | ClassFlow</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=20261103b"><link rel="stylesheet" href="../css/theme.css?v=20261113-red1">
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <?php require_once 'sidebar.php'; ?>

        <!-- Main page content, positioned alongside the sidebar on dashboard pages. -->
        <main class="col-md-9 col-lg-10 p-4 dashboard-content">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="page-title mb-1">Edit Class</h2>
                    <p class="text-muted mb-0">Update your timetable class information.</p>
                </div>
                <a href="timetable.php" class="btn btn-outline-secondary">
                    <i class="fa-solid fa-arrow-left me-1"></i> Back
                </a>
            </div>

            <?= $message ?>

            <div class="form-card">
                <!-- Submit these fields using POST to the PHP handler named in the form action. -->
                <form method="POST" action="">
                    <input type="hidden" name="csrf" value="<?= cf_csrf_token() ?>">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <!-- Input field: Module / Subject Name. -->
                            <label for="subject_name" class="form-label">Module / Subject Name</label>
                            <input type="text" class="form-control" id="subject_name" name="subject_name" value="<?= htmlspecialchars($subjectName) ?>" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <!-- Input field: Lecturer Name. -->
                            <label for="lecturer_name" class="form-label">Lecturer Name</label>
                            <input type="text" class="form-control" id="lecturer_name" name="lecturer_name" value="<?= htmlspecialchars($lecturerName) ?>" required>
                        </div>

                        <div class="col-md-4 mb-3">
                            <label for="class_date" class="form-label">Class date (optional)</label>
                            <input type="date" class="form-control mb-2" id="class_date" name="class_date" value="<?= htmlspecialchars($classDate) ?>">
                            <p class="form-text">Choose a date for a one-time class. Leave empty for a weekly class.</p>
                            <!-- Input field: Day. -->
                            <label for="day" class="form-label">Day</label>
                            <select class="form-select" id="day" name="day" required>
                                <option value="">Select day</option>
                                <?php foreach (['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'] as $option): ?>
                                    <option value="<?= $option ?>" <?= $day === $option ? 'selected' : '' ?>><?= $option ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-md-4 mb-3">
                            <!-- Input field: Start Time. -->
                            <label for="start_time" class="form-label">Start Time</label>
                            <input type="time" class="form-control" id="start_time" name="start_time" value="<?= htmlspecialchars($startTime) ?>" required>
                        </div>

                        <div class="col-md-4 mb-3">
                            <!-- Input field: End Time. -->
                            <label for="end_time" class="form-label">End Time</label>
                            <input type="time" class="form-control" id="end_time" name="end_time" value="<?= htmlspecialchars($endTime) ?>" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <!-- Input field: Room. -->
                            <label for="room" class="form-label">Room</label>
                            <input type="text" class="form-control" id="room" name="room" value="<?= htmlspecialchars($room) ?>" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <!-- Input field: Class Type. -->
                            <label for="class_type" class="form-label">Class Type</label>
                            <select class="form-select" id="class_type" name="class_type" required>
                                <option value="">Select class type</option>
                                <option value="Lecture" <?= $classType === 'Lecture' ? 'selected' : '' ?>>Lecture</option>
                                <option value="Tutorial" <?= $classType === 'Tutorial' ? 'selected' : '' ?>>Tutorial</option>
                                <option value="Lab" <?= $classType === 'Lab' ? 'selected' : '' ?>>Lab</option>
                            </select>
                        </div>

                        <div class="col-12 mb-3">
                            <label for="notes" class="form-label">Notes <span class="text-muted">(Optional)</span></label>
                            <textarea class="form-control" id="notes" name="notes" rows="4"><?= htmlspecialchars($notes) ?></textarea>
                        </div>
                    </div>

                    <!-- Submit this form to its PHP handler. -->
                    <button type="submit" class="btn btn-save">
                        <i class="fa-solid fa-floppy-disk me-1"></i> Update Class
                    </button>
                </form>
            </div>
        </main>
    </div>
</div>
<script>
const classDateInput = document.getElementById('class_date');
const weekdayInput = document.getElementById('day');
function updateWeekday() {
    const parts = classDateInput.value.split('-').map(Number);
    if (classDateInput.value && parts.length === 3) {
        weekdayInput.value = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'][new Date(parts[0], parts[1] - 1, parts[2]).getDay()];
    }
    weekdayInput.disabled = Boolean(classDateInput.value);
}
classDateInput.addEventListener('change', updateWeekday);
updateWeekday();
</script>
</body>
</html>