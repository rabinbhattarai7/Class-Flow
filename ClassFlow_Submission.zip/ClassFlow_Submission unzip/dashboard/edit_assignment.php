<?php
/* This form loads an owned assignment, checks the submitted changes and updates that same record for the signed-in student. */
/* Loads an owned record, validates changes and updates the assignment. */
session_start();
require_once '../include/database.php';

// Reject requests that do not have a signed-in user in the session.
if (!isset($_SESSION['user_id'])) {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: ../login.php');
    exit;
}

// Use the session account ID to scope database operations to the current user.
$userId = $_SESSION['user_id'];
// Read the requested record ID and require a valid integer.
$assignmentId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$message = '';

if (!$assignmentId) {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: assignments.php');
    exit;
}

// Prepare a lookup of assignments using bound parameters. Restrict the query to the current account.
$stmt = $pdo->prepare("SELECT * FROM assignments WHERE id = ? AND user_id = ?");
$stmt->execute([$assignmentId, $userId]);
// Read the matching record; false means no row was found.
$assignment = $stmt->fetch();

if (!$assignment) {
    $_SESSION['error_message'] = 'Assignment not found.';
    // Redirect the browser after processing; exit below stops further output.
    header('Location: assignments.php');
    exit;
}

$title = $assignment['title'];
$module = $assignment['module'];
$description = $assignment['description'] ?? '';
$dueDate = $assignment['due_date'];
$dueTime = substr($assignment['due_time'], 0, 5);
$priority = $assignment['priority'];
$status = $assignment['status'];

// Process submitted form values only on a POST request.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $module = trim($_POST['module'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $dueDate = trim($_POST['due_date'] ?? '');
    $dueTime = trim($_POST['due_time'] ?? '');
    $priority = trim($_POST['priority'] ?? '');
    $status = trim($_POST['status'] ?? '');

    // Define the values accepted by the server for this selection field.
    $validPriorities = ['Low', 'Medium', 'High'];
    // Define the values accepted by the server for this selection field.
    $validStatuses = ['Pending', 'In Progress', 'Completed'];
    // Define the values accepted by the server for this selection field.

    // Validate required values before continuing with database changes.
    if ($title === '' || $module === '' || $dueDate === '' || $dueTime === '' || $priority === '' || $status === '') {
        $message = '<div class="alert alert-danger">Please fill in all required fields.</div>';
    } elseif (!in_array($priority, $validPriorities, true)) {
        $message = '<div class="alert alert-danger">Please select a valid priority.</div>';
    } elseif (!in_array($status, $validStatuses, true)) {
        $message = '<div class="alert alert-danger">Please select a valid status.</div>';
    } else {
        // Prepare changes to the matching assignments record. Restrict the query to the current account.
        $stmt = $pdo->prepare("
            UPDATE assignments
            SET title = ?, module = ?, description = ?, due_date = ?, due_time = ?, priority = ?, status = ?
            WHERE id = ? AND user_id = ?
        ");
        if ($stmt->execute([$title, $module, $description, $dueDate, $dueTime, $priority, $status, $assignmentId, $userId])) {
            $_SESSION['success_message'] = 'Assignment updated successfully.';
            // Redirect the browser after processing; exit below stops further output.
            header('Location: assignments.php');
            exit;
        }
        $message = '<div class="alert alert-danger">Unable to update assignment. Please try again.</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<!-- Set the page title, character encoding, responsive viewport and stylesheet links. -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Assignment | ClassFlow</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=20261103b"><link rel="stylesheet" href="../css/theme.css?v=20261113-red1">
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <?php require_once 'sidebar.php'; ?>
        <!-- Main page content, positioned alongside the sidebar on dashboard pages. -->
        <main class="col-md-9 col-lg-10 p-4 dashboard-content">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="page-title mb-1">Edit Assignment</h2>
                    <p class="text-muted mb-0">Update coursework information and deadline.</p>
                </div>
                <a href="assignments.php" class="btn btn-outline-secondary">
                    <i class="fa-solid fa-arrow-left me-1"></i> Back
                </a>
            </div>

            <?= $message ?>

            <div class="form-card">
                <!-- Submit these fields using POST to the PHP handler named in the form action. -->
                <form method="POST">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <!-- Input field: Assignment Title. -->
                            <label for="title" class="form-label">Assignment Title</label>
                            <input type="text" class="form-control" id="title" name="title" value="<?= htmlspecialchars($title) ?>" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <!-- Input field: Module. -->
                            <label for="module" class="form-label">Module</label>
                            <input type="text" class="form-control" id="module" name="module" value="<?= htmlspecialchars($module) ?>" required>
                        </div>

                        <div class="col-12 mb-3">
                            <label for="description" class="form-label">Description <span class="text-muted">(Optional)</span></label>
                            <textarea class="form-control" id="description" name="description" rows="4"><?= htmlspecialchars($description) ?></textarea>
                        </div>

                        <div class="col-md-6 mb-3">
                            <!-- Input field: Due Date. -->
                            <label for="due_date" class="form-label">Due Date</label>
                            <input type="date" class="form-control" id="due_date" name="due_date" value="<?= htmlspecialchars($dueDate) ?>" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <!-- Input field: Due Time. -->
                            <label for="due_time" class="form-label">Due Time</label>
                            <input type="time" class="form-control" id="due_time" name="due_time" value="<?= htmlspecialchars($dueTime) ?>" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <!-- Input field: Priority. -->
                            <label for="priority" class="form-label">Priority</label>
                            <select class="form-select" id="priority" name="priority" required>
                                <option value="Low" <?= $priority === 'Low' ? 'selected' : '' ?>>Low</option>
                                <option value="Medium" <?= $priority === 'Medium' ? 'selected' : '' ?>>Medium</option>
                                <option value="High" <?= $priority === 'High' ? 'selected' : '' ?>>High</option>
                            </select>
                        </div>

                        <div class="col-md-6 mb-3">
                            <!-- Input field: Status. -->
                            <label for="status" class="form-label">Status</label>
                            <select class="form-select" id="status" name="status" required>
                                <option value="Pending" <?= $status === 'Pending' ? 'selected' : '' ?>>Pending</option>
                                <option value="In Progress" <?= $status === 'In Progress' ? 'selected' : '' ?>>In Progress</option>
                                <option value="Completed" <?= $status === 'Completed' ? 'selected' : '' ?>>Completed</option>
                            </select>
                        </div>

                    </div>

                    <!-- Submit this form to its PHP handler. -->
                    <button type="submit" class="btn btn-save">
                        <i class="fa-solid fa-floppy-disk me-1"></i> Update Assignment
                    </button>
                </form>
            </div>
        </main>
    </div>
</div>
</body>
</html>