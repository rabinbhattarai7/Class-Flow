<?php
/* This handler deletes the requested exam only when it belongs to the signed-in student. */
/* Accepts a POST request and deletes the signed-in user's exam. */
session_start();
require_once '../include/database.php';

// Reject requests that do not have a signed-in user in the session.
if (!isset($_SESSION['user_id'])) {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: ../login.php');
    exit;
}

// Require a form submission before performing this state-changing action.
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: exams.php');
    exit;
}

// Use the session account ID to scope database operations to the current user.
$userId = $_SESSION['user_id'];
// Read the requested record ID and require a valid integer.
$examId = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

if (!$examId) {
    $_SESSION['error_message'] = 'Invalid exam.';
    // Redirect the browser after processing; exit below stops further output.
    header('Location: exams.php');
    exit;
}

// Prepare deletion of the matching exams record. Restrict the query to the current account.
$stmt = $pdo->prepare("DELETE FROM exams WHERE id = ? AND user_id = ?");
$stmt->execute([$examId, $userId]);

// Check whether the database operation actually changed a matching record.
if ($stmt->rowCount() > 0) {
    $_SESSION['success_message'] = 'Exam deleted successfully.';
} else {
    $_SESSION['error_message'] = 'Exam not found or could not be deleted.';
}

// Redirect the browser after processing; exit below stops further output.
header('Location: exams.php');
exit;