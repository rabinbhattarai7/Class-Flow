<?php
/* Students can view or change their own account information. A password change requires confirmation of the current password. */
/* Profile page: updates account details and checks the current password before changing it. */
session_start();
require_once '../include/database.php';

// Reject requests that do not have a signed-in user in the session.
if (!isset($_SESSION['user_id'])) {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: ../login.php');
    exit;
}

// Use the session account ID to scope database operations to the current user.
$userId = $_SESSION['user_id'];
$message = '';
$passwordMessage = '';

// Prepare a lookup of users using bound parameters.
$stmt = $pdo->prepare("SELECT id, first_name, last_name, email, created_at FROM users WHERE id = ?");
$stmt->execute([$userId]);
// Read the matching record; false means no row was found.
$user = $stmt->fetch();

if (!$user) {
    session_destroy();
    // Redirect the browser after processing; exit below stops further output.
    header('Location: ../login.php');
    exit;
}

// Handle the form action identified by this submitted button or field.
if (isset($_POST['update_profile'])) {
    $firstName = trim($_POST['first_name'] ?? '');
    $lastName = trim($_POST['last_name'] ?? '');
    $email = trim($_POST['email'] ?? '');

    // Validate required values before continuing with database changes.
    if ($firstName === '' || $lastName === '' || $email === '') {
        $message = '<div class="alert alert-danger">Please fill in all profile fields.</div>';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = '<div class="alert alert-danger">Please enter a valid email address.</div>';
    } else {
        // Prepare a lookup of users using bound parameters. Exclude the current record from this check.
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $stmt->execute([$email, $userId]);

        if ($stmt->fetch()) {
            $message = '<div class="alert alert-danger">This email address is already in use.</div>';
        } else {
            // Prepare changes to the matching users record.
            $stmt = $pdo->prepare("
                UPDATE users
                SET first_name = ?, last_name = ?, email = ?
                WHERE id = ?
            ");

            if ($stmt->execute([$firstName, $lastName, $email, $userId])) {
                $_SESSION['first_name'] = $firstName;
                $_SESSION['last_name'] = $lastName;
                $_SESSION['email'] = $email;

                $user['first_name'] = $firstName;
                $user['last_name'] = $lastName;
                $user['email'] = $email;

                $message = '<div class="alert alert-success">Profile updated successfully.</div>';
            } else {
                $message = '<div class="alert alert-danger">Unable to update profile.</div>';
            }
        }
    }
}

// Handle the form action identified by this submitted button or field.
if (isset($_POST['change_password'])) {
    $currentPassword = $_POST['current_password'] ?? '';
    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    // Validate required values before continuing with database changes.
    if ($currentPassword === '' || $newPassword === '' || $confirmPassword === '') {
        $passwordMessage = '<div class="alert alert-danger">Please fill in all password fields.</div>';
    } elseif (strlen($newPassword) < 8) {
        $passwordMessage = '<div class="alert alert-danger">New password must be at least 8 characters.</div>';
    } elseif ($newPassword !== $confirmPassword) {
        $passwordMessage = '<div class="alert alert-danger">New passwords do not match.</div>';
    } else {
        // Prepare a lookup of users using bound parameters.
        $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $storedPassword = $stmt->fetchColumn();

        // Check the submitted password against the stored one-way password hash.
        // Require the current password before accepting a change from the signed-in profile. Knowing only the account email is insufficient.
        if (!$storedPassword || !password_verify($currentPassword, $storedPassword)) {
            $passwordMessage = '<div class="alert alert-danger">Current password is incorrect.</div>';
        } else {
            // Hash the new password before saving it; never store the original password text.
            // Create a fresh hash for the replacement password. Subsequent sign-ins will verify the new password against this value.
            $newPasswordHash = password_hash($newPassword, PASSWORD_DEFAULT);

            // Prepare changes to the matching users record.
            $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");

            if ($stmt->execute([$newPasswordHash, $userId])) {
                $passwordMessage = '<div class="alert alert-success">Password changed successfully.</div>';
            } else {
                $passwordMessage = '<div class="alert alert-danger">Unable to change password.</div>';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<!-- Set the page title, character encoding, responsive viewport and stylesheet links. -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile | ClassFlow</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=20261103b"><link rel="stylesheet" href="../css/theme.css?v=20261113-red1">
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <?php require_once 'sidebar.php'; ?>

        <!-- Main page content, positioned alongside the sidebar on dashboard pages. -->
        <main class="col-md-9 col-lg-10 p-4 dashboard-content">
            <div class="mb-4">
                <h2 class="page-title mb-1">Profile</h2>
                <p class="text-muted mb-0">Manage your personal information and account password.</p>
            </div>

            <div class="profile-header mb-4">
                <div class="profile-avatar">
                    <?= strtoupper(substr($user['first_name'], 0, 1) . substr($user['last_name'], 0, 1)) ?>
                </div>

                <div>
                    <h4 class="mb-1">
                        <?= htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?>
                    </h4>
                    <p class="text-muted mb-1"><?= htmlspecialchars($user['email']) ?></p>
                    <span class="badge bg-primary">Student</span>
                </div>
            </div>

            <div class="row g-4">
                <div class="col-lg-7">
                    <div class="form-card h-100">
                        <div class="mb-4">
                            <h5 class="mb-1">Personal Information</h5>
                            <p class="text-muted small mb-0">Update your account details.</p>
                        </div>

                        <?= $message ?>

                        <!-- Submit these fields using POST to the PHP handler named in the form action. -->
                        <form method="POST">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <!-- Input field: First Name. -->
                                    <label for="first_name" class="form-label">First Name</label>
                                    <input type="text" class="form-control" id="first_name" name="first_name" value="<?= htmlspecialchars($user['first_name']) ?>" required>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <!-- Input field: Last Name. -->
                                    <label for="last_name" class="form-label">Last Name</label>
                                    <input type="text" class="form-control" id="last_name" name="last_name" value="<?= htmlspecialchars($user['last_name']) ?>" required>
                                </div>

                                <div class="col-12 mb-3">
                                    <!-- Input field: Email Address. -->
                                    <label for="email" class="form-label">Email Address</label>
                                    <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
                                </div>

                                <div class="col-12 mb-4">
                                    <!-- Input field: Member Since. -->
                                    <label class="form-label">Member Since</label>
                                    <input type="text" class="form-control" value="<?= date('d F Y', strtotime($user['created_at'])) ?>" disabled>
                                </div>
                            </div>

                            <!-- Submit this form to its PHP handler. -->
                            <button type="submit" name="update_profile" class="btn btn-save">
                                <i class="fa-solid fa-floppy-disk me-1"></i>
                                Save Changes
                            </button>
                        </form>
                    </div>
                </div>

                <div class="col-lg-5">
                    <div class="form-card h-100">
                        <div class="mb-4">
                            <h5 class="mb-1">Change Password</h5>
                            <p class="text-muted small mb-0">Use a strong password for your account.</p>
                        </div>

                        <?= $passwordMessage ?>

                        <!-- Submit these fields using POST to the PHP handler named in the form action. -->
                        <form method="POST">
                            <div class="mb-3">
                                <!-- Input field: Current Password. -->
                                <label for="current_password" class="form-label">Current Password</label>
                                <div class="password-field">
                                    <input type="password" class="form-control" id="current_password" name="current_password" required>
                                    <button type="button" class="password-toggle" onclick="togglePassword('current_password', this)">
                                        <i class="fa-regular fa-eye"></i>
                                    </button>
                                </div>
                            </div>

                            <div class="mb-3">
                                <!-- Input field: New Password. -->
                                <label for="new_password" class="form-label">New Password</label>
                                <div class="password-field">
                                    <input type="password" class="form-control" id="new_password" name="new_password" minlength="8" required>
                                    <button type="button" class="password-toggle" onclick="togglePassword('new_password', this)">
                                        <i class="fa-regular fa-eye"></i>
                                    </button>
                                </div>
                                <small class="text-muted">Minimum 8 characters.</small>
                            </div>

                            <div class="mb-4">
                                <!-- Input field: Confirm New Password. -->
                                <label for="confirm_password" class="form-label">Confirm New Password</label>
                                <div class="password-field">
                                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" minlength="8" required>
                                    <button type="button" class="password-toggle" onclick="togglePassword('confirm_password', this)">
                                        <i class="fa-regular fa-eye"></i>
                                    </button>
                                </div>
                            </div>

                            <!-- Submit this form to its PHP handler. -->
                            <button type="submit" name="change_password" class="btn btn-save">
                                <i class="fa-solid fa-key me-1"></i>
                                Change Password
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
// Switch the chosen password field between masked and readable text and update its icon.
function togglePassword(inputId, button) {
    const input = document.getElementById(inputId);
    const icon = button.querySelector('i');

    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}
</script>
</body>
</html>