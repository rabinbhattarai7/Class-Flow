<?php
/* This page checks for an existing category name before attempting to save a new one. */
/* Category form: checks for a duplicate name and inserts a category through a mysqli connection. */
session_start();
include '../include/connect.php';

$message = "";

// Handle the form action identified by this submitted button or field.
if (isset($_POST['save_category'])) {
    $category_name = trim($_POST['category_name']);
    $status = trim($_POST['status']);

    if (!empty($category_name) && !empty($status)) {
        $check_sql = "SELECT id FROM categories WHERE category_name = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("s", $category_name);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();

        if ($check_result->num_rows > 0) {
            $message = "<div class='alert alert-warning'>Category already exists.</div>";
        } else {
            $sql = "INSERT INTO categories (category_name, status) VALUES (?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $category_name, $status);

            if ($stmt->execute()) {
                $_SESSION['success_message'] = "Category added successfully.";
                // Redirect the browser after processing; exit below stops further output.
                header("Location: categories.php");
                exit();
            } else {
                $message = "<div class='alert alert-danger'>Error: Unable to add category.</div>";
            }

            $stmt->close();
        }

        $check_stmt->close();
    } else {
        $message = "<div class='alert alert-danger'>Please fill in all fields.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<!-- Set the page title, character encoding, responsive viewport and stylesheet links. -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Category</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=20261103b"><link rel="stylesheet" href="../css/theme.css?v=20261113-red1">
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <?php require_once 'sidebar.php'; ?>
        <div class="col-md-9 col-lg-10 p-4">
            <h2 class="page-title">Add Category</h2>
            <?php echo $message; ?>
            <div class="form-card">
                <!-- Submit these fields using POST to the PHP handler named in the form action. -->
                <form method="POST" action="">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <!-- Input field: Category Name. -->
                            <label class="form-label">Category Name</label>
                            <input type="text" name="category_name" class="form-control" placeholder="Enter category name">
                        </div>
                        <div class="col-md-6 mb-3">
                            <!-- Input field: Status. -->
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                <option value="">Select status</option>
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                            </select>
                        </div>
                    </div>
                    <!-- Submit this form to its PHP handler. -->
                    <button type="submit" name="save_category" class="btn btn-save"><i class="fa-solid fa-plus me-1"></i> Add Category</button>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
</html>