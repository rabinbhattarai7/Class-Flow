<?php
/* The tracker checks for clashes in a thirty-day date range and can suggest times to move an overlapping study session. */
session_start();
require_once '../include/database.php';
require_once '../include/features.php';
if (!isset($_SESSION['user_id'])) { header('Location: ../login.php'); exit; }
$userId = (int) $_SESSION['user_id'];
$draftToken = (string)($_GET['draft'] ?? $_SESSION['cf_latest_conflict'] ?? '');
$draft = cf_draft_get($userId, $draftToken);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    cf_check_csrf();
    $discard = (string)($_POST['discard_draft'] ?? '');
    if (cf_draft_get($userId, $discard)) unset($_SESSION['cf_conflict_drafts'][$discard]);
    if (($_SESSION['cf_latest_conflict'] ?? '') === $discard) unset($_SESSION['cf_latest_conflict']);
    header('Location: conflicts.php'); exit;
}
$preview = $draft ? cf_draft_preview($pdo, $userId, $draft) : null;
if ($draft) $_SESSION['cf_conflict_drafts'][$draftToken]['slots'] = $preview['slots'];
// This page only needs the existing scheduling tables; it works before migration too.
$zone = new DateTimeZone(cf_feature_ready($pdo) ? cf_preferences($pdo,$userId)['timezone'] : 'Europe/Copenhagen');
$today = new DateTimeImmutable('today', $zone);
$value = (string) ($_GET['from'] ?? $today->format('Y-m-d'));
$from = DateTimeImmutable::createFromFormat('!Y-m-d', $value, $zone);
if (!$from || $from->format('Y-m-d') !== $value) $from = $today;
// Include the selected first date and the following twenty-nine days in the conflict search.
$to = $from->modify('+29 days');
$events = cf_events(cf_rows($pdo,'classes',$userId),cf_rows($pdo,'exams',$userId),cf_rows($pdo,'study_sessions',$userId),$from,$to);
// Pass the expanded schedule to the overlap checker so weekly classes can be compared with dated activities.
$conflicts = cf_conflicts($events);
cf_page_start('Conflict tracker');
?>
<?php if (isset($_SESSION['cf_saved_conflict'])): ?><div class="alert alert-warning"><?= cf_escape($_SESSION['cf_saved_conflict']) ?></div><?php unset($_SESSION['cf_saved_conflict']); endif; ?>
<?php if ($draft): ?>
<section class="form-card mb-4 border border-warning">
<h3>Unsaved draft: <?= cf_escape($preview['title']) ?></h3>
<p><strong>Not saved.</strong> <?= cf_escape($preview['date']) ?>, <?= cf_escape($draft['fields']['start_time'].'–'.$draft['fields']['end_time']) ?>. This preview is separate from your saved schedule.</p>
<?php if ($preview['clashes']): ?>
<p>This draft overlaps:</p><ul>
<?php foreach ($preview['clashes'] as $event): ?>
<li><?= cf_escape($event['title'].' — '.$event['date'].' '.$event['start'].'–'.$event['end']) ?>
<a href="edit_<?= cf_escape($event['type']) ?>.php?id=<?= (int)$event['id'] ?>">Edit saved activity</a></li>
<?php endforeach; ?></ul>
<?php else: ?><p class="text-success">The original clash is no longer present. Return to the form to review and save.</p><?php endif; ?>
<h4>Alternative times</h4>
<p class="text-muted">Same duration (<?= (int)$preview['minutes'] ?> minutes), between 08:00 and 20:00. Choosing a time fills the form; you must review and save it. Availability is checked again when saving.</p>
<?php foreach ($preview['slots'] as $slot): ?>
<a class="btn btn-outline-primary me-2 mb-2" href="<?= cf_escape(cf_draft_form_url($draftToken,$draft,$slot)) ?>">Use <?= cf_escape($slot) ?></a>
<?php endforeach; ?>
<?php if (!$preview['slots']): ?><p>No available slot of this length was found. Return to the form and choose another date or shorter duration.</p><?php endif; ?>
<?php if ($draft['kind'] !== 'study_session'): ?><p class="text-muted">Check your official timetable before changing a class or exam time.</p><?php endif; ?>
<a class="btn btn-primary" href="<?= cf_escape(cf_draft_form_url($draftToken,$draft)) ?>">Return to form</a>
<form method="post" class="d-inline"><input type="hidden" name="csrf" value="<?= cf_escape(cf_csrf_token()) ?>"><input type="hidden" name="discard_draft" value="<?= cf_escape($draftToken) ?>"><button class="btn btn-outline-secondary">Discard draft</button></form>
</section>
<?php elseif (isset($_GET['draft'])): ?><div class="alert alert-info">This draft has expired or is unavailable. Open the original form and try again.</div><?php endif; ?>
<h3>Saved schedule</h3>
<p class="text-muted">Review overlaps between weekly classes, exams and incomplete study sessions. Adjacent events do not count as conflicts. Assignment deadlines are not included because a deadline has no duration.</p>
<form class="d-flex gap-2 mb-4" method="get"><label for="from" class="align-self-center">30 days from</label><input class="form-control w-auto" type="date" name="from" id="from" value="<?= cf_escape($from->format('Y-m-d')) ?>" required><button class="btn btn-primary">Check dates</button></form>
<?php if (!$conflicts): ?><div class="alert alert-success">No overlaps between saved activities in this date range. Rejected entries are not saved activities.</div><?php endif; ?>
<?php foreach ($conflicts as [$a,$b]): ?>
<section class="form-card mb-3"><h4><?= cf_escape($a['date']) ?> · <?= cf_escape($a['title']) ?> overlaps <?= cf_escape($b['title']) ?></h4>
<p><?= cf_escape($a['start'].'–'.$a['end']) ?> and <?= cf_escape($b['start'].'–'.$b['end']) ?></p>
<?php foreach ([$a,$b] as $e): ?><a class="btn btn-outline-primary me-2 mb-2" href="edit_<?= $e['type'] ?>.php?id=<?= (int)$e['id'] ?>">Edit <?= cf_escape($e['title']) ?></a><?php endforeach; ?>
<?php $move = $a['type']==='study_session' ? $a : ($b['type']==='study_session' ? $b : null);
if ($move):
    $minutes=(int)((strtotime($move['end'])-strtotime($move['start']))/60);
    $slots=cf_free_slots($events,$move['date'],$minutes);
?><p class="mb-0 text-muted">Free alternatives for this study session, between 08:00 and 20:00: <?= $slots ? cf_escape(implode(', ',$slots)) : 'none on this day; choose another date.' ?>. Use Edit to choose a new time.</p><?php else: ?><p class="mb-0 text-muted">Check the official timetable before changing a class or exam.</p><?php endif; ?>
</section><?php endforeach; ?>
<?php cf_page_end(); ?>
