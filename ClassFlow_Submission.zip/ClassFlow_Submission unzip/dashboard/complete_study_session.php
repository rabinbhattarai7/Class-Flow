<?php
/* This handler marks an owned study session as completed so ClassFlow can reflect its new progress in the relevant views. */
/* POST handler: marks an owned study session as completed. */
session_start();
require_once '../include/database.php';

// Reject requests that do not have a signed-in user in the session.
if (!isset($_SESSION['user_id'])) {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: ../login.php');
    exit;
}

// Require a form submission before performing this state-changing action.
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    // Redirect the browser after processing; exit below stops further output.
    header('Location: study_planner.php');
    exit;
}

// Use the session account ID to scope database operations to the current user.
$userId = $_SESSION['user_id'];
// Read the requested record ID and require a valid integer.
$sessionId = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

if (!$sessionId) {
    $_SESSION['error_message'] = 'Invalid study session.';
    // Redirect the browser after processing; exit below stops further output.
    header('Location: study_planner.php');
    exit;
}

// Prepare changes to the matching study sessions record. Restrict the query to the current account.
$stmt = $pdo->prepare("
    UPDATE study_sessions
    SET status = 'Completed'
    WHERE id = ? AND user_id = ?
");

$stmt->execute([$sessionId, $userId]);

// Check whether the database operation actually changed a matching record.
if ($stmt->rowCount() > 0) {
    $_SESSION['success_message'] = 'Study session marked as completed.';
} else {
    $_SESSION['error_message'] = 'Study session not found or already completed.';
}

// Redirect the browser after processing; exit below stops further output.
header('Location: study_planner.php');
exit;