<?php
/* The sidebar lists dashboard pages and highlights the one currently open so students can see where they are. */
$cfCurrentPage = basename($_SERVER['SCRIPT_NAME'] ?? '');
if (in_array($cfCurrentPage, ['import_timetable.php','add_class.php','edit_class.php','view_class.php'], true)) $cfCurrentPage = 'timetable.php';
$cfFirst = trim((string)($_SESSION['first_name'] ?? 'Student'));
$cfLast = trim((string)($_SESSION['last_name'] ?? ''));
$cfInitials = strtoupper(substr($cfFirst,0,1) . substr($cfLast,0,1));
$cfDisplayName = trim($cfFirst . ' ' . $cfLast);
?>
<header class="cf-topbar">
    <div class="cf-topbar-brand">
        <button class="cf-menu-toggle" id="cf-menu-toggle" type="button" aria-label="Open navigation" aria-expanded="false" aria-controls="cf-navigation"><i class="fa-solid fa-bars" aria-hidden="true"></i></button>
        <a href="index.php" class="cf-wordmark"><i class="fa-regular fa-calendar-check" aria-hidden="true"></i> ClassFlow<span class="cf-brand-dot">.</span></a>
    </div>
    <span class="cf-topbar-caption">Your student workspace</span>
    <div class="cf-topbar-actions">
        <a class="cf-topbar-icon" href="reminders.php" aria-label="View reminders" title="Reminders"><i class="fa-regular fa-bell" aria-hidden="true"></i></a>
        <details class="cf-help-menu">
            <summary class="cf-topbar-icon" aria-label="Quick help" title="Quick help"><i class="fa-regular fa-circle-question" aria-hidden="true"></i></summary>
            <div class="cf-help-panel"><strong>A little help?</strong><p>Add your classes, plan study time and keep track of deadlines.</p><a href="add_class.php">Add a class <span aria-hidden="true">→</span></a><a href="conflicts.php">Review schedule conflicts <span aria-hidden="true">→</span></a></div>
        </details>
        <a class="cf-user-link" href="profile.php" aria-label="View your profile"><span class="cf-user-name"><?= htmlspecialchars($cfDisplayName, ENT_QUOTES, 'UTF-8') ?></span><span class="cf-avatar"><?= htmlspecialchars($cfInitials ?: 'S', ENT_QUOTES, 'UTF-8') ?></span></a>
    </div>
</header>
<button class="cf-nav-backdrop" id="cf-nav-backdrop" aria-label="Close navigation" type="button" hidden></button>
<script src="../js/interface.js?v=20261113-red1" defer></script>
<!-- Shared dashboard navigation linking the scheduling pages, profile and logout. -->
<nav class="col-md-3 col-lg-2 sidebar" id="cf-navigation" aria-label="Main navigation">
    <p class="cf-nav-label">MY WORKSPACE</p>
    <h3><svg class="cf-brand-mark" viewBox="0 0 28 28" fill="none" aria-hidden="true" focusable="false"><rect x="3.5" y="5.5" width="21" height="19" rx="4" stroke="currentColor" stroke-width="1.7"/><path d="M9 3.5v4M19 3.5v4M4 11h20M9 16h3M9 20h3M16 18l2 2 4-5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>ClassFlow</h3>
    <a href="index.php" class="<?= $cfCurrentPage === 'index.php' ? 'active' : '' ?>">
        <i class="fa-solid fa-chart-line me-2"></i> Dashboard
    </a>
    <a href="calendar.php" class="<?= $cfCurrentPage === 'calendar.php' ? 'active' : '' ?>">
        <i class="fa-solid fa-calendar-check me-2"></i> Calendar
    </a>
    <a href="timetable.php" class="<?= $cfCurrentPage === 'timetable.php' ? 'active' : '' ?>">
        <i class="fa-solid fa-calendar-days me-2"></i> Timetable
    </a>

    <a href="assignments.php" class="<?= $cfCurrentPage === 'assignments.php' ? 'active' : '' ?>">
        <i class="fa-solid fa-book me-2"></i> Assignments
    </a>

    <a href="exams.php" class="<?= $cfCurrentPage === 'exams.php' ? 'active' : '' ?>">
        <i class="fa-solid fa-file-pen me-2"></i> Exams
    </a>

    <a href="study_planner.php" class="<?= $cfCurrentPage === 'study_planner.php' ? 'active' : '' ?>">
        <i class="fa-solid fa-clock me-2"></i> Study Planner
    </a>
    <a href="reminders.php" class="<?= $cfCurrentPage === 'reminders.php' ? 'active' : '' ?>">
        <i class="fa-solid fa-calendar-check me-2"></i> Reminders
    </a>
    <a href="email_reminders.php" class="<?= $cfCurrentPage === 'email_reminders.php' ? 'active' : '' ?>">
        <i class="fa-solid fa-envelope me-2"></i> Email Reminders
    </a>
    <a href="conflicts.php" class="<?= $cfCurrentPage === 'conflicts.php' ? 'active' : '' ?>">
        <i class="fa-solid fa-triangle-exclamation me-2"></i> Conflict Tracker
    </a>
    <a href="profile.php" class="<?= $cfCurrentPage === 'profile.php' ? 'active' : '' ?>">
        <i class="fa-solid fa-user me-2"></i> Profile
    </a>

    <a href="../logout.php">
        <i class="fa-solid fa-right-from-bracket me-2"></i> Logout
    </a>
<div class="cf-sidebar-note"><span class="cf-status-dot"></span> A little planning. More headspace.</div></nav>
