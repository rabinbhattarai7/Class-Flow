# ClassFlow

ClassFlow is a student planner for classes, assignments, exams and study sessions. You can enter classes yourself or import a timetable from a CSV file or a supported text-based PDF. The app can flag schedule clashes and show upcoming reminders.

## What you need

- Windows with XAMPP and PHP 8.2 or later
- The PHP extensions `pdo_mysql` for the database and `mbstring` for PDF import
- An internet connection and Google reCAPTCHA v2 checkbox keys for sign-in

## Set up ClassFlow

1. Extract the project to `C:\xampp\htdocs\ClassFlow`. Check that `index.php` and `vendor\autoload.php` are in the extracted project.
2. Open the XAMPP Control Panel and start **Apache** and **MySQL**.
3. Open [phpMyAdmin](http://localhost/phpmyadmin/), create a database called `classflow_file`, then select it and import `classflow_schema.sql`. This gives you an empty database with no student accounts or records.
4. Open PowerShell and run the following commands to set up the email reminder and password reset tables.

   ```powershell
   Set-Location C:\xampp\htdocs\ClassFlow
   & C:\xampp\php\php.exe .\scripts\migrate_features.php
   ```

5. Create reCAPTCHA v2 checkbox keys for the hostname you use, such as `localhost`. In `login.php`, set the `data-sitekey` attribute to your site key. In `include/recaptcha.php`, set `$recaptchaSecretKey` to your secret key. [Google reCAPTCHA setup](https://developers.google.com/recaptcha/docs/display)
6. Open [ClassFlow](http://localhost/ClassFlow/), select **Register**, then create an account and sign in.

ClassFlow uses `localhost`, database `classflow_file`, and user `root` with a blank password by default. If your setup is different, set `CLASSFLOW_DB_HOST`, `CLASSFLOW_DB_NAME`, `CLASSFLOW_DB_USER` and `CLASSFLOW_DB_PASSWORD` for Apache and PowerShell as needed.

## Use the planner

- In **Timetable**, add a class or choose **Import CSV / PDF**. Review the imported rows and select the classes you want to save.
- When adding or editing a class, choose **Class date** for a one-time class. The weekday is filled in automatically. Leave the date empty for a weekly class. Dated classes appear once in the calendar and only in the matching week of the timetable; the class list shows all saved classes and their dates.
- Add assignments, exams and study sessions from the dashboard.
- Open **Conflict Tracker** to check for overlaps and **Reminders** to see what's coming up.
- Manual class, exam and study-session forms allow overlaps. When an overlap is detected, the activity is saved and the Conflict Tracker opens on the relevant date with a warning. Edit either saved activity there to resolve the clash. Invalid dates and time ranges still cannot be saved. Timetable imports retain their separate validation: conflicting import rows must be corrected before confirmation.

## Set up email (optional)

Email reminders and password reset codes use the same Gmail sender. You'll need PHP's `openssl` extension and a Gmail account with 2-Step Verification and an app password. [Google app password instructions](https://support.google.com/accounts/answer/185833)

1. From the ClassFlow folder in PowerShell, run `.\scripts\configure_gmail.ps1`. Enter your Gmail address and app password when prompted.
2. Fully close and reopen XAMPP, then start Apache and MySQL again.
3. Run `.\scripts\run_reminders.ps1 -TestGmail` and check the sender's inbox for the test message. To preview the reminder queue without sending mail, run `.\scripts\run_reminders.ps1 -DryRun`.
4. For automatic reminders, open **Email Reminders**, opt in, and set your time zone and how far in advance you want to be notified. Then run `.\scripts\register_reminder_task.ps1`.

The scheduled task checks for due reminders every five minutes while you're signed in to Windows. Leave the computer and MySQL running for reminders to go out.

## Run the tests

Start MySQL in XAMPP, then run this from the project folder in the VS Code PowerShell terminal:

```powershell
powershell -NoProfile -File .\tests\run_tests.ps1
```

The runner checks planning and reminders (35 checks), timetable import (45 checks) and password reset (9 checks). It saves the real output, exit codes, commands and source file hashes in a new dated folder under `tests/evidence`. It returns a failure if a suite fails or the expected check count is missing. PHP needs `pdo_sqlite`, `pdo_mysql` and `mbstring` for these suites.

See [tests/README.md](tests/README.md) for the fixtures, evidence and limits of the tests. Include the `tests` folder with the assessment artifact so the marker can inspect and repeat them. The supplied Brock timetable is a private assessment input; do not publish it with a public repository.

After the class-date update, run `& C:\xampp\php\php.exe .\tests\class_dates.php` for 14 additional focused checks. These are separate from the original 89-check dissertation run. Existing installations must run `scripts/migrate_features.php` to add the optional date column; saved weekly classes keep their existing behaviour.

Run `& C:\xampp\php\php.exe .\tests\conflict_drafts.php` for 20 additional checks of draft ownership, expiry, conflict previews, suggested times and form restoration. These are also separate from the original dissertation test count.

## Share the project

Include the source code, this README, `classflow_schema.sql`, the `migrations` folder and the bundled `vendor` folder. Keep your local `classflow.sql` backup, account data, Gmail credentials and reCAPTCHA secret private. Use a placeholder for the reCAPTCHA secret in the shared copy.

## Interface

The interface uses a crimson and white theme, with a teal study card. Dashboard summary cards link to their relevant pages. On smaller screens, use the menu button to open navigation; press Escape or tap outside the menu to close it. Refresh with Ctrl+F5 after replacing the design files.

## GitHub submission

Import `classflow_schema.sql` for a fresh database. Set `CLASSFLOW_RECAPTCHA_SECRET` on the server or define `$recaptchaSecretKey` in `include/recaptcha.local.php` using the key paired with your site key.

The full test runner needs the private Brock PDF supplied through its `-BrockPdf` parameter or placed locally in `tests/fixtures/brock.pdf`. The repository excludes that PDF and local test evidence. Share approved evidence separately through the submission portal if required.
