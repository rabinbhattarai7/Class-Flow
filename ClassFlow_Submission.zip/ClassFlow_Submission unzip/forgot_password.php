<?php
/* Password recovery has two separate steps. The student first requests a code by email, then submits that code with a new password. */
session_start();
header('Cache-Control: no-store');
header('Referrer-Policy: no-referrer');

require_once __DIR__ . '/include/features.php';
require_once __DIR__ . '/include/email.php';
require_once __DIR__ . '/include/password_reset.php';

$error = '';
$notice = '';
$showReset = isset($_GET['code']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Confirm this form submission came from the current ClassFlow session before requesting a code or saving a password.
    cf_check_csrf();
    $action = $_POST['action'] ?? '';
    if ($action === 'request') {
        $email = trim(is_string($_POST['email'] ?? null) ? $_POST['email'] : '');
        if (strlen($email) > 150 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Enter a valid email address.';
        } elseif (!cf_mail_configured()) {
            $error = 'Password recovery email is currently unavailable. Please contact the ClassFlow administrator.';
        } else {
            $showReset = true;
            // Use the same response for known and unknown accounts so the page does not reveal which addresses are registered.
            $notice = 'If the address is registered, a reset code may arrive shortly. Check your inbox and spam folder.';
            // Limit repeated requests from this browser. The recovery helper also checks the time of the last request for the account.
            if ((int) ($_SESSION['cf_last_reset_request'] ?? 0) <= time() - 30) {
                $_SESSION['cf_last_reset_request'] = time();
                require __DIR__ . '/include/database.php';
                try {
                    $reset = cf_issue_reset_code($pdo, $email);
                    if ($reset !== null) {
                        cf_send_email(
                            $reset['email'],
                            'ClassFlow password reset code',
                            "Your ClassFlow reset code is:\n\n{$reset['code']}\n\n"
                            . "Enter it on the Forgot password page within 30 minutes. "
                            . "If you did not request this code, you can ignore this email.\n"
                        );
                    }
                } catch (Throwable $failure) {
                    error_log('ClassFlow password reset request could not be completed.');
                }
            }
        }
    } elseif ($action === 'reset') {
        $showReset = true;
        $code = is_string($_POST['code'] ?? null) ? $_POST['code'] : '';
        $newPassword = is_string($_POST['password'] ?? null) ? $_POST['password'] : '';
        if (strlen($newPassword) < 8 || strlen($newPassword) > 72 || str_contains($newPassword, "\0")) {
            $error = 'Choose a password at least 8 characters long and no more than 72 bytes.';
        } elseif ($newPassword !== ($_POST['confirmation'] ?? null)) {
            $error = 'The passwords do not match.';
        } else {
            require __DIR__ . '/include/database.php';
            try {
                // Send the validated password to the recovery helper. The helper only changes it when the submitted code is valid and unused.
                $resetEmail = cf_redeem_reset_code($pdo, $code, $newPassword);
                if ($resetEmail !== null) {
                    // Clear the current session and ask the student to sign in with the replacement password. Only the email is carried over to the sign-in form.
                    $_SESSION = [];
                    session_regenerate_id(true);
                    $_SESSION['cf_password_reset_email'] = $resetEmail;
                    header('Location: login.php', true, 303);
                    exit;
                }
                $error = 'This code is invalid, expired or already used. Request a new code if needed.';
            } catch (Throwable $failure) {
                error_log('ClassFlow password reset could not be saved.');
                $error = 'Password recovery is temporarily unavailable. Try again later.';
            }
        }
    }
}

require __DIR__ . '/include/header.php';
?>
<main class="login-section">
    <div class="login-card">
        <h1 class="login-title"><?= $showReset ? 'Set a new password' : 'Forgot password?' ?></h1>
        <?php if ($error !== ''): ?>
            <p class="alert alert-danger" role="alert"><?= cf_escape($error) ?></p>
        <?php endif; ?>
        <?php if ($notice !== ''): ?>
            <p class="alert alert-info" role="status"><?= cf_escape($notice) ?></p>
        <?php endif; ?>
        <form method="post" action="forgot_password.php">
            <input type="hidden" name="csrf" value="<?= cf_escape(cf_csrf_token()) ?>">
            <?php if ($showReset): ?>
                <input type="hidden" name="action" value="reset">
                <div class="mb-3">
                    <label class="form-label" for="code">Reset code from your email</label>
                    <input class="form-control" id="code" name="code" maxlength="32" autocomplete="one-time-code" required>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="password">New password</label>
                    <input class="form-control" type="password" id="password" name="password" minlength="8" autocomplete="new-password" required>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="confirmation">Confirm new password</label>
                    <input class="form-control" type="password" id="confirmation" name="confirmation" minlength="8" autocomplete="new-password" required>
                </div>
                <button type="submit" class="btn btn-cf-primary w-100">Save new password</button>
                <a class="cf-link d-block mt-3" href="forgot_password.php">Request another code</a>
            <?php else: ?>
                <p class="login-subtitle">Enter the email address you use to sign in.</p>
                <input type="hidden" name="action" value="request">
                <div class="mb-3">
                    <label class="form-label" for="email">Email address</label>
                    <input class="form-control" type="email" id="email" name="email" maxlength="150" autocomplete="email" required>
                </div>
                <button type="submit" class="btn btn-cf-primary w-100">Email a reset code</button>
                <a class="cf-link d-block mt-3" href="forgot_password.php?code=1">I already have a code</a>
            <?php endif; ?>
        </form>
        <a class="cf-link d-block mt-3" href="login.php">Back to sign in</a>
    </div>
</main>
<?php require __DIR__ . '/include/footer.php'; ?>
