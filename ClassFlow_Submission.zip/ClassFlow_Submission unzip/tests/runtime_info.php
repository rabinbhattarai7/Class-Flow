<?php
// Read-only runtime metadata for the evidence runner. A file avoids shell quoting differences.
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
echo json_encode([
    'php' => PHP_VERSION,
    'os' => PHP_OS_FAMILY,
    'extensions' => get_loaded_extensions(),
], JSON_THROW_ON_ERROR);
