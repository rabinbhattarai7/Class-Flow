<?php
/* These checks cover timetable parsing, preview validation and saving selected rows. Optional checks use a separate database and representative document samples. */
if(PHP_SAPI!=='cli') { http_response_code(404); exit; }
require __DIR__.'/../include/timetable_import.php';
$checks=0;
function verify(bool $condition,string $message): void { global $checks; if(!$condition) throw new RuntimeException('FAILED: '.$message); $checks++; echo "PASS: $message\n"; }
function rejects(callable $fn,string $message): void { try { $fn(); } catch(RuntimeException $e) { verify(true,$message); return; } verify(false,$message); }
verify(cf_import_time('1:15 PM')==='13:15','12-hour time conversion');
verify(cf_import_time('12:00 AM')==='00:00','midnight conversion');
verify(cf_import_time('12:00 PM')==='12:00','noon conversion');
verify(cf_import_time('09.30')==='09:30','dot-separated European time');
verify(cf_import_time('0930')==='09:30','compact time');
verify(cf_import_time('9 a.m.')==='09:00','AM with punctuation');
verify(cf_import_time('25:00')==='' && cf_import_time('13:00 PM')==='','invalid times rejected');
verify(cf_import_days('Tue-Thu')===['Tuesday','Thursday'],'multi-day course expansion');
verify(cf_import_days('mandag')===['Monday'],'Danish weekday');
verify(cf_import_days('monkey')===[],'unknown weekday not guessed');
verify(cf_import_range('Mon/11:35-14:25')===['11:35','14:25'],'combined weekday/time range');
verify(cf_import_range('9:00–10:30 AM')===['09:00','10:30'],'shared meridiem range');
$csv=cf_import_csv_read("\xef\xbb\xbfCourse;Teacher;Weekday;Start;End;Venue\r\n\"Database; Design\";Alex;Mon;9:00 AM;10:30 AM;B204\r\n");
$mapping=['subject_name'=>'0','lecturer_name'=>'1','day'=>'2','start_time'=>'3','end_time'=>'4','room'=>'5'];
$rows=cf_import_csv_map($csv,$mapping);
verify(count($rows)===1 && $rows[0]['subject_name']==='Database; Design','BOM, semicolon delimiter and quoted text');
verify($rows[0]['day']==='Monday' && $rows[0]['start_time']==='09:00','CSV field mapping normalizes values');
verify($rows[0]['class_type']==='Lecture' && str_contains($rows[0]['warnings'],'defaults'),'missing class type is explicitly defaulted');
$tab=cf_import_csv_read("subject\tday\tstart\tend\nMath\tWed\t10:00\t11:00\n");
verify(count($tab['header'])===4,'tab-separated CSV');
rejects(fn()=>cf_import_csv_read("subject,day,start\nMath,Mon\n"),'ragged CSV rows rejected');
rejects(fn()=>cf_import_csv_map($csv,['subject_name'=>'0','day'=>'2','start_time'=>'3']),'missing required mapping rejected');
rejects(fn()=>cf_import_csv_map($csv,['subject_name'=>'0','day'=>'0','start_time'=>'3','end_time'=>'4']),'duplicate column mapping rejected');
$data=['subject_name'=>'Math','day'=>'Friday','start_time'=>'10:00','end_time'=>'11:00'];
$row=cf_import_row($data);
verify(!$errors=cf_import_validate($row),'optional lecturer and room are safely defaulted');
$bad=$row; $bad['end_time']='09:00';
verify(count(cf_import_validate($bad))>0,'end before start rejected');
$daily="Daily timetable for Test\nTuesday, 10/27/2026 12:00:00 AM\n11:45 AM\n12:30 PM 75626 IMAT3711 Privacy and Data Protection • S124 • Fati Tahiru\n12:30 PM\n1:15 PM 75626 IMAT3711 Privacy and Data Protection • S124 • Fati Tahiru";
$dailyRows=cf_pdf_daily_rows($daily,1);
verify(count($dailyRows)===2 && $dailyRows[0]['room']==='S124','Brock-style daily text separates classes and rooms');
verify($dailyRows[1]['end_time']==='13:15' && str_contains($dailyRows[0]['notes'],'10/27/2026'),'PDF dates retained and PM converted');
$grid=[['y'=>700,'cells'=>[['x'=>100,'text'=>'Monday'],['x'=>250,'text'=>'Tuesday'],['x'=>400,'text'=>'Wednesday']]],
 ['y'=>650,'cells'=>[['x'=>20,'text'=>'09:00-10:00'],['x'=>100,'text'=>'Programming'],['x'=>250,'text'=>'Mathematics']]],
 ['y'=>600,'cells'=>[['x'=>20,'text'=>'10:00-11:00'],['x'=>400,'text'=>'Databases']]]];
$gridRows=cf_pdf_grid_rows($grid,1);
verify(count($gridRows)===3 && $gridRows[1]['day']==='Tuesday','weekly grid columns map to weekdays');
verify($gridRows[2]['start_time']==='10:00' && $gridRows[2]['end_time']==='11:00','weekly grid uses explicit row times');

// Run database import checks in a separate MySQL schema when requested. The tests use synthetic records and remove the temporary schema afterwards.
if(in_array('--mysql',$argv,true)) {
    require __DIR__.'/../include/database.php'; $admin=$pdo;
    $name='classflow_import_test_'.bin2hex(random_bytes(6));
    $admin->exec("CREATE DATABASE `$name` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci");
    try {
        $pdo=new PDO('mysql:host='.(getenv('CLASSFLOW_DB_HOST')?:'localhost').';dbname='.$name.';charset=utf8mb4',getenv('CLASSFLOW_DB_USER')?:'root',getenv('CLASSFLOW_DB_PASSWORD')?:'', [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
        $baseline=file_get_contents(__DIR__.'/../classflow_schema.sql');
        foreach(['users','assignments','classes','exams','study_sessions'] as $table) {
            preg_match('/CREATE TABLE `'.preg_quote($table,'/').'` \(.*?\) ENGINE=.*?;/s',$baseline,$match);
            $pdo->exec(str_replace('`id` int(10) UNSIGNED NOT NULL,','`id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,',$match[0]));
        }
        $pdo->exec(file_get_contents(__DIR__.'/../migrations/001_planning_and_reminders.sql'));
        $pdo->exec("INSERT INTO users (first_name,last_name,email,password) VALUES ('Import','Test','import@example.invalid','unused'),('Other','User','other@example.invalid','unused')");
        verify(cf_import_commit($pdo,1,[$row])===1,'selected valid class committed');
        verify(cf_import_commit($pdo,1,[$row])===0,'repeat import skips existing class');
        verify(cf_import_commit($pdo,2,[$row])===1,'user imports are isolated');
        $conflict=$row; $conflict['subject_name']='Different course'; $conflict['start_time']='10:30'; $conflict['end_time']='11:30';
        rejects(fn()=>cf_import_commit($pdo,1,[$conflict]),'existing overlap blocks import');
        $free=$row; $free['day']='Monday'; $free['subject_name']='Free class';
        rejects(fn()=>cf_import_commit($pdo,1,[$free,$conflict]),'mixed valid/conflicting batch saves nothing');
        verify(count(cf_rows($pdo,'classes',1))===1,'failed batch did not partially insert classes');
        $overlap=$free; $overlap['subject_name']='Overlapping second row';
        rejects(fn()=>cf_import_commit($pdo,1,[$free,$overlap]),'overlaps inside selected batch rejected');
        $next=$row; $next['start_time']='11:00'; $next['end_time']='12:00';
        verify(cf_import_commit($pdo,1,[$next])===1,'adjacent imported classes allowed');
        verify(cf_import_statuses($pdo,1,[$bad])[0]['status']==='error','invalid preview row marked clearly');
        verify(cf_import_statuses($pdo,1,[$conflict])[0]['status']==='conflict','existing preview conflict marked clearly');
        verify(cf_import_statuses($pdo,1,[$row])[0]['status']==='duplicate','existing preview duplicate marked clearly');
    } finally {
        $pdo=null;
        if(preg_match('/^classflow_import_test_[a-f0-9]{12}$/',$name)) $admin->exec("DROP DATABASE `$name`");
    }
}
foreach($argv as $argument) {
    if(str_starts_with($argument,'--brock=')) {
        $result=cf_import_pdf(substr($argument,8),'1');
        verify(count($result['rows'])===6,'user Brock PDF extracts all six sessions');
        verify($result['rows'][0]['start_time']==='11:45' && $result['rows'][5]['end_time']==='17:00','user PDF first and final times match');
        verify($result['rows'][3]['lecturer_name']==='Samuel Agbesi' && $result['rows'][3]['room']==='S245','user PDF lecturer and room match');
    }
    if(str_starts_with($argument,'--samples=')) {
        $base=rtrim(substr($argument,10),'/\\');
        $result=cf_import_pdf($base.'/carleton.pdf','1');
        verify(count($result['rows'])===9,'public Carleton page expands to nine weekday classes');
        verify($result['rows'][3]['day']==='Tuesday' && $result['rows'][4]['day']==='Thursday','public multi-day entries expand correctly');
        verify($result['rows'][5]['class_type']==='Lab','public PDF lab type retained');
        $result=cf_import_pdf($base.'/southampton.pdf','1');
        verify(!$result['rows'] && count($result['warnings'])>0,'public illustrated timetable guide does not generate invented classes');
        $result=cf_import_pdf($base.'/cambridge.pdf','18');
        verify(!$result['rows'] && count($result['warnings'])>0,'public image-based weekly timetable is flagged instead of guessed');
        rejects(fn()=>cf_import_pdf($base.'/carleton.pdf','999'),'out-of-range PDF page rejected');
    }
}
echo "Completed $checks import checks.\n";
