# ClassFlow testing evidence

These are executable checks of the application code, not a manually written list of successful results. Submit this folder with the ClassFlow application. The evidence ZIP is a companion to the application, not a standalone app.

## Repeat the dissertation checks

1. Set up the application database using the main README and start MySQL in XAMPP.
2. Open the ClassFlow project in VS Code and open a PowerShell terminal.
3. Run:

```powershell
powershell -NoProfile -File .\tests\run_tests.ps1
```

The default PHP path is `C:\xampp\php\php.exe`. Override it with `-PhpPath` if needed. PHP needs `pdo_sqlite`, `pdo_mysql` and `mbstring`. The database account must be able to create and drop the isolated import-test database and create temporary tables. Tests read the same database environment settings as the application. Never put database passwords into submitted logs.

The runner uses all four PDFs in `tests/fixtures`. Use `-BrockPdf` and `-SamplesDirectory` to supply different locations for those same files. Missing fixtures cause an error; the runner does not silently claim a full run.

| Script | Expected passing assertions | What it checks |
| --- | ---: | --- |
| planning_features.php | 35 | Scheduling boundaries, selected account isolation, reminder handling and rendering three authenticated pages |
| timetable_import.php with all options | 45 | Parsing, PDF examples, preview status and isolated database import operations |
| password_reset.php | 9 | Issuance, stored hashes, request throttling, expiry, single use and password changes |
| Total | 89 | Selected local behaviours |

The import total already includes the 25 basic parser checks. Do not add a separate basic run to the 89. The optional `--mysql` planning mode is not part of this exact dissertation command set.

## What the marker can inspect

Each new run creates `tests/evidence/<UTC timestamp>/` containing:

- `SUMMARY.md`: a readable results table.
- `summary.json`: exact commands, timestamps, PHP version/extensions, expected and observed counts, and process exit codes.
- Three `*.stdout.txt` files: unedited standard output from the scripts.
- Three `*.stderr.txt` files: unedited diagnostic output, including empty files where no diagnostic was produced.
- `file_hashes.csv`: SHA-256 hashes of the first-party PHP/SQL/scripts, dependency manifests and PDF inputs at the start of the run. It is a version record, not independent certification. Vendor dependency versions are recorded by composer.lock.

`evidence/original_20261113` preserves the three logs used during the dissertation revision. Those original text logs do not contain the new runner's metadata. A later dated run is a repeat verification, not a replacement or backdated reconstruction of the original run. The two database test scripts were changed to use the clean `classflow_schema.sql` instead of the private data backup before repeat verification; their assertion counts were unchanged.

For screenshots, run the command yourself in VS Code and capture the command plus the resulting table or log output. Use genuine terminal captures, not recreated screenshots. A small selection can go in Appendix B; submit the complete logs here with the artifact.

Suggested dissertation cross-reference, once this folder is included in the actual submission:

> The test scripts and complete output logs are supplied in the artifact's tests folder. Appendix B gives the reproduction command and explains the scope of the automated checks.

## How the tests are isolated

Planning uses a temporary SQLite fixture and a simulated email transport. Import creates a randomly named temporary MySQL database and drops it afterwards. Password reset creates connection-local temporary tables that shadow the application's tables for that connection. These automated runs do not send real email or update real student account records.

The planning suite deliberately produces `Delivery not confirmed for user #1, assignment #6.` while testing an uncertain email outcome. This is expected for that controlled scenario. Other diagnostics or a wrong pass count cause the runner to report failure.

## Limits of the evidence

Passing assertions cover only the specified inputs and code paths. They do not demonstrate student usability, a complete browser workflow, real email receipt, Windows Task Scheduler execution, accessibility, load handling or a complete security audit. The SQLite fixture replaces MySQL locking functions; it is not a concurrent-worker test. The three page-render checks use synthetic authenticated sessions rather than signing in through a real browser.

The 89 checks should not be described as proving that the whole system is bug-free. The earlier 134-check figure and historical Gmail observations are not verified by this runner.

## Code review note

The inspected delete and completion handlers check the signed-in account and restrict changes using the record owner. However, `dashboard/delete_class.php`, `dashboard/delete_assignment.php`, `dashboard/complete_assignment.php` and the profile update actions do not call the CSRF token check used by some other forms. This is a remaining security consistency issue, outside these 89 checks. No claim of comprehensive security testing should be made from this evidence.
