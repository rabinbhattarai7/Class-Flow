<?php
/* The isolated test database provides the same tables used by planning code and translates the database expressions the tests need. */
/* SQL dialect adapter for isolated tests only. Locks are not simulated as concurrency tests. */
class CfTestDatabase extends PDO
{
    public function __construct(string $path)
    {
        parent::__construct('sqlite:'.$path, null, null, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
        $this->sqliteCreateFunction('GET_LOCK',static fn()=>1);
        $this->sqliteCreateFunction('RELEASE_LOCK',static fn()=>1);
        $this->sqliteCreateFunction('DATABASE',static fn()=>'sqlite_fixture');
        $this->sqliteCreateFunction('DAYNAME',static fn($day)=>(new DateTimeImmutable($day))->format('l'));
    }
    // Translate the few database-specific expressions used by the worker so the same code can run on the isolated test database.
    public function prepare(string $query, array $options=[]): PDOStatement|false
    {
        $query=str_replace(['INSERT IGNORE','UTC_TIMESTAMP()'],['INSERT OR IGNORE',"datetime('now')"],$query);
        return parent::prepare($query,$options);
    }
}
// Create the account, academic and reminder tables used by the fixtures without loading the project’s real data.
function cf_test_schema(PDO $pdo): void
{
    $pdo->exec("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT,first_name TEXT,last_name TEXT,email TEXT,password TEXT);
    CREATE TABLE assignments (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,title TEXT,module TEXT,due_date TEXT,due_time TEXT,status TEXT DEFAULT 'Pending',reminder TEXT DEFAULT '1_day');
    CREATE TABLE classes (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,subject_name TEXT,lecturer_name TEXT,class_date TEXT,day TEXT,start_time TEXT,end_time TEXT,room TEXT,class_type TEXT);
    CREATE TABLE exams (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,exam_name TEXT,module TEXT,exam_date TEXT,start_time TEXT,end_time TEXT,location TEXT,exam_type TEXT,reminder TEXT);
    CREATE TABLE study_sessions (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,topic TEXT,module TEXT,study_date TEXT,start_time TEXT,end_time TEXT,status TEXT);
    CREATE TABLE cf_preferences (user_id INTEGER PRIMARY KEY,email_enabled INTEGER DEFAULT 0,timezone TEXT DEFAULT 'Europe/Copenhagen',study_reminder TEXT DEFAULT '1_day',class_reminder TEXT DEFAULT 'none',assignment_reminder TEXT DEFAULT '1_day',exam_reminder TEXT DEFAULT '1_day');
    CREATE TABLE cf_reminder_deliveries (delivery_key TEXT PRIMARY KEY,user_id INTEGER,event_type TEXT,event_id INTEGER,event_title TEXT,event_at TEXT,status TEXT DEFAULT 'pending',attempts INTEGER DEFAULT 0,last_error TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,attempted_at TEXT,sent_at TEXT);");
}
