<?php
// Focused regression checks for optional one-time class dates. No live accounts or email.
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require __DIR__ . '/sqlite_fixture.php';
require __DIR__ . '/../include/features.php';
$pdo = new CfTestDatabase(':memory:');
cf_test_schema($pdo);
$checks = 0;
function dateCheck(bool $ok, string $name): void {
    global $checks;
    if (!$ok) throw new RuntimeException('FAILED: ' . $name);
    ++$checks;
    echo "PASS: $name\n";
}
$pdo->exec("INSERT INTO classes (id,user_id,subject_name,day,class_date,start_time,end_time)
    VALUES (1,1,'Dated class','Monday','2030-01-07','10:00','11:00')");
$rows = cf_rows($pdo, 'classes', 1);
dateCheck($rows[0]['class_date'] === '2030-01-07', 'class date persists in storage');
$events = cf_events($rows, [], [], new DateTimeImmutable('2030-01-01'), new DateTimeImmutable('2030-01-31'));
dateCheck(count($events) === 1 && $events[0]['date'] === '2030-01-07', 'dated class expands exactly once');
dateCheck(cf_events($rows, [], [], new DateTimeImmutable('2030-01-08'), new DateTimeImmutable('2030-01-31')) === [], 'dated class does not recur in later weeks');
dateCheck(cf_schedule_conflict($pdo,1,'dated_class','2030-01-07','10:30','11:30') !== null, 'same-date overlapping class detected');
dateCheck(cf_schedule_conflict($pdo,1,'dated_class','2030-01-14','10:30','11:30') === null, 'different date on same weekday allowed');
dateCheck(cf_schedule_conflict($pdo,1,'exam','2030-01-07','10:30','11:30') !== null, 'exam clashes with dated class on its date');
dateCheck(cf_schedule_conflict($pdo,1,'exam','2030-01-14','10:30','11:30') === null, 'exam on a later week does not clash');
dateCheck(cf_schedule_conflict($pdo,1,'dated_class','2030-01-07','10:00','11:00',1) === null, 'editing excludes the same dated class');
dateCheck(cf_schedule_conflict($pdo,2,'dated_class','2030-01-07','10:00','11:00') === null, 'dated classes remain isolated by account');
dateCheck(cf_schedule_conflict($pdo,1,'dated_class','2030-01-07','11:00','12:00') === null, 'adjacent dated classes allowed');
dateCheck(cf_schedule_conflict($pdo,1,'dated_class','2030-02-31','10:00','11:00') !== null, 'invalid calendar date rejected');
dateCheck(cf_schedule_conflict($pdo,1,'class','Monday','10:00','11:00') !== null, 'weekly class detects dated class conflict');
$pdo->exec("UPDATE classes SET class_date=NULL WHERE id=1");
$events = cf_events(cf_rows($pdo,'classes',1), [], [], new DateTimeImmutable('2030-01-01'), new DateTimeImmutable('2030-01-31'));
dateCheck(count($events) === 4, 'undated class still repeats weekly');
dateCheck(cf_schedule_conflict($pdo,1,'dated_class','2030-01-14','10:00','11:00') !== null, 'dated class detects recurring class conflict');
echo "Completed $checks class-date checks. No live records changed.\n";
