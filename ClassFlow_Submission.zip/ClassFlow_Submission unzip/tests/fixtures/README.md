# PDF inputs

These are the exact inputs used for the full import checks. Retain the filenames below.

| File | Source | Expected role |
| --- | --- | --- |
| brock.pdf | User-supplied ums.brock.dk_WebTimeTable_PrintCal.aspx.pdf | Six Tuesday sessions; selected times, lecturer and room checked |
| carleton.pdf | Carleton University, School of Industrial Design, Fall 2025 timetable | First page produces nine weekday occurrences |
| southampton.pdf | University of Southampton timetable guide | Unsupported illustrated layout is flagged |
| cambridge.pdf | CL Global Academy brochure hosted by Cambridge Enterprise | Unsupported graphical layout on page 18 is flagged |

Public source URLs used for the supplied copies:

- https://carleton.ca/id/wp-content/uploads/SID-web-timetable-Fall-2025.pdf
- https://cdn.southampton.ac.uk/assets/imported/transforms/content-block/UsefulDownloads_Download/15E9185A2EDC4DA9B5810330F4DD9786/Understanding%20your%20timetable%20202021.pdf
- https://www.enterprise.cam.ac.uk/wp-content/uploads/2026/01/CL-Global-Academy-S26-AI-Brochure.pdf

The Brock file is a private supplied teaching timetable. It is included for assessment reproduction, not for public publication. The public documents are third-party compatibility inputs, not original ClassFlow work. Their file hashes are recorded with each run.
