<?php
// Session drafts and suggestions use synthetic SQLite records, with no real accounts or mail.
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require __DIR__.'/sqlite_fixture.php';
require __DIR__.'/../include/features.php';
$pdo = new CfTestDatabase(':memory:'); cf_test_schema($pdo);
$_SESSION = ['user_id'=>1]; $_SERVER['REQUEST_METHOD']='GET';
$checks=0;
function draftCheck(bool $ok,string $name): void {
    global $checks;
    if (!$ok) throw new RuntimeException('FAILED: '.$name);
    ++$checks; echo "PASS: $name\n";
}
$pdo->exec("INSERT INTO classes (id,user_id,subject_name,day,class_date,start_time,end_time)
VALUES (1,1,'Research Methods','Monday','2030-01-07','10:00','11:30')");
$input=['subject_name'=>'Privacy Management','lecturer_name'=>'Lecturer','class_date'=>'2030-01-07','day'=>'Friday','start_time'=>'10:00','end_time'=>'14:00','room'=>'223','class_type'=>'Lecture','notes'=>'Keep my notes','csrf'=>'not stored'];
$message=cf_draft_warning(1,'class',0,$input,'Conflict');
$token=$_SESSION['cf_latest_conflict']; $draft=cf_draft_get(1,$token);
draftCheck(str_contains($message,'conflicts.php?draft='),'rejected form receives a tracker link');
draftCheck((int)$pdo->query('SELECT COUNT(*) FROM classes')->fetchColumn()===1,'draft creation writes no academic record');
draftCheck(!isset($draft['fields']['csrf']),'only permitted form fields retained');
draftCheck($draft['fields']['day']==='Monday','weekday derived from selected class date');
draftCheck(cf_draft_get(2,$token)===null,'another account cannot retrieve the draft');
$preview=cf_draft_preview($pdo,1,$draft);
draftCheck(count($preview['clashes'])===1 && $preview['clashes'][0]['title']==='Research Methods','preview identifies the saved overlapping activity');
draftCheck($preview['minutes']===240,'suggestions preserve the four-hour duration');
draftCheck($preview['slots'][0]==='11:30-15:30','first suggested slot starts after the saved class');
draftCheck(count($preview['slots'])===3,'suggestions are limited to three choices');
$_SESSION['cf_conflict_drafts'][$token]['slots']=$preview['slots'];
$_GET=['draft'=>$token,'slot'=>$preview['slots'][0]];
$restored=cf_draft_restore(1,'class',0);
draftCheck($restored['start_time']==='11:30' && $restored['end_time']==='15:30','chosen suggestion prefills the original form');
draftCheck($restored['notes']==='Keep my notes' && $restored['subject_name']==='Privacy Management','other entered details are preserved');
draftCheck(cf_draft_restore(1,'exam',0)===[] && cf_draft_restore(1,'class',1)===[],'draft is bound to the original form and record');
$_GET['slot']='00:00-01:00';
draftCheck(cf_draft_restore(1,'class',0)['start_time']==='10:00','unlisted slot parameter is ignored');
$_SERVER['REQUEST_METHOD']='POST';
draftCheck(cf_draft_restore(1,'class',0)===[],'draft restoration does not override a submitted form');
$_SERVER['REQUEST_METHOD']='GET';
$pdo->exec("INSERT INTO exams (id,user_id,exam_name,exam_date,start_time,end_time) VALUES (1,1,'New booking','2030-01-07','12:00','13:00')");
draftCheck(cf_schedule_conflict($pdo,1,'dated_class','2030-01-07','11:30','15:30')!==null,'save-time validation catches a booking added after suggestion');
cf_draft_warning(1,'class',1,$input,'Conflict');
$editDraft=cf_draft_get(1,$_SESSION['cf_latest_conflict']);
$editPreview=cf_draft_preview($pdo,1,$editDraft);
draftCheck(count(array_filter($editPreview['clashes'],fn($e)=>$e['type']==='class' && $e['id']==1))===0,'editing preview excludes its own saved record');
draftCheck(str_starts_with(cf_draft_form_url($_SESSION['cf_latest_conflict'],$editDraft),'edit_class.php?') && str_contains(cf_draft_form_url($_SESSION['cf_latest_conflict'],$editDraft),'id=1'),'edit return link retains the record identifier');
$_SESSION['cf_conflict_drafts'][$token]['expires']=time()-1;
draftCheck(cf_draft_get(1,$token)===null,'expired drafts are unavailable');
$weekly=$input; $weekly['class_date']=''; $weekly['day']='Monday';
cf_draft_warning(1,'class',0,$weekly,'Conflict');
$weeklyPreview=cf_draft_preview($pdo,1,cf_draft_get(1,$_SESSION['cf_latest_conflict']));
draftCheck(count($weeklyPreview['clashes'])>=2,'weekly preview includes dated conflicts beyond the normal thirty-day window');
cf_draft_clear(1,'class',0);
draftCheck(cf_draft_get(1,$_SESSION['cf_latest_conflict'])===null,'successful save clears matching unsaved drafts');
echo "Completed $checks conflict-draft checks. No live records changed.\n";
