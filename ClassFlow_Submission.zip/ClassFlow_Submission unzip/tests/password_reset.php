<?php
/* These checks use temporary account tables to verify recovery codes and password changes without touching live student records or sending email. */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
// Use a fixed synthetic password to verify that loading the database does not overwrite the submitted password.
$password = 'Synthetic-replacement';
require __DIR__ . '/../include/database.php';
if ($password !== 'Synthetic-replacement') {
    throw new RuntimeException('Loading the database overwrote the submitted password.');
}
require __DIR__ . '/../include/password_reset.php';

// Connection-local tables shadow the application tables for this test only.
$pdo->exec('CREATE TEMPORARY TABLE users (id INT UNSIGNED PRIMARY KEY, email VARCHAR(150) UNIQUE, password VARCHAR(255)) ENGINE=InnoDB');
$schema = file_get_contents(__DIR__ . '/../migrations/002_password_resets.sql');
$pdo->exec(str_replace('CREATE TABLE IF NOT EXISTS', 'CREATE TEMPORARY TABLE', $schema));
function checkReset(bool $pass, string $message): void {
    if (!$pass) throw new RuntimeException($message);
    echo "PASS: $message\n";
}
$email = 'synthetic-reset@example.test';
$insert = $pdo->prepare('INSERT INTO users VALUES (1, ?, ?)');
$insert->execute([$email, password_hash('Synthetic-original', PASSWORD_DEFAULT)]);
checkReset(cf_issue_reset_code($pdo, 'absent@example.test') === null, 'unknown account has no code');
// Issue a test code for the temporary account and verify storage, expiry and single use.
$issued = cf_issue_reset_code($pdo, $email);
checkReset($issued !== null, 'known account receives a code');
checkReset($pdo->query('SELECT code_hash FROM cf_password_resets')->fetchColumn() === hash('sha256', $issued['code']), 'only the code hash is stored');
checkReset(cf_issue_reset_code($pdo, $email) === null, 'repeat request is limited');
checkReset(cf_redeem_reset_code($pdo, $issued['code'], $password) === $email, 'valid code changes password and returns the correct sign-in email');
checkReset(password_verify($password, $pdo->query('SELECT password FROM users')->fetchColumn()), 'replacement hash works with normal login');
checkReset(!cf_redeem_reset_code($pdo, $issued['code'], 'Synthetic-other'), 'a used code is rejected');
$pdo->exec('UPDATE cf_password_resets SET requested_at = 0');
$issued = cf_issue_reset_code($pdo, $email);
$pdo->exec('UPDATE cf_password_resets SET expires_at = 0');
checkReset(!cf_redeem_reset_code($pdo, $issued['code'], 'Synthetic-other'), 'an expired code is rejected');
$pdo->exec('UPDATE cf_password_resets SET requested_at = 0');
$issued = cf_issue_reset_code($pdo, $email);
$pdo->exec("UPDATE users SET email = 'changed@example.test'");
checkReset(!cf_redeem_reset_code($pdo, $issued['code'], 'Synthetic-other'), 'a code is invalidated by a change to the account email');
