<?php
/* These checks use synthetic academic records and a simulated sender to verify scheduling, reminder delivery rules and page rendering. */
/* Isolated integration tests: a temporary SQLite database, dialect adapter and fake email transport only. */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require __DIR__ . '/sqlite_fixture.php';
require __DIR__ . '/../include/reminder_dispatch.php';
$path=tempnam(sys_get_temp_dir(),'cf_test_');
$name='classflow_test_'.bin2hex(random_bytes(6));
$mysql=in_array('--mysql',$argv,true);
$admin=null;
if ($mysql) {
    require __DIR__.'/../include/database.php';
    $admin=$pdo;
    $admin->exec("CREATE DATABASE `$name` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci");
}
$checks=0;
function check(bool $condition, string $message): void {
    global $checks;
    if (!$condition) throw new RuntimeException('FAILED: '.$message);
    $checks++; echo "PASS: $message\n";
}
// Start with the scheduling boundaries, including back-to-back activities and dates when daylight saving changes.
check(!cf_overlap('09:00','10:00','10:00','11:00'),'back-to-back events allowed');
check(cf_overlap('09:00','11:00','10:00','12:00'),'partial overlap detected');
check(cf_overlap('09:00','12:00','10:00','11:00'),'contained event detected');
$zone=new DateTimeZone('Europe/Copenhagen');
check(cf_reminder_time('2026-11-10','07:00','same_day',$zone)->format('H:i')==='00:00','early events get midnight same-day reminder');
check(cf_reminder_time('2026-11-10','12:00','same_day',$zone)->format('H:i')==='08:00','daytime events get 08:00 reminder');
check(cf_reminder_time('2026-11-10','12:00','none',$zone)===null,'disabled reminder has no send time');
check(cf_reminder_time('2026-10-25','12:00','1_day',$zone)->format('Y-m-d H:i P')==='2026-10-24 12:00 +02:00','calendar-day lead respects daylight saving');
$events=[['date'=>'2026-11-10','start'=>'08:00','end'=>'09:00']];
check(cf_free_slots($events,'2026-11-10',60)[0]==='09:00–10:00','suggestions avoid existing events');


try {
    if ($mysql) {
        $pdo=new PDO('mysql:host='.(getenv('CLASSFLOW_DB_HOST')?:'localhost').';dbname='.$name.';charset=utf8mb4',getenv('CLASSFLOW_DB_USER')?:'root',getenv('CLASSFLOW_DB_PASSWORD')?:'', [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
        $baseline=file_get_contents(__DIR__.'/../classflow_schema.sql');
        foreach(['users','assignments','classes','exams','study_sessions'] as $table) {
            if (!preg_match('/CREATE TABLE `'.preg_quote($table,'/').'` \(.*?\) ENGINE=.*?;/s',$baseline,$match)) throw new RuntimeException('Missing baseline schema');
            $sql=str_replace('`id` int(10) UNSIGNED NOT NULL,','`id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,',$match[0]);
            $pdo->exec($sql);
        }
        $migration=file_get_contents(__DIR__.'/../migrations/001_planning_and_reminders.sql');
        $pdo->exec($migration); $pdo->exec($migration);
    } else {
        $pdo=new CfTestDatabase($path);
        cf_test_schema($pdo);
    }
    check(cf_feature_ready($pdo),'feature schema is available');
    $pdo->exec("INSERT INTO users (first_name,last_name,email,password) VALUES ('Test','One','one@example.invalid','unused'),('Test','Two','two@example.invalid','unused')");
    $pdo->exec("INSERT INTO cf_preferences (user_id,email_enabled,timezone,study_reminder,class_reminder) VALUES (1,1,'Europe/Copenhagen','1_week','1_week'),(2,0,'Europe/Copenhagen','1_week','1_week')");
    $defaults = cf_preferences($pdo, 1);
    check($defaults['assignment_reminder'] === '1_day' && $defaults['exam_reminder'] === '1_day', 'assignment and exam reminders default to one day before');
    $pdo->exec("UPDATE cf_preferences SET assignment_reminder='3_days', exam_reminder='1_week' WHERE user_id=1");
    $tomorrow=(new DateTimeImmutable('tomorrow',$zone))->format('Y-m-d');
    $yesterday=(new DateTimeImmutable('yesterday',$zone))->format('Y-m-d');
    $weekday=(new DateTimeImmutable($tomorrow,$zone))->format('l');
    $a=$pdo->prepare('INSERT INTO assignments (user_id,title,module,due_date,due_time,status,reminder) VALUES (?,?,?,?,?,?,?)');
    $a->execute([1,'Due assignment','M1',$tomorrow,'12:00','Pending','none']);
    $assignmentId=(int)$pdo->lastInsertId();
    $nextWeek=(new DateTimeImmutable('+8 days',$zone))->format('Y-m-d');
    $a->execute([1,'Outside reminder window','M1',$nextWeek,'12:00','Pending','none']);
    $a->execute([1,'Completed','M1',$tomorrow,'12:00','Completed','3_days']);
    $a->execute([1,'Overdue','M1',$yesterday,'12:00','Pending','3_days']);
    $a->execute([2,'Other user','M1',$tomorrow,'12:00','Pending','3_days']);
    $exam=$pdo->prepare('INSERT INTO exams (user_id,exam_name,module,exam_date,start_time,end_time,location,exam_type,reminder) VALUES (1,?,?,?,?,?,?,?,?)');
    $exam->execute(['Exam','M1',$tomorrow,'10:00','11:00','R1','Written','none']);
    $study=$pdo->prepare('INSERT INTO study_sessions (user_id,topic,module,study_date,start_time,end_time,status) VALUES (1,?,?,?,?,?,?)');
    $study->execute(['Study','M1',$tomorrow,'11:00','12:00','Planned']);
    $study->execute(['Finished study','M1',$tomorrow,'15:00','16:00','Completed']);
    $class=$pdo->prepare('INSERT INTO classes (user_id,subject_name,lecturer_name,day,start_time,end_time,room,class_type) VALUES (1,?,?,?,?,?,?,?)');
    $class->execute(['Class','Teacher',$weekday,'09:00','10:00','R1','Lecture']);
    $classId=(int)$pdo->lastInsertId();
    // Capture messages in memory instead of calling Gmail, so tests can check recipients, titles and repeated runs safely.
    $sent=[];
    $spy=function($to,$subject,$body) use (&$sent) { $sent[]=[$to,$subject,$body]; };
    $pdo->exec("UPDATE cf_preferences SET assignment_reminder='none', exam_reminder='none' WHERE user_id=1");
    ob_start(); $disabled=cf_dispatch_reminders($pdo,$spy,true); $disabledOutput=ob_get_clean();
    check($disabled['count']===2 && !str_contains($disabledOutput,'Due: assignment') && !str_contains($disabledOutput,'Due: exam'),
        'turning off assignment and exam reminders leaves study and class reminders eligible');
    $pdo->exec("UPDATE cf_preferences SET assignment_reminder='3_days', exam_reminder='1_week' WHERE user_id=1");
    ob_start(); $preview=cf_dispatch_reminders($pdo,$spy,true); ob_end_clean();
    check($preview['count']===4 && !$sent,'dry run previews assignment, exam, study and class without sending');
    check((int)$pdo->query('SELECT COUNT(*) FROM cf_reminder_deliveries')->fetchColumn()===0,'dry run writes no delivery history');
    $result=cf_dispatch_reminders($pdo,$spy);
    check($result['count']===4 && count($sent)===4,'eligible events dispatch through fake transport');
    check(in_array('ClassFlow: Due assignment', array_column($sent,1), true)
        && in_array('ClassFlow: Exam', array_column($sent,1), true),
        'shared settings send assignment and exam reminders regardless of old item settings');
    check(count(array_filter($sent,fn($s)=>$s[0]!=='one@example.invalid'))===0,'opted-out second user receives nothing');
    check((int)$pdo->query("SELECT COUNT(*) FROM cf_reminder_deliveries WHERE status='sent'")->fetchColumn()===4,'successful sends recorded');
    check(cf_dispatch_reminders($pdo,$spy)['count']===0,'repeated worker does not duplicate sends');
    $pdo->exec("UPDATE assignments SET due_time='13:00' WHERE id=$assignmentId");
    check(cf_dispatch_reminders($pdo,$spy)['count']===1,'edited event time creates one new eligible reminder');
    $a->execute([1,'Transport failure','M1',$tomorrow,'12:00','Pending','3_days']);
    $fail=cf_dispatch_reminders($pdo,function(){ throw new RuntimeException('Simulated network failure'); });
    check($fail['errors']===1,'unconfirmed SMTP outcome is reported');
    check(cf_dispatch_reminders($pdo,$spy)['count']===0,'uncertain send is not silently retried');
    $pdo->exec("UPDATE cf_reminder_deliveries SET status='pending' WHERE status='uncertain'");
    check(cf_dispatch_reminders($pdo,$spy)['count']===1,'explicit retry sends an eligible failed occurrence');
    check(cf_schedule_conflict($pdo,1,'exam',$tomorrow,'09:30','10:30')!==null,'exam detects class clash');
    check(cf_schedule_conflict($pdo,1,'class',$weekday,'10:30','10:45')!==null,'weekly class detects dated exam clash');
    check(cf_schedule_conflict($pdo,1,'exam',$tomorrow,'11:30','12:30')!==null,'exam detects study-session clash');
    check(cf_schedule_conflict($pdo,1,'class',$weekday,'09:00','10:00',$classId)===null,'edit excludes the current class and permits adjacent exams');
    check(cf_schedule_conflict($pdo,2,'exam',$tomorrow,'09:00','10:00')===null,'conflict queries isolate users');
    check(cf_schedule_conflict($pdo,1,'exam',$tomorrow,'15:00','16:00')===null,'completed study does not reserve time');
    check(cf_schedule_conflict($pdo,1,'exam','2026-02-31','12:00','13:00')!==null,'invalid calendar dates rejected');
    check(cf_schedule_conflict($pdo,1,'study_session','2026-02-31','12:00','13:00',0,true)!==null,'historical study still validates its date');
    check(cf_schedule_conflict($pdo,1,'study_session',$tomorrow,'09:00','10:00',0,true)===null,'historical completed study does not block a schedule');
    $expanded=cf_events(cf_rows($pdo,'classes',1),cf_rows($pdo,'exams',1),cf_rows($pdo,'study_sessions',1),new DateTimeImmutable($tomorrow,$zone),new DateTimeImmutable($tomorrow,$zone));
    check(count($expanded)===3 && count(cf_conflicts($expanded))===0,'tracker expands class and ignores completed study');
    // Render each new authenticated page using a synthetic session and the test database.
    foreach (['email_reminders','conflicts','import_timetable'] as $page) {
        $testFile=tempnam(sys_get_temp_dir(),'cf_page_');
        $dashboard=realpath(__DIR__.'/../dashboard');
        $adapter=realpath(__DIR__.'/sqlite_fixture.php');
        $connection=$mysql
            ? '$pdo=new PDO('.var_export('mysql:host='.(getenv('CLASSFLOW_DB_HOST')?:'localhost').';dbname='.$name.';charset=utf8mb4',true).','.var_export(getenv('CLASSFLOW_DB_USER')?:'root',true).','.var_export(getenv('CLASSFLOW_DB_PASSWORD')?:'',true).',[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);'
            : 'require '.var_export($adapter,true).'; $pdo=new CfTestDatabase('.var_export($path,true).');';
        $code='<?php session_save_path(sys_get_temp_dir()); '.$connection.' chdir('.var_export($dashboard,true).'); session_id("cftest'.bin2hex(random_bytes(8)).'"); session_start(); $_SESSION["user_id"]=1; session_write_close(); $_SERVER["REQUEST_METHOD"]="GET"; $_SERVER["SCRIPT_NAME"]="'.$page.'.php"; $source=file_get_contents("'.$page.'.php"); $source=str_replace("require_once \'../include/database.php\';", "", $source); eval("?>".$source); session_destroy();';
        file_put_contents($testFile,$code);
        $pipes=[];
        $process=proc_open([PHP_BINARY,$testFile],[1=>['pipe','w'],2=>['pipe','w']],$pipes);
        $output=stream_get_contents($pipes[1]); $stderr=stream_get_contents($pipes[2]);
        fclose($pipes[1]); fclose($pipes[2]); $status=proc_close($process); unlink($testFile);
        if ($status!==0 || $stderr || str_contains($output,'Fatal error')) echo "Page diagnostic: $stderr\n" . substr($output,-1800) . "\n";
        check($status===0 && str_contains($output,'</html>') && !str_contains($output,'Fatal error') && !$stderr,"$page authenticated page renders without errors");
    }
    echo "Completed $checks checks. No real email sent.\n";
} finally {
    $a=$exam=$study=$class=null;
    $pdo=null;
    gc_collect_cycles();
    if (is_file($path)) unlink($path);
    if ($mysql && preg_match('/^classflow_test_[a-f0-9]{12}$/',$name)) $admin->exec("DROP DATABASE `$name`");
}
