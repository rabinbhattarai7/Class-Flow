param(
    [string]$PhpPath = 'C:\xampp\php\php.exe',
    [string]$BrockPdf = (Join-Path $PSScriptRoot 'fixtures\brock.pdf'),
    [string]$SamplesDirectory = (Join-Path $PSScriptRoot 'fixtures')
)

$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
foreach ($required in @($PhpPath, $BrockPdf, (Join-Path $projectRoot 'classflow_schema.sql'),
        (Join-Path $SamplesDirectory 'carleton.pdf'), (Join-Path $SamplesDirectory 'southampton.pdf'),
        (Join-Path $SamplesDirectory 'cambridge.pdf'))) {
    if (-not (Test-Path -LiteralPath $required -PathType Leaf)) { throw "Missing required file: $required" }
}
$PhpPath = (Resolve-Path -LiteralPath $PhpPath).Path
$BrockPdf = (Resolve-Path -LiteralPath $BrockPdf).Path
$SamplesDirectory = (Resolve-Path -LiteralPath $SamplesDirectory).Path.TrimEnd('\')
$runId = [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffZ')
$runDirectory = Join-Path $PSScriptRoot "evidence\$runId"
New-Item -ItemType Directory -Path $runDirectory | Out-Null
$started = [DateTime]::UtcNow.ToString('o')

# Record the first-party source and fixture hashes, without copying account data or secrets.
$sourceFiles = @()
foreach ($folder in @('', 'include', 'dashboard', 'scripts', 'tests', 'migrations')) {
    $directory = if ($folder) { Join-Path $projectRoot $folder } else { $projectRoot }
    $sourceFiles += Get-ChildItem -LiteralPath $directory -File | Where-Object {
        $_.Extension -in @('.php', '.ps1', '.sql', '.json', '.lock') -and
        $_.Name -ne 'classflow.sql' -and $_.Name -notlike '*.local.php'
    }
}
$sourceFiles += Get-Item -LiteralPath $BrockPdf
foreach ($name in @('carleton.pdf', 'southampton.pdf', 'cambridge.pdf')) {
    $sourceFiles += Get-Item -LiteralPath (Join-Path $SamplesDirectory $name)
}
$hashes = @($sourceFiles | Sort-Object FullName -Unique | ForEach-Object {
    $label = $_.FullName
    if ($label.StartsWith($projectRoot + '\', [StringComparison]::OrdinalIgnoreCase)) {
        $label = $label.Substring($projectRoot.Length + 1)
    }
    [pscustomobject]@{ File = $label; SHA256 = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash }
})
$hashes | Export-Csv -LiteralPath (Join-Path $runDirectory 'file_hashes.csv') -NoTypeInformation -Encoding UTF8

$suites = @(
    @{ Name = 'planning_features'; Expected = 35; Arguments = @('tests/planning_features.php') },
    @{ Name = 'timetable_import'; Expected = 45; Arguments = @('tests/timetable_import.php', '--mysql', "--brock=$BrockPdf", "--samples=$SamplesDirectory") },
    @{ Name = 'password_reset'; Expected = 9; Arguments = @('tests/password_reset.php') }
)
$results = @()
foreach ($suite in $suites) {
    $stdoutPath = Join-Path $runDirectory ($suite.Name + '.stdout.txt')
    $stderrPath = Join-Path $runDirectory ($suite.Name + '.stderr.txt')
    $arguments = ($suite.Arguments | ForEach-Object { '"' + $_.Replace('"', '\"') + '"' }) -join ' '
    $command = '& "' + $PhpPath + '" ' + $arguments
    Write-Host "Running $($suite.Name)..."
    $suiteStart = [DateTime]::UtcNow.ToString('o')
    $process = Start-Process -FilePath $PhpPath -ArgumentList $arguments -WorkingDirectory $projectRoot `
        -WindowStyle Hidden -Wait -PassThru -RedirectStandardOutput $stdoutPath -RedirectStandardError $stderrPath
    $stdout = [IO.File]::ReadAllText($stdoutPath)
    $stderr = [IO.File]::ReadAllText($stderrPath)
    $passes = [regex]::Matches($stdout, '(?m)^PASS: ').Count
    $expectedDiagnostic = $suite.Name -eq 'planning_features' -and
        $stderr.Trim() -eq 'Delivery not confirmed for user #1, assignment #6.'
    $passed = $process.ExitCode -eq 0 -and $passes -eq $suite.Expected -and
        ([string]::IsNullOrWhiteSpace($stderr) -or $expectedDiagnostic)
    $status = if ($passed) { 'PASS' } else { 'FAIL' }
    $results += [pscustomobject]@{
        Suite = $suite.Name; Status = $status; PassedAssertions = $passes
        ExpectedAssertions = $suite.Expected; ExitCode = $process.ExitCode
        StartedUtc = $suiteStart; FinishedUtc = [DateTime]::UtcNow.ToString('o')
        Command = $command; Stdout = [IO.Path]::GetFileName($stdoutPath)
        Stderr = [IO.Path]::GetFileName($stderrPath)
        ExpectedDeliveryDiagnostic = $expectedDiagnostic
    }
    Write-Host "$($suite.Name): $status ($passes/$($suite.Expected)); exit code $($process.ExitCode)"
}
$runtimePath = Join-Path $runDirectory 'runtime.json'
$runtimeErrors = Join-Path $runDirectory 'runtime.stderr.txt'
$runtimeProcess = Start-Process -FilePath $PhpPath -ArgumentList ('"' + (Join-Path $PSScriptRoot 'runtime_info.php') + '"') -WindowStyle Hidden -Wait -PassThru -RedirectStandardOutput $runtimePath -RedirectStandardError $runtimeErrors
if ($runtimeProcess.ExitCode -ne 0) { throw 'Could not collect PHP runtime information.' }
$runtime = [IO.File]::ReadAllText($runtimePath)
$failed = @($results | Where-Object Status -ne 'PASS').Count
$summary = [ordered]@{
    RunId = $runId; StartedUtc = $started; FinishedUtc = [DateTime]::UtcNow.ToString('o')
    WorkingDirectory = $projectRoot; PhpRuntime = ($runtime | ConvertFrom-Json)
    OverallStatus = $(if ($failed -eq 0) { 'PASS' } else { 'FAIL' })
    TotalPassedAssertions = ($results | Measure-Object PassedAssertions -Sum).Sum
    ExpectedAssertions = 89; Results = $results
    Scope = 'Selected local automated checks. Planning uses SQLite fixtures and simulated email; import uses a temporary MySQL schema; reset uses temporary tables. No live email, student usability, browser interaction or concurrency validation.'
}
$summary | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath (Join-Path $runDirectory 'summary.json') -Encoding UTF8
$lines = @('# ClassFlow test run', '', "Run: $runId", "Overall: $($summary.OverallStatus)", '',
    '| Suite | Passed assertions | Expected | Exit code | Status |', '| --- | ---: | ---: | ---: | --- |')
foreach ($result in $results) {
    $lines += "| $($result.Suite) | $($result.PassedAssertions) | $($result.ExpectedAssertions) | $($result.ExitCode) | $($result.Status) |"
}
$lines += @('', $summary.Scope, '', 'Raw output and error streams are preserved separately. The planning suite deliberately exercises an unconfirmed delivery. See summary.json for exact commands and timestamps, and file_hashes.csv for SHA-256 hashes of source files and inputs.')
$lines | Set-Content -LiteralPath (Join-Path $runDirectory 'SUMMARY.md') -Encoding UTF8
Write-Host "Evidence saved to: $runDirectory"
if ($failed) { exit 1 }
exit 0
