<!-- Logout handler: clears session values, expires the session cookie and redirects to login. -->
```php
<?php
/* Sign-out clears the current session and its browser cookie so a later request cannot use that session to open private pages. */
// Open the current session so we can clear it.
session_start();

// Remove all session values, such as the logged-in user's ID.
$_SESSION = [];

// Check whether PHP uses a cookie to identify the session.
if (ini_get('session.use_cookies')) {
    // Get the existing session cookie's settings.
    $params = session_get_cookie_params();

    // Delete the browser's session cookie by setting its expiry in the past.
    setcookie(
        session_name(),       // Name of the session cookie.
        '',                   // Clear its value.
        time() - 42000,        // Expiry time in the past.
        $params['path'],       // Match the original cookie's path.
        $params['domain'],     // Match the original cookie's domain.
        $params['secure'],     // Preserve the HTTPS-only setting.
        $params['httponly']    // Preserve the JavaScript-access restriction.
    );
}

// Delete the stored session data on the server.
session_destroy();

// Redirect the user to the login page.
header('Location: login.php');

// Stop running the script after the redirect.
exit;
