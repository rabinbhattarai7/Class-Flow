<?php
/* Recovery codes are issued for existing accounts, expire after thirty minutes and are consumed when the password change is saved. */

// Issue at most one recovery code per account within five minutes. Save the hash of the code, so the database does not contain a usable copy.
function cf_issue_reset_code(PDO $pdo, string $email): ?array
{
    $pdo->beginTransaction();
    try {
        // Lock the account row while checking and saving the request so simultaneous requests cannot issue two codes for the same account.
        $account = $pdo->prepare('SELECT id, email, password FROM users WHERE email = ? FOR UPDATE');
        $account->execute([$email]);
        $user = $account->fetch(PDO::FETCH_ASSOC);
        $now = time();
        if (!$user) {
            $pdo->commit();
            return null;
        }

        $lastRequest = $pdo->prepare('SELECT requested_at FROM cf_password_resets WHERE user_id = ?');
        $lastRequest->execute([$user['id']]);
        if ((int) $lastRequest->fetchColumn() > $now - 300) {
            $pdo->commit();
            return null;
        }

        // Generate the code from random bytes. An account fingerprint ties it to the current email and password state.
        $code = bin2hex(random_bytes(16));
        $save = $pdo->prepare(
            'INSERT INTO cf_password_resets (user_id, code_hash, account_state, requested_at, expires_at)
             VALUES (?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE code_hash = VALUES(code_hash), account_state = VALUES(account_state),
                 requested_at = VALUES(requested_at), expires_at = VALUES(expires_at), used_at = NULL'
        );
        $save->execute([
            $user['id'], hash('sha256', $code), hash('sha256', $user['email'] . ':' . $user['password']),
            $now, $now + 1800,
        ]);
        $pdo->commit();
        return ['email' => $user['email'], 'code' => $code];
    } catch (Throwable $error) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $error;
    }
}

// Verify the code, save the new password hash and mark the code used in one database update.
function cf_redeem_reset_code(PDO $pdo, string $code, string $password): ?string
{
    $code = strtolower(trim($code));
    if (!preg_match('/\A[0-9a-f]{32}\z/', $code)) {
        return null;
    }

    // Hash the submitted code using the same method as issuance so it can be matched without storing or looking up the original code.
    $codeHash = hash('sha256', $code);
    $lookup = $pdo->prepare(
        'SELECT r.user_id, u.email FROM cf_password_resets r JOIN users u ON u.id = r.user_id
         WHERE r.code_hash = ? AND r.used_at IS NULL AND r.expires_at > ?'
    );
    $lookup->execute([$codeHash, time()]);
    $account = $lookup->fetch(PDO::FETCH_ASSOC);
    if (!$account) {
        return null;
    }

    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    // Update the password and consume the code in one statement. The account
    // state check also invalidates codes after a signed-in password or email change.
    $update = $pdo->prepare(
        "UPDATE users u JOIN cf_password_resets r ON r.user_id = u.id
         SET u.password = ?, r.used_at = ?
         WHERE u.id = ? AND r.code_hash = ? AND r.used_at IS NULL AND r.expires_at > ?
           AND r.account_state = CONVERT(SHA2(CONCAT(u.email, ':', u.password), 256) USING ascii) COLLATE ascii_bin"
    );
    $now = time();
    $update->execute([$passwordHash, $now, $account['user_id'], $codeHash, $now]);
    return $update->rowCount() > 0 ? $account['email'] : null;
}
