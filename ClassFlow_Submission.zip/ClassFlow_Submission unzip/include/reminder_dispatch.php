<?php
/* The worker finds reminders that are due, records an attempt before sending and tracks the result to prevent repeated sends during later runs. */
require_once __DIR__ . '/features.php';

/** Dependency-injected transport permits realistic tests without sending email. */
function cf_dispatch_reminders(PDO $pdo, callable $send, bool $dryRun = false): array
{
// Use a lock for this database so two reminder workers cannot process its queue at the same time.
$lockName='cf_reminders_'.substr(hash('sha256',(string)$pdo->query('SELECT DATABASE()')->fetchColumn()),0,40);
$lock=$pdo->prepare('SELECT GET_LOCK(?, 0)'); $lock->execute([$lockName]);
if (!(int) $lock->fetchColumn()) { return ["count"=>0,"errors"=>0,"busy"=>true]; }
$count = 0; $errors = 0;
try {
    // Only students who opted in are considered. Each student receives email at the address on their ClassFlow account.
    $users = $pdo->query('SELECT u.id,u.email,p.* FROM users u JOIN cf_preferences p ON p.user_id=u.id WHERE p.email_enabled=1')->fetchAll();
    foreach ($users as $user) {
        $userId = (int) $user['user_id'];
        if (!filter_var($user['email'], FILTER_VALIDATE_EMAIL)) continue;
        try { $zone = new DateTimeZone($user['timezone']); } catch (Exception $e) { continue; }
        $now = new DateTimeImmutable('now', $zone);
        // Collect assignments that are not completed and expand timed activities into dates before calculating their reminder windows.
        $events = [];
        foreach (cf_rows($pdo, 'assignments', $userId) as $a) {
            if ($a['status'] !== 'Completed') $events[] = ['type'=>'assignment', 'id'=>$a['id'], 'title'=>$a['title'], 'date'=>$a['due_date'], 'time'=>$a['due_time'], 'lead'=>$user['assignment_reminder']];
        }
        $expanded = cf_events(cf_rows($pdo,'classes',$userId), cf_rows($pdo,'exams',$userId), cf_rows($pdo,'study_sessions',$userId), $now, $now->modify('+8 days'));
        foreach ($expanded as $e) {
            $lead = match ($e['type']) { 'exam' => $user['exam_reminder'], 'class' => $user['class_reminder'], default => $user['study_reminder'] };
            $events[] = ['type'=>$e['type'], 'id'=>$e['id'], 'title'=>$e['title'], 'date'=>$e['date'], 'time'=>$e['start'], 'lead'=>$lead];
        }
        foreach ($events as $event) {
            $when = new DateTimeImmutable($event['date'].' '.$event['time'], $zone);
            // A reminder is eligible from its configured send time until the activity starts or the assignment is due.
            $remind = cf_reminder_time($event['date'], $event['time'], $event['lead'], $zone);
            if (!$remind || $now < $remind || $now >= $when) continue;
            // Include occurrence, recipient, zone and lead so edited schedules use their new reminder.
            $key = hash('sha256', implode('|', [$userId,$event['type'],$event['id'],$when->format('c'),$event['lead'],$user['email']]));
            $lookup = $pdo->prepare('SELECT status FROM cf_reminder_deliveries WHERE delivery_key=?'); $lookup->execute([$key]); $status = $lookup->fetchColumn();
            if ($status && $status !== 'pending') continue;
            if ($count >= 100) break 2;
            // Preview mode reports eligible records and skips both the delivery history update and the actual email.
            if ($dryRun) { echo "Due: {$event['type']} #{$event['id']} for user #$userId at {$when->format('c')}\n"; $count++; continue; }
            $insert = $pdo->prepare("INSERT IGNORE INTO cf_reminder_deliveries (delivery_key,user_id,event_type,event_id,event_title,event_at) VALUES (?,?,?,?,?,?)");
            $insert->execute([$key,$userId,$event['type'],$event['id'],$event['title'],$when->format('Y-m-d H:i:s')]);
            // Claim the pending attempt before contacting Gmail. Only the run that claims it can send the message.
            $claim = $pdo->prepare("UPDATE cf_reminder_deliveries SET status='sending', attempts=attempts+1, attempted_at=UTC_TIMESTAMP() WHERE delivery_key=? AND status='pending'");
            $claim->execute([$key]);
            if (!$claim->rowCount()) continue;
            try {
                $body = "ClassFlow reminder\n\n{$event['title']}\nScheduled: {$when->format('l j F Y, H:i')} ({$user['timezone']})\n\nOpen ClassFlow to view or update this item. You can turn off email reminders in Email reminders.\n";
                $send($user['email'], 'ClassFlow: '.$event['title'], $body);
                // Record that Gmail accepted the message. Inbox receipt must be checked separately.
                $done = $pdo->prepare("UPDATE cf_reminder_deliveries SET status='sent', sent_at=UTC_TIMESTAMP(), last_error=NULL WHERE delivery_key=?"); $done->execute([$key]);
            } catch (Throwable $e) {
                // SMTP failures can occur after acceptance. Manual retry avoids silent duplicate sends.
                $failed = $pdo->prepare("UPDATE cf_reminder_deliveries SET status='uncertain', last_error=? WHERE delivery_key=?");
                $failed->execute(['Delivery could not be confirmed. Check the inbox and sender configuration before retrying.', $key]);
                $errors++;
                fwrite(STDERR, "Delivery not confirmed for user #$userId, {$event['type']} #{$event['id']}.\n");
            }
            $count++;
        }
    }
} finally { $release=$pdo->prepare('SELECT RELEASE_LOCK(?)'); $release->execute([$lockName]); }
return ['count'=>$count, 'errors'=>$errors, 'busy'=>false];
}
