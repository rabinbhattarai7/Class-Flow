<?php
/* Shared helpers provide form protection, account-specific data access, reminder preferences and schedule validation across dashboard pages. */
require_once __DIR__ . '/planning.php';
require_once __DIR__ . '/conflict_drafts.php';

// Escape text before placing it in a page so database values and form inputs display as text instead of markup.
function cf_escape($value): string { return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8'); }
// An overlap is a warning, while malformed dates/times still prevent manual saves.
function cf_is_schedule_overlap(?string $message): bool {
    return $message !== null && str_starts_with($message, 'Schedule conflict with ');
}
function cf_saved_conflict_redirect(PDO $pdo, int $userId, string $kind, int $id, array $fields, ?string $warning): void {
    if (!cf_is_schedule_overlap($warning)) return;
    $fields = array_replace(array_fill_keys(array_keys(cf_draft_fields($kind)), ''), $fields);
    if ($kind === 'class' && !empty($fields['class_date'])) $fields['day'] = (new DateTimeImmutable($fields['class_date']))->format('l');
    $preview = cf_draft_preview($pdo,$userId,['kind'=>$kind,'id'=>$id,'fields'=>$fields]);
    $dates = array_column($preview['clashes'],'date'); sort($dates);
    $from = $dates[0] ?? (new DateTimeImmutable('today',new DateTimeZone('Europe/Copenhagen')))->format('Y-m-d');
    $_SESSION['cf_saved_conflict'] = 'Your activity was saved. It overlaps another activity. Review the saved conflicts below and edit a time if needed.';
    unset($_SESSION['success_message']);
    header('Location: conflicts.php?from=' . rawurlencode($from));
    exit;
}
// Give each session a random form token that can be checked when a request changes data.
function cf_csrf_token(): string { return $_SESSION['cf_csrf'] ??= bin2hex(random_bytes(32)); }
// Reject a submitted form when its token does not match the current session.
function cf_check_csrf(): void
{
    if (!hash_equals(cf_csrf_token(), (string) ($_POST['csrf'] ?? ''))) {
        http_response_code(403); exit('Your session expired. Reload the page and try again.');
    }
}
// Read this student’s email and timing preferences. New accounts have email delivery off until the student opts in.
function cf_preferences(PDO $pdo, int $userId): array
{
    $stmt = $pdo->prepare('SELECT * FROM cf_preferences WHERE user_id = ?');
    $stmt->execute([$userId]);
    return $stmt->fetch() ?: ['email_enabled' => 0, 'timezone' => 'Europe/Copenhagen',
        'study_reminder' => '1_day', 'class_reminder' => 'none',
        'assignment_reminder' => '1_day', 'exam_reminder' => '1_day'];
}
// Allow only the known academic tables and filter the results by the student’s account number.
function cf_rows(PDO $pdo, string $table, int $userId): array
{
    if (!in_array($table, ['classes', 'exams', 'study_sessions', 'assignments'], true)) throw new InvalidArgumentException('Invalid table');
    $stmt = $pdo->prepare("SELECT * FROM $table WHERE user_id = ?");
    $stmt->execute([$userId]); return $stmt->fetchAll();
}
// Check that the shared assignment and exam reminder fields exist before using features that depend on the latest migration.
function cf_feature_ready(PDO $pdo): bool
{
    try { $pdo->query('SELECT assignment_reminder, exam_reminder FROM cf_preferences LIMIT 0'); return true; }
    catch (PDOException $e) { return false; }
}
// Start the shared dashboard layout and escape the title before displaying it.
function cf_page_start(string $title, bool $showTitle = true): void
{
    $safe = cf_escape($title);
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>' . $safe . ' | ClassFlow</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet"><link href="style.css?v=20261103b" rel="stylesheet"><link rel="stylesheet" href="../css/theme.css?v=20261113-red1"></head><body><div class="container-fluid"><div class="row">';
    require __DIR__ . '/../dashboard/sidebar.php';
    echo '<main class="col-md-9 col-lg-10 p-4 dashboard-content">';
    if ($showTitle) echo '<h2 class="page-title">' . $safe . '</h2>';
}
// Close the dashboard content and page elements opened by the matching start helper.
function cf_page_end(): void { echo '</main></div></div></body></html>'; }
// Tell the local administrator to run the database migration if the feature tables are not ready.
function cf_require_features(PDO $pdo): void
{
    if (!cf_feature_ready($pdo)) {
        echo '<div class="alert alert-info">The new planning tools need a one-time database update. Ask the site administrator to run the ClassFlow feature migration described in FEATURE_SETUP.md.</div>';
        cf_page_end(); exit;
    }
}

/** Check all three event types when adding or changing a scheduled item. */
// Check a proposed class, exam or study session against the student’s existing schedule before saving. When editing, exclude the record being edited.
function cf_schedule_conflict(PDO $pdo, int $userId, string $type, string $date, string $start, string $end, int $excludeId = 0, bool $historical = false): ?string
{
    if (!preg_match('/^([01][0-9]|2[0-3]):[0-5][0-9]$/', $start) || !preg_match('/^([01][0-9]|2[0-3]):[0-5][0-9]$/', $end)) return 'Enter valid start and end times.';
    // A class repeats on a weekday. Exams and study sessions are dated, so calculate the weekday for those records before checking weekly classes.
    if ($type==='class') {
        if (!in_array($date,['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'],true)) return 'Choose a valid weekday.';
        $weekday=$date;
    } else {
        $parsed=DateTimeImmutable::createFromFormat('!Y-m-d',$date);
        if (!$parsed || $parsed->format('Y-m-d')!==$date) return 'Enter a valid event date.';
        $weekday=$parsed->format('l');
    }
    // Completed historical study sessions still need valid dates and times, but they do not reserve time in the active schedule.
    if ($historical) return null;
    // A clash requires an existing activity to start before the proposed end and finish after the proposed start. Back-to-back activities are allowed.
    $classCondition = $type === 'class' ? '1=1' : '(class_date IS NULL OR class_date = ?)';
    $classParams = $type === 'class' ? [] : [$date];
    $stmt=$pdo->prepare("SELECT id,subject_name AS title,start_time,end_time FROM classes WHERE user_id=? AND day=? AND $classCondition AND start_time < ? AND end_time > ? AND id != ? LIMIT 1");
    $stmt->execute(array_merge([$userId,$weekday],$classParams,[$end,$start,in_array($type,['class','dated_class'],true)?$excludeId:0]));
    $match=$stmt->fetch();
    if (!$match) {
        foreach ([['exam','exams','exam_date','exam_name'],['study_session','study_sessions','study_date','topic']] as [$kind,$table,$dateCol,$titleCol]) {
            if ($type==='class') {
                $condition="DAYNAME($dateCol)=? AND $dateCol>=?";
                $zone = new DateTimeZone(cf_feature_ready($pdo) ? cf_preferences($pdo,$userId)['timezone'] : 'Europe/Copenhagen');
                $params=[$weekday,(new DateTimeImmutable('today',$zone))->format('Y-m-d')];
            } else { $condition="$dateCol=?"; $params=[$date]; }
            $notCompleted=$kind==='study_session'?" AND status != 'Completed'":'';
            $stmt=$pdo->prepare("SELECT id,$titleCol AS title,start_time,end_time FROM $table WHERE user_id=? AND $condition AND start_time < ? AND end_time > ? AND id != ? $notCompleted LIMIT 1");
            $stmt->execute(array_merge([$userId],$params,[$end,$start,$type===$kind?$excludeId:0]));
            $match=$stmt->fetch();
            if ($match) break;
        }
    }
    return $match ? 'Schedule conflict with "'.$match['title'].'" ('.substr($match['start_time'],0,5).'–'.substr($match['end_time'],0,5).'). Choose a different time or review the Conflict Tracker.' : null;
}
