<?php
// Unsaved form data stays in the user's session, never in the academic tables.
function cf_draft_fields(string $kind): array {
    return match ($kind) {
        'class' => ['subject_name'=>'subjectName','lecturer_name'=>'lecturerName','day'=>'day','class_date'=>'classDate','start_time'=>'startTime','end_time'=>'endTime','room'=>'room','class_type'=>'classType','notes'=>'notes'],
        'exam' => ['exam_name'=>'examName','module'=>'module','exam_date'=>'examDate','start_time'=>'startTime','end_time'=>'endTime','location'=>'location','exam_type'=>'examType','notes'=>'notes'],
        'study_session' => ['topic'=>'topic','module'=>'module','study_date'=>'studyDate','start_time'=>'startTime','end_time'=>'endTime','status'=>'status','notes'=>'notes'],
        default => [],
    };
}
function cf_draft_prune(): void {
    foreach ($_SESSION['cf_conflict_drafts'] ?? [] as $key => $draft) {
        if (($draft['expires'] ?? 0) < time() || ($draft['user_id'] ?? 0) !== (int)($_SESSION['user_id'] ?? 0)) unset($_SESSION['cf_conflict_drafts'][$key]);
    }
}
function cf_draft_get(int $userId, string $token): ?array {
    cf_draft_prune();
    $draft = $_SESSION['cf_conflict_drafts'][$token] ?? null;
    return $draft && $draft['user_id'] === $userId ? $draft : null;
}
function cf_draft_warning(int $userId, string $kind, int $id, array $input, string $warning): string {
    cf_draft_prune();
    $fields = [];
    foreach (cf_draft_fields($kind) as $name => $variable) $fields[$name] = is_string($input[$name] ?? null) ? $input[$name] : '';
    $dateValue = match ($kind) { 'class'=>$fields['class_date'], 'exam'=>$fields['exam_date'], default=>$fields['study_date'] };
    $dateObject = $dateValue !== '' ? DateTimeImmutable::createFromFormat('!Y-m-d', $dateValue) : null;
    if (($dateValue !== '' && (!$dateObject || $dateObject->format('Y-m-d') !== $dateValue)) ||
        !preg_match('/^([01][0-9]|2[0-3]):[0-5][0-9]$/', $fields['start_time']) ||
        !preg_match('/^([01][0-9]|2[0-3]):[0-5][0-9]$/', $fields['end_time'])) {
        return '<div class="alert alert-warning">Changes not saved. ' . cf_escape($warning) . '</div>';
    }
    if ($kind === 'class' && $fields['class_date'] !== '') $fields['day'] = (new DateTimeImmutable($fields['class_date']))->format('l');
    $token = bin2hex(random_bytes(16));
    $_SESSION['cf_conflict_drafts'][$token] = ['user_id'=>$userId,'kind'=>$kind,'id'=>$id,'fields'=>$fields,'expires'=>time()+3600];
    while (count($_SESSION['cf_conflict_drafts']) > 10) array_shift($_SESSION['cf_conflict_drafts']);
    $_SESSION['cf_latest_conflict'] = $token;
    return '<div class="alert alert-warning">Changes not saved. ' . cf_escape($warning) . ' <a class="alert-link" href="conflicts.php?draft=' . $token . '">Review clash and alternative times</a></div>';
}
function cf_draft_form_url(string $token, array $draft, ?string $slot = null): string {
    $query = ['draft'=>$token];
    if ($draft['id']) $query['id'] = $draft['id'];
    if ($slot !== null) $query['slot'] = $slot;
    return ($draft['id'] ? 'edit_' : 'add_') . $draft['kind'] . '.php?' . http_build_query($query);
}
function cf_draft_restore(int $userId, string $kind, int $id): array {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') return [];
    $draft = cf_draft_get($userId, (string)($_GET['draft'] ?? ''));
    if (!$draft || $draft['kind'] !== $kind || $draft['id'] !== $id) return [];
    $fields = $draft['fields'];
    $slot = (string)($_GET['slot'] ?? '');
    // Only a suggestion generated for this session draft can prefill the form.
    if (in_array($slot, $draft['slots'] ?? [], true)) [$fields['start_time'], $fields['end_time']] = explode('-', $slot);
    return $fields;
}
function cf_draft_clear(int $userId, string $kind, int $id): void {
    foreach ($_SESSION['cf_conflict_drafts'] ?? [] as $token => $draft) {
        if ($draft['user_id'] === $userId && $draft['kind'] === $kind && $draft['id'] === $id) unset($_SESSION['cf_conflict_drafts'][$token]);
    }
}
function cf_draft_preview(PDO $pdo, int $userId, array $draft): array {
    $f = $draft['fields']; $kind = $draft['kind'];
    $type = $kind === 'class' && $f['class_date'] !== '' ? 'dated_class' : $kind;
    $date = match ($kind) { 'class'=>$f['class_date'] ?: $f['day'], 'exam'=>$f['exam_date'], default=>$f['study_date'] };
    $title = match ($kind) { 'class'=>$f['subject_name'], 'exam'=>$f['exam_name'], default=>$f['topic'] };
    $classes = cf_rows($pdo,'classes',$userId); $exams = cf_rows($pdo,'exams',$userId); $study = cf_rows($pdo,'study_sessions',$userId);
    $dates = [];
    if ($type === 'class') {
        $zone = new DateTimeZone(cf_feature_ready($pdo) ? cf_preferences($pdo,$userId)['timezone'] : 'Europe/Copenhagen');
        $today = new DateTimeImmutable('today', $zone);
        $first = $today->format('l') === $date ? $today : $today->modify('next ' . $date);
        $dates[] = $first->format('Y-m-d');
        // Inspect stored dated activities too, even outside the normal 30-day view.
        foreach (array_merge($classes,$exams,$study) as $row) {
            $d = $row['class_date'] ?? $row['exam_date'] ?? $row['study_date'] ?? null;
            if ($d && (new DateTimeImmutable($d))->format('l') === $date) $dates[] = $d;
        }
    } else $dates[] = $date;
    $clashes = [];
    foreach (array_unique($dates) as $d) {
        $on = new DateTimeImmutable($d);
        foreach (cf_events($classes,$exams,$study,$on,$on) as $event) {
            if ($event['type'] === $kind && (int)$event['id'] === $draft['id']) continue;
            if (cf_overlap($f['start_time'],$f['end_time'],$event['start'],$event['end'])) $clashes[] = $event;
        }
    }
    $start = explode(':',$f['start_time']); $end = explode(':',$f['end_time']);
    $minutes = (int)$end[0]*60+(int)$end[1]-(int)$start[0]*60-(int)$start[1];
    $slots = [];
    if ($minutes > 0 && $minutes <= 720) {
        for ($m=480; $m+$minutes<=1200 && count($slots)<3; $m+=30) {
            $a=sprintf('%02d:%02d',intdiv($m,60),$m%60); $n=$m+$minutes;
            $b=sprintf('%02d:%02d',intdiv($n,60),$n%60);
            if (cf_schedule_conflict($pdo,$userId,$type,$date,$a,$b,$draft['id']) === null) $slots[]="$a-$b";
        }
    }
    return ['title'=>$title,'date'=>$date,'clashes'=>$clashes,'slots'=>$slots,'minutes'=>$minutes];
}
