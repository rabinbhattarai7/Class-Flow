<?php
/* Reminders and password recovery share this email sender. It uses the configured Google connection and lets the calling feature handle delivery failures. */
require_once __DIR__ . '/gmail_oauth.php';

// Return the address for the selected sender. A saved Google sign-in connection takes priority over the app password settings.
function cf_mail_sender_address(): string
{
    return cf_gmail_oauth_config()['email'] ?? (string) getenv('CLASSFLOW_GMAIL_ADDRESS');
}

// Check whether the required settings are present. This check does not contact Gmail.
function cf_mail_configured(): bool
{
    return cf_gmail_oauth_config() !== null
        || (bool) (getenv('CLASSFLOW_GMAIL_ADDRESS') && getenv('CLASSFLOW_GMAIL_APP_PASSWORD'));
}
// Build one message for the supplied recipient. The selected Gmail connection determines how it is submitted.
function cf_send_email(string $recipient, string $subject, string $body): void
{
    if (!cf_mail_configured()) throw new RuntimeException('Gmail sender is not configured.');
    foreach (['Exception', 'PHPMailer', 'SMTP'] as $file) require_once __DIR__ . "/../vendor/phpmailer/src/$file.php";
    $oauth = cf_gmail_oauth_config();
    $sender = $oauth['email'] ?? (string) getenv('CLASSFLOW_GMAIL_ADDRESS');
    if (!filter_var($sender, FILTER_VALIDATE_EMAIL) || !filter_var($recipient, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Invalid email address.');
    $mail = new PHPMailer\PHPMailer\PHPMailer(true);
    $mail->isSMTP(); // Use RFC-compliant line endings when generating the message for either transport.
    $mail->CharSet = 'UTF-8';
    $mail->setFrom($sender, 'ClassFlow Reminders');
    $mail->addAddress($recipient);
    $mail->Subject = $subject;
    $mail->Body = $body;
    // With Google sign-in, prepare the message and send it through the Gmail application interface. Otherwise use Gmail’s mail server.
    if ($oauth !== null) {
        $mail->preSend();
        cf_gmail_send_mime($oauth, $mail->getSentMIMEMessage());
        return;
    }
    // Gmail’s mail server requires authentication and starts an encrypted connection before the app password is used.
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = $sender;
    $mail->Password = str_replace(' ', '', (string) getenv('CLASSFLOW_GMAIL_APP_PASSWORD'));
    $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;
    $mail->Timeout = 20;
    $mail->send();
}
