<?php
/* The importer turns supported spreadsheet and document formats into editable class rows. The application validates the selected rows before saving them. */
require_once __DIR__ . '/features.php';
require_once __DIR__ . '/../vendor/autoload.php';

// Translate familiar column headings into ClassFlow fields so exports from different sources can use the same preview.
function cf_import_alias(string $label): ?string
{
    $key=strtolower(preg_replace('/[^a-z0-9]/i','',trim($label)));
    foreach ([
        'subject_name'=>['subject','subjectname','module','modulename','modulenames','course','coursename','coursetitle','title','description'],
        'lecturer_name'=>['lecturer','lecturername','teacher','teachers','instructor','staff','tutor'],
        'day'=>['day','weekday','dayofweek'], 'start_time'=>['start','starttime','from','begin','begintime'],
        'end_time'=>['end','endtime','to','finish','finishtime'], 'room'=>['room','rooms','location','venue'],
        'class_type'=>['type','classtype','activitytype','eventtype'], 'notes'=>['notes','note','comments'],
        'day_time'=>['daytime','dayandtime'], 'time_range'=>['time','times','timerange'],
    ] as $field=>$aliases) if (in_array($key,$aliases,true)) return $field;
    return null;
}

// Convert supported time formats to twenty-four-hour time. Return an empty value when the source cannot be read reliably.
function cf_import_time(string $value): string
{
    $value=trim(str_replace("\xc2\xa0",' ',$value));
    $value=preg_replace('/(?<=\d)\.(?=\d)/',':',$value);
    if (preg_match('/^(\d{1,2})(?::?(\d{2}))?\s*([ap])\.?m\.?$/i',$value,$m)) {
        $hour=(int)$m[1]; $minute=(int)($m[2]??0);
        if ($hour<1 || $hour>12 || $minute>59) return '';
        return sprintf('%02d:%02d',$hour%12+(strtolower($m[3])==='p'?12:0),$minute);
    }
    if (preg_match('/^(\d{1,2}):([0-5]\d)(?::00)?$/',$value,$m) && (int)$m[1]<24) return sprintf('%02d:%02d',(int)$m[1],(int)$m[2]);
    if (preg_match('/^(\d{2})([0-5]\d)$/',$value,$m) && (int)$m[1]<24) return $m[1].':'.$m[2];
    return '';
}

// Recognise supported weekday names and abbreviations. Return each weekday once so a class can expand into its weekly entries.
function cf_import_days(string $value): array
{
    $aliases=['mon'=>'Monday','tue'=>'Tuesday','wed'=>'Wednesday','thu'=>'Thursday','fri'=>'Friday','sat'=>'Saturday','sun'=>'Sunday',
        'mandag'=>'Monday','tirsdag'=>'Tuesday','onsdag'=>'Wednesday','torsdag'=>'Thursday','fredag'=>'Friday','lørdag'=>'Saturday','søndag'=>'Sunday'];
    $result=[];
    foreach (preg_split('/[,\/;&+\s–-]+/u',mb_strtolower(trim($value))) as $part) {
        $part=rtrim($part,'.');
        $full=['monday'=>'Monday','tuesday'=>'Tuesday','wednesday'=>'Wednesday','thursday'=>'Thursday','friday'=>'Friday','saturday'=>'Saturday','sunday'=>'Sunday'];
        $day=$aliases[$part]??$full[$part]??null;
        if ($day && !in_array($day,$result,true)) $result[]=$day;
    }
    return $result;
}

// Read a start and end time from the same text field and account for a shared morning or afternoon marker.
function cf_import_range(string $value): ?array
{
    $time='\d{1,2}(?::|\.)\d{2}(?:\s*[ap]\.?m\.?)?|\d{1,2}\s*[ap]\.?m\.?|\d{4}';
    if (!preg_match('/('.$time.')\s*(?:-|–|—|\bto\b)\s*('.$time.')/iu',$value,$m)) return null;
    $a=cf_import_time($m[1]); $b=cf_import_time($m[2]);
    // A shared AM/PM suffix is permitted only when it produces an ordered interval.
    if (!preg_match('/[ap]/i',$m[1]) && preg_match('/([ap]\.?m\.?)$/i',$m[2],$suffix)) {
        $inferred=cf_import_time($m[1].' '.$suffix[1]);
        if ($inferred && $b && $inferred<$b) $a=$inferred;
    }
    return $a && $b ? [$a,$b] : null;
}

// Give spreadsheet and PDF rows a common format. Mark missing optional details so the student can review them.
function cf_import_row(array $data, string $source=''): array
{
    $row=[];
    foreach (['subject_name','lecturer_name','day','start_time','end_time','room','class_type','notes'] as $key) $row[$key]=trim((string)($data[$key]??''));
    $row['start_time']=cf_import_time($row['start_time']);
    $row['end_time']=cf_import_time($row['end_time']);
    $days=cf_import_days($row['day']); $row['day']=$days[0]??'';
    $warnings=[];
    if (!$row['lecturer_name']) { $row['lecturer_name']='Not specified'; $warnings[]='Lecturer not supplied'; }
    if (!$row['room']) { $row['room']='Not specified'; $warnings[]='Room not supplied'; }
    $original=$row['class_type'];
    $type=match(strtolower($original)) {'lecture','lec','l'=>'Lecture','tutorial','tut','t','seminar'=>'Tutorial','lab','laboratory','practical','p','computer lab'=>'Lab',default=>'Lecture'};
    if (!$original || !in_array(strtolower($original),['lecture','lec','l','tutorial','tut','t','seminar','lab','laboratory','practical','p','computer lab'],true)) $warnings[]=$original ? "Source type: $original; mapped to Lecture" : 'Class type defaults to Lecture';
    $row['class_type']=$type;
    $row['source']=$source;
    $row['warnings']=implode('; ',$warnings);
    return $row;
}

// Read a structured text file, detect its column separator and verify that every row has the same number of columns as the header.
function cf_import_csv_read(string $content): array
{
    if (strlen($content)>2*1024*1024) throw new RuntimeException('CSV files must be smaller than 2 MB.');
    if (str_starts_with($content,"\xff\xfe") || str_starts_with($content,"\xfe\xff")) $content=mb_convert_encoding($content,'UTF-8','UTF-16');
    $content=preg_replace('/^\xEF\xBB\xBF/','',$content);
    if (!mb_check_encoding($content,'UTF-8')) throw new RuntimeException('Save the CSV as UTF-8 or UTF-16 and upload it again.');
    $line=strtok($content,"\r\n")?:''; $delimiter=','; $best=0;
    foreach ([',',';',"\t"] as $candidate) {
        $count=count(str_getcsv($line,$candidate,'"',''));
        if ($count>$best) { $best=$count; $delimiter=$candidate; }
    }
    $stream=fopen('php://temp','r+'); fwrite($stream,$content); rewind($stream);
    $header=fgetcsv($stream,0,$delimiter,'"','');
    if (!$header || count($header)<3 || count($header)>40) throw new RuntimeException('The CSV needs a header row and columns for the class, day and times.');
    $records=[];
    while (($row=fgetcsv($stream,0,$delimiter,'"',''))!==false) {
        if (count($row)===1 && trim((string)$row[0])==='') continue;
        if (count($records)>=100) throw new RuntimeException('Import up to 100 class rows at a time.');
        if (count($row)!==count($header)) throw new RuntimeException('CSV row '.(count($records)+2).' has a different number of columns from its header.');
        $records[]=$row;
    }
    fclose($stream);
    if (!$records) throw new RuntimeException('The CSV contains no class rows.');
    return ['header'=>$header,'records'=>$records];
}

// Map the source columns to the required class fields and create one preview row per recognised weekday.
function cf_import_csv_map(array $csv, array $mapping): array
{
    foreach (['subject_name','day','start_time','end_time'] as $required) if (!isset($mapping[$required]) || $mapping[$required]==='') throw new RuntimeException('Map the subject, day, start time and end time columns.');
    $used=array_filter($mapping,fn($v)=>$v!=='');
    if (count(array_unique($used))!==count($used)) throw new RuntimeException('Use a different source column for each field.');
    $rows=[];
    foreach ($csv['records'] as $i=>$record) {
        $data=[];
        foreach ($mapping as $field=>$index) {
            if ($index==='') continue;
            if (!ctype_digit((string)$index) || !array_key_exists((int)$index,$record)) throw new RuntimeException('Choose valid CSV columns.');
            $data[$field]=$record[(int)$index];
        }
        $days=cf_import_days($data['day']??'');
        foreach ($days?:[''] as $day) { $data['day']=$day; $rows[]=cf_import_row($data,'CSV row '.($i+2)); }
    }
    if(count($rows)>100) throw new RuntimeException('Expanded weekday entries exceed 100 classes. Import a smaller file.');
    return $rows;
}

/** Reconstruct visible lines from text coordinates instead of raw PDF object order. */
// Use text coordinates to group entries on the same line and sort them from left to right.
function cf_pdf_lines($page): array
{
    $items=[];
    foreach ($page->getDataTm() as $entry) {
        if (!isset($entry[0][4],$entry[0][5],$entry[1]) || !trim((string)$entry[1])) continue;
        $items[]=['x'=>(float)$entry[0][4],'y'=>(float)$entry[0][5],'text'=>trim((string)$entry[1])];
    }
    usort($items,fn($a,$b)=>abs($a['y']-$b['y'])>2 ? ($b['y']<=>$a['y']) : ($a['x']<=>$b['x']));
    $lines=[];
    foreach ($items as $item) {
        $i=count($lines)-1;
        if ($i<0 || abs($lines[$i]['y']-$item['y'])>2) $lines[]=['y'=>$item['y'],'cells'=>[$item]];
        else $lines[$i]['cells'][]=$item;
    }
    foreach ($lines as &$line) { usort($line['cells'],fn($a,$b)=>$a['x']<=>$b['x']); $line['text']=implode("\t",array_column($line['cells'],'text')); } unset($line);
    return $lines;
}

// Use a recognisable header row to locate each column, then map nearby text to the corresponding timetable field.
function cf_pdf_table_rows(array $lines, int $pageNumber): array
{
    $columns=[]; $rows=[];
    foreach ($lines as $line) {
        $header=[];
        foreach($line['cells'] as $cell) $header[]=['x'=>$cell['x'],'field'=>cf_import_alias($cell['text'])??'__ignore'];
        $fields=array_column($header,'field');
        if (in_array('subject_name',$fields,true) && (in_array('day',$fields,true)||in_array('day_time',$fields,true)) && count($fields)>=4) { $columns=$header; continue; }
        if (!$columns) continue;
        $data=[];
        foreach ($line['cells'] as $cell) {
            $closest=null; $distance=PHP_FLOAT_MAX;
            foreach ($columns as $column) if (abs($cell['x']-$column['x'])<$distance) { $closest=$column['field']; $distance=abs($cell['x']-$column['x']); }
            if ($closest==='__ignore') continue;
            $data[$closest]=trim(($data[$closest]??'').' '.$cell['text']);
        }
        if (isset($data['day_time'])) {
            $range=cf_import_range($data['day_time']);
            if ($range) { [$data['start_time'],$data['end_time']]=$range; $data['day']=preg_split('/[\/\d]/',$data['day_time'],2)[0]; }
        } elseif (isset($data['time_range']) && $range=cf_import_range($data['time_range'])) [$data['start_time'],$data['end_time']]=$range;
        $days=cf_import_days($data['day']??'');
        if (!$days || empty($data['subject_name']) || !cf_import_time($data['start_time']??'') || !cf_import_time($data['end_time']??'')) continue;
        foreach ($days as $day) { $data['day']=$day; $rows[]=cf_import_row($data,'PDF page '.$pageNumber); }
    }
    return $rows;
}

// Read daily timetable exports by pairing printed start and end times with the weekday and class description.
function cf_pdf_daily_rows(string $text, int $pageNumber): array
{
    $rows=[]; $day=''; $date=''; $pending='';
    $time='\d{1,2}:\d{2}\s*[AP]M';
    foreach (preg_split('/\R/u',$text) as $line) {
        $line=trim(str_replace("\xc2\xa0",' ',$line));
        if (preg_match('/^(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday),\s*(\d{1,2}\/\d{1,2}\/\d{4})/i',$line,$m)) { $day=ucfirst(strtolower($m[1])); $date=$m[2]; $pending=''; continue; }
        if (!$day) continue;
        if (preg_match('/^('.$time.')$/i',$line,$m)) { $pending=cf_import_time($m[1]); continue; }
        if ($pending && preg_match('/^('.$time.')\s+(\d+\s+)?(.+)$/i',$line,$m)) {
            $parts=preg_split('/\s*[•·]\s*/u',$m[3]);
            $data=['subject_name'=>$parts[0], 'room'=>$parts[1]??'', 'lecturer_name'=>$parts[2]??'', 'day'=>$day,'start_time'=>$pending,'end_time'=>$m[1],
                'notes'=>'Source date: '.$date.'. Imported as a repeating weekly class.'];
            $rows[]=cf_import_row($data,'PDF page '.$pageNumber.' · '.$date); $pending='';
        }
    }
    return $rows;
}

/** Read explicit day/time rows; never infer a class duration from the next printed event. */
// Read timetable lines that state a weekday and time range directly, while ignoring unrelated headings.
function cf_pdf_explicit_rows(array $lines, int $pageNumber): array
{
    $rows=[]; $currentDay='';
    foreach($lines as $line) {
        $text=preg_replace('/\s+/u',' ',$line['text']);
        if(preg_match('/^(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)\s*$/i',$text,$m)) { $currentDay=$m[1]; continue; }
        if(!($range=cf_import_range($text))) continue;
        $day=$currentDay;
        if(preg_match('/\b(Mon(?:day)?|Tue(?:sday)?|Wed(?:nesday)?|Thu(?:rsday)?|Fri(?:day)?|Sat(?:urday)?|Sun(?:day)?)\b/i',$text,$m)) $day=$m[1];
        if(!$day) continue;
        $title=preg_replace('/\b(?:Mon(?:day)?|Tue(?:sday)?|Wed(?:nesday)?|Thu(?:rsday)?|Fri(?:day)?|Sat(?:urday)?|Sun(?:day)?)\b[:,\s]*/i','',$text);
        $title=preg_replace('/\d{1,2}[:.]\d{2}(?:\s*[AP]M)?\s*[-–—]\s*\d{1,2}[:.]\d{2}(?:\s*[AP]M)?/iu','',$title);
        $title=trim($title," \t|-:");
        if(mb_strlen($title)<3 || mb_strlen($title)>100 || preg_match('/timetable|semester|week\s+\d|http|copyright/i',$title)) continue;
        $parts=preg_split('/\s*[|•]\s*/u',$title);
        $rows[]=cf_import_row(['subject_name'=>$parts[0],'room'=>$parts[1]??'','lecturer_name'=>$parts[2]??'','day'=>$day,'start_time'=>$range[0],'end_time'=>$range[1]],'PDF page '.$pageNumber);
    }
    return $rows;
}

/** Simple weekly grids with an explicit start/end range printed for every row. */
// Read a weekly grid only when weekday columns and written time ranges provide enough information to place classes.
function cf_pdf_grid_rows(array $lines, int $pageNumber): array
{
    $columns=[]; $headerY=0; $anchors=[]; $rows=[];
    foreach($lines as $line) {
        $days=[];
        foreach($line['cells'] as $cell) {
            $found=cf_import_days($cell['text']);
            if(count($found)===1 && preg_match('/^(mon(?:day)?|tue(?:sday)?|wed(?:nesday)?|thu(?:rsday)?|fri(?:day)?|sat(?:urday)?|sun(?:day)?)$/i',trim($cell['text']))) $days[]=['x'=>$cell['x'],'day'=>$found[0]];
        }
        if(count($days)>=3) { $columns=$days; $headerY=$line['y']; break; }
    }
    if(!$columns) return [];
    foreach($lines as $line) {
        if($line['y']>=$headerY) continue;
        foreach($line['cells'] as $cell) if($cell['x']<$columns[0]['x']-15 && $range=cf_import_range($cell['text'])) { $anchors[]=['y'=>$line['y'],'range'=>$range]; break; }
    }
    foreach($anchors as $i=>$anchor) {
        $bottom=$anchors[$i+1]['y']??($anchor['y']-60);
        $content=array_fill(0,count($columns),[]);
        foreach($lines as $line) {
            if($line['y']>$anchor['y']+3 || $line['y']<=$bottom+3) continue;
            foreach($line['cells'] as $cell) {
                if($cell['x']<$columns[0]['x']-15) continue;
                $nearest=0; $distance=PHP_FLOAT_MAX;
                foreach($columns as $j=>$column) if(abs($column['x']-$cell['x'])<$distance) { $nearest=$j; $distance=abs($column['x']-$cell['x']); }
                $content[$nearest][]=$cell['text'];
            }
        }
        foreach($content as $j=>$texts) {
            $title=trim(implode(' ',$texts));
            if(!$title || mb_strlen($title)>100 || preg_match('/^(break|lunch|free|closed|no class)/i',$title)) continue;
            $rows[]=cf_import_row(['subject_name'=>$title,'day'=>$columns[$j]['day'],'start_time'=>$anchor['range'][0],'end_time'=>$anchor['range'][1],
                'notes'=>'Extracted from a weekly grid. Review the printed row times against the source.'],'PDF page '.$pageNumber.' · weekly grid');
        }
    }
    return $rows;
}

// Process the chosen pages using supported text layouts. Warn when a page has no selectable text or no reliable class rows.
function cf_import_pdf(string $path, string $pageSelection=''): array
{
    require_once __DIR__.'/../vendor/autoload.php';
    $config=new Smalot\PdfParser\Config();
    $config->setRetainImageContent(false);
    $parser=new Smalot\PdfParser\Parser([], $config);
    $document=$parser->parseFile($path);
    $pages=$document->getPages();
    if(count($pages)>60) throw new RuntimeException('Import a PDF with at most 60 pages, or export just the timetable pages.');
    $selected=[];
    if(trim($pageSelection)!=='') {
        foreach(explode(',',$pageSelection) as $part) {
            if(!preg_match('/^\s*(\d+)(?:\s*-\s*(\d+))?\s*$/',$part,$m)) throw new RuntimeException('Enter PDF pages such as 1,3-4.');
            $start=(int)$m[1]; $end=isset($m[2])?(int)$m[2]:$start;
            if($start<1 || $end<$start || $end>count($pages)) throw new RuntimeException('Choose page numbers within this PDF.');
            $selected=array_merge($selected,range($start,$end));
        }
        $selected=array_unique($selected);
    } else $selected=range(1,count($pages));
    $rows=[]; $warnings=[];
    foreach($selected as $number) {
        $page=$pages[$number-1]; $text=$page->getText();
        if(!trim($text)) { $warnings[]="Page $number contains no selectable text; scanned pages need OCR before import."; continue; }
        $found=cf_pdf_daily_rows($text,$number);
        if(!$found) { $lines=cf_pdf_lines($page); $found=cf_pdf_table_rows($lines,$number); }
        if(!$found) $found=cf_pdf_grid_rows($lines,$number);
        if(!$found) $found=cf_pdf_explicit_rows($lines,$number);
        if(!$found) $warnings[]="Page $number: no reliable class rows found. Image timetables and grids without explicit class times cannot be imported automatically.";
        foreach($found as $row) $rows[]=$row;
        if(count($rows)>100) throw new RuntimeException('More than 100 classes were found. Select fewer PDF pages.');
    }
    return ['rows'=>$rows,'warnings'=>$warnings,'pages'=>count($pages)];
}

// Check required fields, accepted weekdays and types, and whether the end time is later than the start time.
function cf_import_validate(array $row): array
{
    $errors=[];
    foreach(['subject_name'=>100,'lecturer_name'=>100,'room'=>50,'notes'=>1000] as $key=>$length) {
        if($key!=='notes' && trim($row[$key]??'')==='') $errors[]="Missing ".str_replace('_',' ',$key);
        if(mb_strlen($row[$key]??'')>$length) $errors[]=str_replace('_',' ',$key)." is too long (maximum $length characters)";
    }
    if(!in_array($row['day'],['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'],true)) $errors[]='Choose a valid weekday';
    if(!cf_import_time($row['start_time']) || !cf_import_time($row['end_time']) || $row['start_time']>=$row['end_time']) $errors[]='Enter valid times with end after start';
    if(!in_array($row['class_type'],['Lecture','Tutorial','Lab'],true)) $errors[]='Choose a valid class type';
    return $errors;
}

// Label each preview row so the student can see whether it is ready, invalid, an exact duplicate, or a scheduling conflict.
function cf_import_statuses(PDO $pdo, int $userId, array $rows): array
{
    $existing=cf_rows($pdo,'classes',$userId); $result=[];
    foreach($rows as $i=>$row) {
        $errors=cf_import_validate($row); $status=$errors?'error':'ready'; $message=implode('; ',$errors);
        if(!$errors) {
            foreach($existing as $old) if(empty($old['class_date']) && $old['day']===$row['day'] && substr($old['start_time'],0,5)===$row['start_time'] && substr($old['end_time'],0,5)===$row['end_time'] && mb_strtolower(trim($old['subject_name']))===mb_strtolower(trim($row['subject_name']))) { $status='duplicate'; $message='Already in your timetable'; break; }
            if($status==='ready' && $conflict=cf_schedule_conflict($pdo,$userId,'class',$row['day'],$row['start_time'],$row['end_time'])) { $status='conflict'; $message=$conflict; }
            if($status==='ready') foreach(array_slice($rows,0,$i) as $j=>$other) {
                if($other['day']===$row['day'] && cf_overlap($row['start_time'],$row['end_time'],$other['start_time'],$other['end_time'])) {
                    $same=$other['start_time']===$row['start_time'] && $other['end_time']===$row['end_time'] && mb_strtolower($other['subject_name'])===mb_strtolower($row['subject_name']);
                    $status=$same?'duplicate':'conflict'; $message=($same?'Repeated entry':'Overlaps').' with preview row '.($j+1); break;
                }
            }
        }
        $result[]=['status'=>$status,'message'=>$message];
    }
    return $result;
}

// Lock the student’s account while validating and saving the selected rows. Roll back the import if any selected row has an error or clash.
function cf_import_commit(PDO $pdo, int $userId, array $rows): int
{
    if(!$rows || count($rows)>100) throw new RuntimeException('Select between 1 and 100 classes.');
    $pdo->beginTransaction();
    try {
        // Hold the account row until this import ends so two imports for the same student cannot both save from the same preview state.
        $lock=$pdo->prepare('SELECT id FROM users WHERE id=? FOR UPDATE'); $lock->execute([$userId]);
        if(!$lock->fetchColumn()) throw new RuntimeException('Your account could not be found.');
        $statuses=cf_import_statuses($pdo,$userId,$rows); $count=0;
        foreach($statuses as $status) if(!in_array($status['status'],['ready','duplicate'],true)) throw new RuntimeException('Nothing was saved. Resolve selected errors or conflicts, or deselect those rows, then try again.');
        $insert=$pdo->prepare('INSERT INTO classes (user_id,subject_name,lecturer_name,day,start_time,end_time,room,class_type,notes) VALUES (?,?,?,?,?,?,?,?,?)');
        foreach($rows as $i=>$row) {
            if($statuses[$i]['status']==='duplicate') continue;
            $insert->execute([$userId,$row['subject_name'],$row['lecturer_name'],$row['day'],$row['start_time'],$row['end_time'],$row['room'],$row['class_type'],$row['notes']]); $count++;
        }
        $pdo->commit(); return $count;
    } catch(Throwable $e) { if($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
}
