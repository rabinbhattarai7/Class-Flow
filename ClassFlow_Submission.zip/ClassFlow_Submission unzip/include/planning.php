<?php
/* These scheduling functions calculate overlaps, reminder times and available study slots from supplied records without saving changes. */
/* Shared, testable planning calculations. Estimates are rules, not trained models. */
// Use strict comparisons so an activity ending at the next activity’s start time does not count as an overlap.
function cf_overlap(string $startA, string $endA, string $startB, string $endB): bool
{
    return $startA < $endB && $endA > $startB;
}

// Calculate the first eligible reminder time in the student’s time zone. A lead of one day keeps the event’s local clock time on the previous day.
function cf_reminder_time(string $date, string $time, string $lead, DateTimeZone $zone): ?DateTimeImmutable
{
    $event = new DateTimeImmutable("$date $time", $zone);
    return match ($lead) {
        'same_day' => $event->setTime(8, 0) < $event ? $event->setTime(8, 0) : $event->setTime(0, 0),
        '1_day' => $event->modify('-1 day'),
        '3_days' => $event->modify('-3 days'),
        '1_week' => $event->modify('-1 week'),
        default => null,
    };
}

/** Expand weekly classes and dated events into actual local dates. */
function cf_events(array $classes, array $exams, array $sessions, DateTimeImmutable $from, DateTimeImmutable $to): array
{
    $events = [];
    for ($date = $from->setTime(0, 0); $date <= $to; $date = $date->modify('+1 day')) {
        $day = $date->format('Y-m-d');
        foreach ($classes as $c) {
            if (!empty($c['class_date']) ? $c['class_date'] === $day : $c['day'] === $date->format('l')) {
                $events[] = ['type' => 'class', 'id' => $c['id'], 'title' => $c['subject_name'], 'date' => $day,
                    'start' => substr($c['start_time'], 0, 5), 'end' => substr($c['end_time'], 0, 5)];
            }
        }
        foreach ([['exam', $exams, 'exam_date', 'exam_name'], ['study_session', $sessions, 'study_date', 'topic']] as [$type, $rows, $dateKey, $titleKey]) {
            foreach ($rows as $row) {
                if ($row[$dateKey] === $day && ($row['status'] ?? '') !== 'Completed') {
                    $events[] = ['type' => $type, 'id' => $row['id'], 'title' => $row[$titleKey], 'date' => $day,
                        'start' => substr($row['start_time'], 0, 5), 'end' => substr($row['end_time'], 0, 5)];
                }
            }
        }
    }
    usort($events, fn($a, $b) => strcmp($a['date'] . $a['start'], $b['date'] . $b['start']));
    return $events;
}

// Compare activities on the same date and return the pairs whose time ranges overlap.
function cf_conflicts(array $events): array
{
    $conflicts = [];
    foreach ($events as $i => $a) {
        for ($j = $i + 1; $j < count($events); $j++) {
            $b = $events[$j];
            if ($b['date'] !== $a['date']) break;
            if (cf_overlap($a['start'], $a['end'], $b['start'], $b['end'])) $conflicts[] = [$a, $b];
        }
    }
    return $conflicts;
}

/** Suggest only times that are free of every existing event on the selected day. */
// Scan the day in thirty-minute steps and return up to three openings long enough for the requested study session.
function cf_free_slots(array $events, string $day, int $minutes): array
{
    $result = [];
    for ($start = 8 * 60; $start + $minutes <= 20 * 60; $start += 30) {
        $a = sprintf('%02d:%02d', intdiv($start, 60), $start % 60);
        $end = $start + $minutes;
        $b = sprintf('%02d:%02d', intdiv($end, 60), $end % 60);
        $busy = false;
        foreach ($events as $event) {
            if ($event['date'] === $day && cf_overlap($a, $b, $event['start'], $event['end'])) { $busy = true; break; }
        }
        if (!$busy) $result[] = "{$a}–{$b}";
        if (count($result) === 3) break;
    }
    return $result;
}
