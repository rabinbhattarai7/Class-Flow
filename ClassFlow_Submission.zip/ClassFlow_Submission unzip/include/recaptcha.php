<?php
// Load the private server key from the environment or a local configuration file.
$recaptchaSecretKey = getenv('CLASSFLOW_RECAPTCHA_SECRET') ?: '';
$localConfig = __DIR__ . '/recaptcha.local.php';
if (is_file($localConfig)) {
    require $localConfig;
}
