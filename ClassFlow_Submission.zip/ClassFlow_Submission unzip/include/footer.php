<!-- The public footer loads the shared browser scripts and connects each password visibility button to its own input field. -->
<!-- Shared footer: provides copyright text, password visibility controls and Bootstrap scripts. -->
<!-- Footer -->
<footer>
    <div class="container text-center">
        <p class="mb-0">&copy; 2026 ClassFlow. Designed to help students organise their time.</p>
    </div>
</footer>

<!-- Bootstrap 5 JS Bundle -->
<script>
// Attach a visibility toggle to each button that names a password input.
document.querySelectorAll('[data-password-target]').forEach(function (button) {
    // Handle the eye button click without submitting the form.
    button.addEventListener('click', function () {
        const input = document.getElementById(button.dataset.passwordTarget);
        if (!input) return;

        // Determine whether this click should reveal or hide the password.
        const visible = input.type === 'password';
        input.type = visible ? 'text' : 'password';
        // Keep the accessible label and pressed state consistent with password visibility.
        button.setAttribute('aria-label', visible ? 'Hide password' : 'Show password');
        button.setAttribute('aria-pressed', String(visible));

        const icon = button.querySelector('i');
        if (icon) {
            icon.classList.toggle('bi-eye', !visible);
            icon.classList.toggle('bi-eye-slash', visible);
        }
    });
});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
