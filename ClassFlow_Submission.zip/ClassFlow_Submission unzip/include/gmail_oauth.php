<?php
/* Google sign-in authorises the Gmail application interface to send email. The connection is stored outside the website and refreshed when needed. */

// Keep the connection file in the Windows user’s local application folder, outside the site served by Apache.
function cf_gmail_oauth_path(): ?string
{
    $appData = getenv('LOCALAPPDATA');
    return $appData ? $appData . '/ClassFlow/gmail-oauth.json' : null;
}

// Only use a stored Google connection if all required values and a valid sender address are present.
function cf_gmail_oauth_config(): ?array
{
    $path = cf_gmail_oauth_path();
    if ($path === null || !is_readable($path)) {
        return null;
    }
    $raw = @file_get_contents($path);
    $config = $raw === false ? null : json_decode($raw, true);
    foreach (['client_id', 'client_secret', 'refresh_token', 'email'] as $key) {
        if (!is_string($config[$key] ?? null) || $config[$key] === '') {
            return null;
        }
    }
    return filter_var($config['email'], FILTER_VALIDATE_EMAIL) ? $config : null;
}

// Send a request to Google over an encrypted connection. Report failed responses without including tokens in the error.
function cf_gmail_google_request(string $url, array $headers, ?string $body, string $operation): array
{
    $curl = curl_init($url);
    curl_setopt_array($curl, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT => 20,
    ]);
    if ($body !== null) {
        curl_setopt($curl, CURLOPT_POSTFIELDS, $body);
    }
    try {
        $response = curl_exec($curl);
        $status = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
    } finally {
        curl_close($curl);
    }
    $data = $response === false ? null : json_decode($response, true);
    if ($status < 200 || $status >= 300 || !is_array($data)) {
        throw new RuntimeException("$operation failed (HTTP $status). Check the Google Cloud setup and Gmail authorisation.");
    }
    return $data;
}

// Exchange an authorisation code or refresh token for a temporary access token at Google’s token endpoint.
function cf_gmail_token(array $fields): array
{
    return cf_gmail_google_request(
        'https://oauth2.googleapis.com/token',
        ['Content-Type: application/x-www-form-urlencoded'],
        http_build_query($fields),
        'Google token request'
    );
}

// Encode the prepared email using the URL-safe Base64 format required by the Gmail application interface.
function cf_gmail_base64url(string $data): string
{
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

// Reuse the temporary Google access token during a worker run. Refresh it before expiry and check that Gmail returns a message identifier.
function cf_gmail_send_mime(array $config, string $mime): void
{
    static $accessToken = '';
    static $validUntil = 0;
    if ($validUntil <= time()) {
        $token = cf_gmail_token([
            'client_id' => $config['client_id'],
            'client_secret' => $config['client_secret'],
            'refresh_token' => $config['refresh_token'],
            'grant_type' => 'refresh_token',
        ]);
        if (empty($token['access_token'])) {
            throw new RuntimeException('Google did not return a Gmail access token.');
        }
        $accessToken = $token['access_token'];
        $validUntil = time() + max(0, (int) ($token['expires_in'] ?? 0) - 60);
    }
    $response = cf_gmail_google_request(
        'https://gmail.googleapis.com/gmail/v1/users/me/messages/send',
        ['Content-Type: application/json', 'Authorization: Bearer ' . $accessToken],
        json_encode(['raw' => cf_gmail_base64url($mime)], JSON_THROW_ON_ERROR),
        'Gmail submission'
    );
    if (empty($response['id'])) {
        throw new RuntimeException('Gmail did not return a message ID.');
    }
}
