<?php
/* Account pages and background scripts use this shared database connection. Credentials stay inside the connection function so they cannot overwrite form values. */
/* Shared PDO connection used by account pages and dashboard queries. */
try {
    // Keep connection credentials local so including this file cannot overwrite form data.
    $pdo = (static function (): PDO {
        $host = getenv('CLASSFLOW_DB_HOST') ?: 'localhost';
        $dbname = getenv('CLASSFLOW_DB_NAME') ?: 'classflow_file';
        $username = getenv('CLASSFLOW_DB_USER') ?: 'root';
        $password = getenv('CLASSFLOW_DB_PASSWORD') ?: '';
        return new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    })();
} catch (PDOException $e) {
    if (PHP_SAPI === 'cli') {
        file_put_contents('php://stderr', "Database connection failed. Check that XAMPP MySQL is running and ClassFlow can connect.\n");
        exit(1);
    }
    exit('Database connection failed.');
}
